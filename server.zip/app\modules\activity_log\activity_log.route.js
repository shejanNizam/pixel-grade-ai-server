"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActivityLogRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const user_interface_1 = require("../user/user.interface");
const activity_log_controller_1 = require("./activity_log.controller");
const router = (0, express_1.Router)();
/**
 * @swagger
 * /activity-log:
 *   get:
 *     tags: [ActivityLog]
 *     summary: Read the audit trail (admin only)
 *     description: >
 *       Filter with any log field, e.g. `?action=login_failed`. There is no
 *       write endpoint — logs are recorded server-side by the modules that
 *       perform the actions.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: action
 *         schema:
 *           type: string
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Paginated log entries, newest first
 *       403:
 *         description: Forbidden — insufficient role
 */
router.get("/", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), activity_log_controller_1.ActivityLogControllers.getAllLogs);
exports.ActivityLogRoutes = router;
//# sourceMappingURL=activity_log.route.js.map