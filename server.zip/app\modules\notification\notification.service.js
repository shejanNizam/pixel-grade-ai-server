"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationServices = exports.isStaffRole = void 0;
const http_status_1 = __importDefault(require("http-status"));
const index_1 = require("../../config/index");
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const QueryBuilder_1 = require("../../utils/QueryBuilder");
const logger_1 = require("../../utils/logger");
const sendEmail_1 = require("../../utils/sendEmail");
const socket_1 = require("../../../socket/socket");
const user_model_1 = require("../user/user.model");
const user_interface_1 = require("../user/user.interface");
const notification_interface_1 = require("./notification.interface");
const notification_model_1 = require("./notification.model");
/** Settings are created on first read rather than at signup, so accounts that
 *  predate this module still resolve to the documented defaults. */
const getOrCreateSettings = async (userId) => {
    const existing = await notification_model_1.NotificationSettings.findOne({ user: userId });
    if (existing)
        return existing;
    return notification_model_1.NotificationSettings.create({ user: userId });
};
/** Which email preference governs each notification type. `system` is
 *  deliberately absent — it has no user-facing toggle, so it stays in-app only
 *  rather than becoming unblockable email. */
const EMAIL_PREF_BY_TYPE = {
    [notification_interface_1.NotifType.grade_ready]: "emailGradeReady",
    [notification_interface_1.NotifType.price_alert]: "emailPriceAlert",
    [notification_interface_1.NotifType.subscription]: "emailSubscription",
    [notification_interface_1.NotifType.support]: "emailSupport",
    // Every staff alert shares one toggle, off by default. Splitting these into
    // four switches would be four settings nobody ever changes.
    [notification_interface_1.NotifType.support_ticket_new]: "emailAdminAlerts",
    [notification_interface_1.NotifType.support_ticket_reply]: "emailAdminAlerts",
    [notification_interface_1.NotifType.subscription_started]: "emailAdminAlerts",
    [notification_interface_1.NotifType.subscription_payment_failed]: "emailAdminAlerts",
};
const STAFF_ROLES = [user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin];
const isStaffRole = (role) => STAFF_ROLES.includes(role);
exports.isStaffRole = isStaffRole;
const emailConfigured = () => Boolean(index_1.configs.EMAIL_SENDER.smtp_host && index_1.configs.EMAIL_SENDER.smtp_user);
/**
 * Fire-and-forget email delivery. Never awaited by the caller's business flow
 * and never throws: a down SMTP server must not fail the grading, billing, or
 * support action that triggered the notification — the in-app copy is the
 * source of truth, email is best-effort.
 */
const dispatchEmail = async (userId, settings, type, title, body) => {
    try {
        if (!emailConfigured())
            return;
        const prefKey = EMAIL_PREF_BY_TYPE[type];
        if (!prefKey || !settings[prefKey])
            return;
        const user = await user_model_1.User.findById(userId).select("email isDeleted");
        if (!user?.email || user.isDeleted)
            return;
        await (0, sendEmail_1.sendEmail)({
            to: user.email,
            subject: `PixelGrade AI — ${title}`,
            templateName: "notification",
            templateData: {
                title,
                body: body ?? "",
                dashboardUrl: `${index_1.configs.frontend_url}/user-dashboard`,
            },
        });
    }
    catch (error) {
        logger_1.logger.error("Notification email dispatch failed", { userId, type, error });
    }
};
/**
 * Internal — called by other modules (grade ready, price alert, subscription
 * renewal, support reply), never exposed as a route. A client that could mint
 * its own notifications could forge a "grade ready" or a billing message.
 *
 * Two independent channels, each behind its own preference:
 *  - in-app: when `inappEnabled` is off nothing is stored, so the unread badge
 *    stays honest rather than counting hidden rows.
 *  - email: governed per-type by the `email*` flags; sent best-effort in the
 *    background even when in-app is off, since the user opted into each
 *    channel separately.
 */
const create = async (userId, type, title, body, link) => {
    const audience = notification_interface_1.TYPE_AUDIENCE[type];
    if (audience !== notification_interface_1.NotifAudience.user) {
        // A staff type addressed to one account is always a mistake — staff alerts
        // go to every admin via createForStaff. Failing loudly here beats a support
        // alert quietly appearing in a customer's notification bell.
        throw new AppError_1.default(http_status_1.default.INTERNAL_SERVER_ERROR, `"${type}" is a staff notification — use createForStaff, not create.`);
    }
    return deliver(userId, type, audience, title, body, link);
};
/**
 * Writes one notification and pushes it live.
 *
 * Shared by `create` and `createForStaff` so both channels, both preference
 * checks, and the socket push exist in exactly one place.
 */
const deliver = async (userId, type, audience, title, body, link) => {
    const settings = await getOrCreateSettings(String(userId));
    // Deliberately not awaited — see dispatchEmail.
    void dispatchEmail(String(userId), settings, type, title, body);
    // `inappEnabled` is a user-facing preference and deliberately does NOT
    // silence staff alerts: an admin muting their personal notifications must
    // not also stop seeing that tickets are arriving.
    if (!settings.inappEnabled && audience === notification_interface_1.NotifAudience.user)
        return null;
    const notification = await notification_model_1.Notification.create({
        user: userId,
        type,
        audience,
        title,
        ...(body ? { body } : {}),
        ...(link ? { link } : {}),
    });
    // Counted per audience, so the admin bell shows operational unread only and
    // the user bell shows personal unread only.
    const unreadCount = await notification_model_1.Notification.countDocuments({
        user: userId,
        audience,
        isRead: false,
    });
    // Push live so the badge updates without a refresh. emitToUser is a no-op
    // when sockets are not up, so this is safe during seeding and in tests.
    (0, socket_1.emitToUser)(String(userId), "notification:new", {
        notification,
        audience,
        unreadCount,
    });
    return notification;
};
/**
 * Fans a platform event out to every active staff account.
 *
 * One row per admin rather than one shared row, because read state is
 * per-person: a shared notification would be marked read for the whole team by
 * whoever opened it first.
 *
 * Never throws into the caller's flow. A support ticket must still be created
 * if the alert fails to reach one of three admins — the ticket is the record,
 * the notification is a convenience.
 */
const createForStaff = async (type, title, body, link) => {
    const audience = notification_interface_1.TYPE_AUDIENCE[type];
    if (audience !== notification_interface_1.NotifAudience.admin) {
        throw new AppError_1.default(http_status_1.default.INTERNAL_SERVER_ERROR, `"${type}" is a user notification — use create, not createForStaff.`);
    }
    try {
        const staff = await user_model_1.User.find({
            role: { $in: STAFF_ROLES },
            isDeleted: false,
            status: "active",
        }).select("_id");
        if (staff.length === 0) {
            logger_1.logger.warn("Staff notification had no recipients", { type, title });
            return [];
        }
        const results = await Promise.allSettled(staff.map((admin) => deliver(admin._id, type, audience, title, body, link)));
        results.forEach((result, index) => {
            if (result.status === "rejected") {
                logger_1.logger.error("Staff notification failed for one admin", {
                    adminId: String(staff[index]._id),
                    type,
                    error: result.reason,
                });
            }
        });
        return results.flatMap((r) => (r.status === "fulfilled" && r.value ? [r.value] : []));
    }
    catch (error) {
        logger_1.logger.error("Staff notification fan-out failed", { type, error });
        return [];
    }
};
/**
 * Admin announcement to every active customer.
 *
 * The one place a notification originates from a request rather than from a
 * platform event, so it is admin-guarded at the route and typed `system`,
 * which carries no email preference and therefore cannot be used to bypass a
 * user's email opt-outs.
 *
 * ⚠️ Writes one row per user. Fine at current scale; past roughly ten thousand
 * accounts this wants a queue rather than a request.
 */
const broadcast = async (title, body, link) => {
    const recipients = await user_model_1.User.find({
        role: user_interface_1.UserRole.user,
        isDeleted: false,
        status: "active",
    }).select("_id");
    const results = await Promise.allSettled(recipients.map((recipient) => deliver(recipient._id, notification_interface_1.NotifType.system, notification_interface_1.NotifAudience.user, title, body, link)));
    const delivered = results.filter((r) => r.status === "fulfilled").length;
    const failed = results.length - delivered;
    if (failed > 0) {
        logger_1.logger.error("Broadcast partially failed", { delivered, failed });
    }
    return { recipients: recipients.length, delivered, failed };
};
/**
 * Resolves which audience a caller is allowed to read.
 *
 * Only staff may ask for `admin`. A regular user requesting it would get an
 * empty list anyway — no staff-audience row is ever written to a customer —
 * but refusing explicitly keeps the rule in one readable place instead of
 * relying on that emergent property staying true.
 *
 * Defaults to `user`, so an un-parameterised call can never widen scope.
 */
const resolveAudience = (role, requested) => {
    if (requested === notification_interface_1.NotifAudience.admin) {
        if (!(0, exports.isStaffRole)(role)) {
            throw new AppError_1.default(http_status_1.default.FORBIDDEN, "Only staff can read admin notifications.");
        }
        return notification_interface_1.NotifAudience.admin;
    }
    return notification_interface_1.NotifAudience.user;
};
const getMyNotifications = async (userId, role, query) => {
    const audience = resolveAudience(role, query.audience);
    // `audience` is stripped from the passthrough filter — it is resolved above
    // against the caller's role, and letting QueryBuilder apply the raw param
    // would hand the client back control of the thing we just authorised.
    const filters = { ...query };
    delete filters.audience;
    const queryBuilder = new QueryBuilder_1.QueryBuilder(notification_model_1.Notification.find({ user: userId, audience }), filters);
    const notifications = await queryBuilder
        .filter()
        .sort()
        .paginate()
        .build();
    const meta = await queryBuilder.getMeta();
    return { data: notifications, meta };
};
const getUnreadCount = async (userId, role, requestedAudience) => {
    const audience = resolveAudience(role, requestedAudience);
    const count = await notification_model_1.Notification.countDocuments({
        user: userId,
        audience,
        isRead: false,
    });
    return { unreadCount: count, audience };
};
/** Scoped to the owner in the query itself, so one user cannot mark another
 *  user's notification as read by guessing an id. */
const markAsRead = async (userId, notificationId) => {
    const notification = await notification_model_1.Notification.findOneAndUpdate({ _id: notificationId, user: userId }, { isRead: true }, { returnDocument: "after" });
    if (!notification) {
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Notification not found");
    }
    // Recount within the notification's OWN audience — marking a staff alert read
    // must not decrement the personal badge, and vice versa.
    const unreadCount = await notification_model_1.Notification.countDocuments({
        user: userId,
        audience: notification.audience,
        isRead: false,
    });
    (0, socket_1.emitToUser)(userId, "notification:read", {
        notificationId,
        audience: notification.audience,
        unreadCount,
    });
    return notification;
};
/** Scoped to one audience, so "mark all read" in the admin bell does not also
 *  clear the reader's personal notifications. */
const markAllAsRead = async (userId, role, requestedAudience) => {
    const audience = resolveAudience(role, requestedAudience);
    await notification_model_1.Notification.updateMany({ user: userId, audience, isRead: false }, { isRead: true });
    (0, socket_1.emitToUser)(userId, "notification:read_all", { audience, unreadCount: 0 });
    return { unreadCount: 0, audience };
};
const remove = async (userId, notificationId) => {
    const deleted = await notification_model_1.Notification.findOneAndDelete({
        _id: notificationId,
        user: userId,
    });
    if (!deleted) {
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Notification not found");
    }
    return deleted;
};
const getSettings = async (userId) => {
    return getOrCreateSettings(userId);
};
const updateSettings = async (userId, payload) => {
    await getOrCreateSettings(userId);
    return notification_model_1.NotificationSettings.findOneAndUpdate({ user: userId }, payload, {
        returnDocument: "after",
        runValidators: true,
    });
};
exports.NotificationServices = {
    create,
    createForStaff,
    broadcast,
    getMyNotifications,
    getUnreadCount,
    markAsRead,
    markAllAsRead,
    remove,
    getSettings,
    updateSettings,
};
//# sourceMappingURL=notification.service.js.map