"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationSettings = exports.notificationSettingsSchema = exports.Notification = exports.notificationSchema = void 0;
const mongoose_1 = require("mongoose");
const notification_interface_1 = require("./notification.interface");
exports.notificationSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
    type: { type: String, enum: Object.values(notification_interface_1.NotifType), required: true },
    audience: {
        type: String,
        enum: Object.values(notification_interface_1.NotifAudience),
        required: true,
        default: notification_interface_1.NotifAudience.user,
    },
    title: { type: String, required: true },
    body: { type: String },
    isRead: { type: Boolean, default: false },
    link: { type: String },
}, {
    timestamps: true,
    versionKey: false,
});
// Every read path is "this recipient, this audience" — the two dashboards ask
// for different audiences, and the unread badge is counted per audience so the
// admin bell does not include the admin's own personal notifications.
exports.notificationSchema.index({ user: 1, audience: 1, isRead: 1, createdAt: -1 });
exports.Notification = (0, mongoose_1.model)("Notification", exports.notificationSchema);
exports.notificationSettingsSchema = new mongoose_1.Schema({
    user: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "User",
        required: true,
        unique: true,
    },
    inappEnabled: { type: Boolean, default: true },
    emailGradeReady: { type: Boolean, default: true },
    emailPriceAlert: { type: Boolean, default: true },
    emailSubscription: { type: Boolean, default: true },
    emailSupport: { type: Boolean, default: true },
    // Off by default — see INotificationSettings.
    emailAdminAlerts: { type: Boolean, default: false },
}, {
    timestamps: true,
    versionKey: false,
});
exports.NotificationSettings = (0, mongoose_1.model)("NotificationSettings", exports.notificationSettingsSchema);
//# sourceMappingURL=notification.model.js.map