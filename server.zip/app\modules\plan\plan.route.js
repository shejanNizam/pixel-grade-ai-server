"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlanRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const validateRequest_1 = __importDefault(require("../../middlewares/validateRequest"));
const user_interface_1 = require("../user/user.interface");
const plan_controller_1 = require("./plan.controller");
const plan_validation_1 = require("./plan.validation");
const router = (0, express_1.Router)();
/**
 * @swagger
 * /plan:
 *   get:
 *     tags: [Plan]
 *     summary: List active subscription plans (public — powers the pricing page)
 *     responses:
 *       200:
 *         description: The four plan tiers, cheapest first
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessResponse'
 */
router.get("/", plan_controller_1.PlanControllers.getAllPlans);
/**
 * @swagger
 * /plan/admin:
 *   get:
 *     tags: [Plan]
 *     summary: List all plans including deactivated ones (admin only)
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: All plans
 *       403:
 *         description: Forbidden — insufficient role
 */
router.get("/admin", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), plan_controller_1.PlanControllers.getAllPlansForAdmin);
/**
 * @swagger
 * /plan/{id}:
 *   get:
 *     tags: [Plan]
 *     summary: Get a single plan
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Plan found
 *       404:
 *         description: Plan not found
 *   patch:
 *     tags: [Plan]
 *     summary: Edit a plan (admin only)
 *     description: >
 *       Plans are edit-only. There is no create or delete endpoint — the four
 *       tiers are fixed — and `name` is rejected so a tier cannot be renamed.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Plan updated
 *       403:
 *         description: Forbidden — insufficient role
 *       404:
 *         description: Plan not found
 */
router.get("/:id", plan_controller_1.PlanControllers.getSinglePlan);
router.patch("/:id", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), (0, validateRequest_1.default)(plan_validation_1.updatePlanZodSchema), plan_controller_1.PlanControllers.updatePlan);
exports.PlanRoutes = router;
//# sourceMappingURL=plan.route.js.map