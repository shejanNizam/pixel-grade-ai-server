"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Card = exports.cardSchema = void 0;
const mongoose_1 = require("mongoose");
const card_interface_1 = require("./card.interface");
exports.cardSchema = new mongoose_1.Schema({
    scrydexCardId: { type: String, required: true, unique: true },
    game: {
        type: String,
        enum: Object.values(card_interface_1.CardGame),
        default: card_interface_1.CardGame.pokemon,
    },
    name: { type: String, required: true },
    language: { type: String },
    releaseYear: { type: Number },
    setExpansion: { type: String },
    cardNumber: { type: String },
    rarity: { type: String },
    // Palette cue for slab artwork — see the interface.
    types: { type: [String], default: undefined },
    officialImageUrl: { type: String },
    // Which printing this row is. See the interface — a card id alone does not
    // identify a price, and refreshing a different variant each pass would put
    // our own bookkeeping into the price history as if it were market movement.
    scrydexVariant: { type: String },
    latestPrice: { type: Number },
    priceCondition: { type: String },
    // Defaulted rather than optional: an unlabelled price is the ambiguity the
    // client reported, and everything the pricing provider returns today is a
    // raw comp. A graded price must set this explicitly.
    priceBasis: {
        type: String,
        enum: Object.values(card_interface_1.PriceBasis),
        default: card_interface_1.PriceBasis.raw,
    },
    priceGradeRef: { type: String },
    // The PSA ladder for this printing. `_id: false` because these are values,
    // not documents — nothing ever references a single rung.
    gradedPrices: {
        type: [
            {
                _id: false,
                grade: { type: String, required: true },
                price: { type: Number, required: true, min: 0 },
            },
        ],
        default: undefined,
    },
    gradedCompany: { type: String },
    currency: { type: String, default: "USD" },
    lastPricedAt: { type: Date },
    // One-shot claim for the historical archive pull — see the interface.
    historyBackfilledAt: { type: Date },
}, {
    timestamps: true,
    versionKey: false,
});
exports.cardSchema.index({ name: 1 });
exports.cardSchema.index({ setExpansion: 1 });
// The price-refresh job sweeps oldest-first, so it needs this ordering.
exports.cardSchema.index({ lastPricedAt: 1 });
exports.Card = (0, mongoose_1.model)("Card", exports.cardSchema);
//# sourceMappingURL=card.model.js.map