"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.multerUpload = void 0;
const crypto_1 = __importDefault(require("crypto"));
const multer_1 = __importDefault(require("multer"));
const multer_storage_cloudinary_1 = require("multer-storage-cloudinary");
const cloudinary_config_1 = require("./cloudinary.config");
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
const storage = new multer_storage_cloudinary_1.CloudinaryStorage({
    cloudinary: cloudinary_config_1.cloudinaryUpload,
    params: async (_req, file) => {
        const originalName = file?.originalname || "unnamed";
        const baseName = originalName
            .toLowerCase()
            .replace(/\.[^.]+$/, "")
            .replace(/\s+/g, "-")
            .replace(/[^a-z0-9-]/g, "")
            .slice(0, 60);
        return {
            folder: "uploads",
            resource_type: "auto",
            public_id: `${crypto_1.default.randomUUID()}-${baseName || "file"}`,
        };
    },
});
exports.multerUpload = (0, multer_1.default)({
    storage,
    limits: { fileSize: MAX_FILE_SIZE },
});
//# sourceMappingURL=multer.config.js.map