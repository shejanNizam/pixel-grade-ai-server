"use strict";
/**
 * Read-only aggregates for the two dashboard landing pages.
 *
 * This module owns no collection of its own — it composes the services that do.
 * It exists because both dashboards open with a row of stat cards drawn from
 * four or five different domains at once, and the alternative is the client
 * fanning out five requests just to paint the first screen.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=dashboard.interface.js.map