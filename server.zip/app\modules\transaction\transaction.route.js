"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const user_interface_1 = require("../user/user.interface");
const transaction_controller_1 = require("./transaction.controller");
const router = (0, express_1.Router)();
const anyUser = Object.values(user_interface_1.UserRole);
const adminOnly = [user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin];
/**
 * @swagger
 * /transaction/me:
 *   get:
 *     tags: [Transaction]
 *     summary: The caller's billing history and invoices
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Paginated transactions, newest first
 */
router.get("/me", (0, checkAuth_1.checkAuth)(...anyUser), transaction_controller_1.TransactionControllers.getMyTransactions);
/**
 * @swagger
 * /transaction/earnings:
 *   get:
 *     tags: [Transaction]
 *     summary: Platform earnings overview (admin only)
 *     description: >
 *       Counts succeeded transactions only. Refunds are reported separately
 *       rather than netted off, so gross and refunded are both visible.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: from
 *         schema:
 *           type: string
 *           format: date
 *       - in: query
 *         name: to
 *         schema:
 *           type: string
 *           format: date
 *     responses:
 *       200:
 *         description: Revenue split by subscriptions and slab orders
 *       403:
 *         description: Forbidden — insufficient role
 */
router.get("/earnings", (0, checkAuth_1.checkAuth)(...adminOnly), transaction_controller_1.TransactionControllers.getEarnings);
/**
 * @swagger
 * /transaction/revenue-by-month:
 *   get:
 *     tags: [Transaction]
 *     summary: Monthly revenue buckets for the earnings chart (admin only)
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: months
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Revenue per month
 */
router.get("/revenue-by-month", (0, checkAuth_1.checkAuth)(...adminOnly), transaction_controller_1.TransactionControllers.getRevenueByMonth);
/**
 * @swagger
 * /transaction:
 *   get:
 *     tags: [Transaction]
 *     summary: All transactions (admin only)
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Paginated transactions
 *       403:
 *         description: Forbidden — insufficient role
 */
router.get("/", (0, checkAuth_1.checkAuth)(...adminOnly), transaction_controller_1.TransactionControllers.getAllTransactions);
exports.TransactionRoutes = router;
//# sourceMappingURL=transaction.route.js.map