"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CaptchaProvider = exports.verifyCaptcha = exports.warnIfCaptchaDisabled = void 0;
const http_status_1 = __importDefault(require("http-status"));
const index_1 = require("../config/index");
const AppError_1 = __importDefault(require("../errorHelpers/AppError"));
const logger_1 = require("../utils/logger");
// ---------------------------------------------------------------------------
// Bot protection — Cloudflare Turnstile.
//
// Added for support ticket submission (client, 2026-08-10). Turnstile rather
// than reCAPTCHA: no per-request cost, no Google account required, and it does
// not need a visible puzzle in the common case.
//
// ⚠️ FAIL-OPEN WHEN UNCONFIGURED, FAIL-CLOSED WHEN CONFIGURED.
//
// Without a secret key, `verifyCaptcha` returns without checking anything and
// the server warns at startup. That is deliberate — the keys are the client's
// to provision, and hard-failing would take the whole support form down in
// every environment until they arrive. It also means **an unset
// TURNSTILE_SECRET_KEY in production silently disables spam protection**, so
// setting it is a deployment requirement, not a nice-to-have.
//
// Once the secret IS set, a missing or invalid token is rejected outright —
// including when Cloudflare itself is unreachable. A captcha that waves
// requests through whenever the verifier is down protects nothing.
// ---------------------------------------------------------------------------
const TURNSTILE_VERIFY_URL = "https://challenges.cloudflare.com/turnstile/v0/siteverify";
/** How long to wait on Cloudflare before giving up on the request. */
const VERIFY_TIMEOUT_MS = 5_000;
/** Warned once at boot so a misconfigured deploy is visible in the logs. */
const warnIfCaptchaDisabled = () => {
    if (!index_1.configs.CAPTCHA.enabled) {
        logger_1.logger.warn("TURNSTILE_SECRET_KEY is not set — captcha verification is DISABLED. " +
            "Support ticket submission is unprotected against automated spam.");
    }
};
exports.warnIfCaptchaDisabled = warnIfCaptchaDisabled;
/**
 * Throws unless `token` is a valid Turnstile solution.
 *
 * @param token  The `cf-turnstile-response` the widget produced client-side.
 * @param remoteIp  The submitter's IP, if known. Optional but tightens the check.
 */
const verifyCaptcha = async (token, remoteIp) => {
    if (!index_1.configs.CAPTCHA.enabled)
        return;
    if (!token) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Please complete the verification challenge before submitting.");
    }
    const body = new URLSearchParams({
        secret: index_1.configs.CAPTCHA.turnstile_secret,
        response: token,
    });
    if (remoteIp)
        body.set("remoteip", remoteIp);
    let result;
    try {
        const response = await fetch(TURNSTILE_VERIFY_URL, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body,
            signal: AbortSignal.timeout(VERIFY_TIMEOUT_MS),
        });
        result = (await response.json());
    }
    catch (error) {
        logger_1.logger.error("Turnstile verification request failed", { error });
        // Fail closed: see the header note.
        throw new AppError_1.default(http_status_1.default.SERVICE_UNAVAILABLE, "Couldn't complete the verification check. Please try again in a moment.");
    }
    if (!result.success) {
        logger_1.logger.warn("Turnstile rejected a submission", {
            errors: result["error-codes"],
        });
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Verification failed. Please try the challenge again.");
    }
};
exports.verifyCaptcha = verifyCaptcha;
exports.CaptchaProvider = { verifyCaptcha: exports.verifyCaptcha, warnIfCaptchaDisabled: exports.warnIfCaptchaDisabled };
//# sourceMappingURL=captcha.provider.js.map