"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.User = exports.userSchema = void 0;
const mongoose_1 = require("mongoose");
const user_interface_1 = require("./user.interface");
exports.userSchema = new mongoose_1.Schema({
    name: { type: String, required: true },
    username: {
        type: String,
        trim: true,
        lowercase: true,
        // `sparse` is required, not cosmetic: a plain unique index treats every
        // user without a username as holding the same `null`, so the second
        // account created would collide on it.
        unique: true,
        sparse: true,
        minlength: 3,
        maxlength: 24,
        match: [
            /^[a-z0-9_]+$/,
            "Username may only contain lowercase letters, numbers, and underscores",
        ],
    },
    email: { type: String, required: true, unique: true },
    password: { type: String, select: false },
    phone: { type: String },
    role: {
        type: String,
        enum: Object.values(user_interface_1.UserRole),
        default: user_interface_1.UserRole.user,
    },
    avatar: {
        url: { type: String },
        publicId: { type: String },
    },
    isEmailVerified: { type: Boolean, default: false },
    status: { type: String, enum: ["active", "blocked"], default: "active" },
    blockReason: { type: String },
    isDeleted: { type: Boolean, default: false },
    deletedAt: { type: Date },
    lastLoginAt: { type: Date },
}, {
    timestamps: true,
    versionKey: false,
});
exports.userSchema.index({ role: 1, status: 1 });
exports.User = (0, mongoose_1.model)("User", exports.userSchema);
//# sourceMappingURL=user.model.js.map