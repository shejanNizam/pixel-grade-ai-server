"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const activity_log_route_1 = require("../modules/activity_log/activity_log.route");
const analysis_route_1 = require("../modules/analysis/analysis.route");
const auth_route_1 = require("../modules/auth/auth.route");
const card_route_1 = require("../modules/card/card.route");
const cms_route_1 = require("../modules/cms/cms.route");
const collection_route_1 = require("../modules/collection/collection.route");
const credit_route_1 = require("../modules/credit/credit.route");
const dashboard_route_1 = require("../modules/dashboard/dashboard.route");
const grading_route_1 = require("../modules/grading/grading.route");
const notification_route_1 = require("../modules/notification/notification.route");
const otp_route_1 = require("../modules/otp/otp.route");
const plan_route_1 = require("../modules/plan/plan.route");
const price_route_1 = require("../modules/price/price.route");
const slab_route_1 = require("../modules/slab/slab.route");
const slabOrder_route_1 = require("../modules/slabOrder/slabOrder.route");
const subscription_route_1 = require("../modules/subscription/subscription.route");
const support_route_1 = require("../modules/support/support.route");
const transaction_route_1 = require("../modules/transaction/transaction.route");
const upload_route_1 = require("../modules/upload/upload.route");
const user_route_1 = require("../modules/user/user.route");
const router = (0, express_1.Router)();
const moduleRoutes = [
    { path: "/auth", route: auth_route_1.AuthRoutes },
    { path: "/user", route: user_route_1.UserRoutes },
    { path: "/otp", route: otp_route_1.OtpRoutes },
    { path: "/upload", route: upload_route_1.UploadRoutes },
    { path: "/plan", route: plan_route_1.PlanRoutes },
    { path: "/credit", route: credit_route_1.CreditRoutes },
    { path: "/card", route: card_route_1.CardRoutes },
    { path: "/analysis", route: analysis_route_1.AnalysisRoutes },
    { path: "/grading", route: grading_route_1.GradingRoutes },
    { path: "/slab", route: slab_route_1.SlabRoutes },
    { path: "/slab-order", route: slabOrder_route_1.SlabOrderRoutes },
    { path: "/collection", route: collection_route_1.CollectionRoutes },
    { path: "/price", route: price_route_1.PriceRoutes },
    { path: "/subscription", route: subscription_route_1.SubscriptionRoutes },
    { path: "/transaction", route: transaction_route_1.TransactionRoutes },
    { path: "/dashboard", route: dashboard_route_1.DashboardRoutes },
    { path: "/notification", route: notification_route_1.NotificationRoutes },
    { path: "/support", route: support_route_1.SupportRoutes },
    { path: "/cms", route: cms_route_1.CmsRoutes },
    { path: "/activity-log", route: activity_log_route_1.ActivityLogRoutes },
];
moduleRoutes.forEach((route) => {
    router.use(route.path, route.route);
});
exports.default = router;
//# sourceMappingURL=index.js.map