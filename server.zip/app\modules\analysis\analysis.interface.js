"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnalysisStatus = exports.ImageSide = exports.UploadSource = void 0;
/** How the images arrived. `pixelscope` is paid-only and is one of the two
 *  conditions for Pixel Verified — a standard scan can never earn the badge. */
var UploadSource;
(function (UploadSource) {
    UploadSource["standard"] = "standard";
    UploadSource["pixelscope"] = "pixelscope";
})(UploadSource || (exports.UploadSource = UploadSource = {}));
var ImageSide;
(function (ImageSide) {
    ImageSide["front"] = "front";
    ImageSide["back"] = "back";
})(ImageSide || (exports.ImageSide = ImageSide = {}));
/** `awaiting_confirmation` is a hard gate, not a UI nicety: grading and slab
 *  generation refuse to run until the user has confirmed the match.
 *
 *  `canceled` is deliberately distinct from `failed`: both end the scan and both
 *  refund, but `failed` means the system could not deliver and `canceled` means
 *  the user walked away. Collapsing them would make abandonment look like an
 *  outage in the admin analytics. */
var AnalysisStatus;
(function (AnalysisStatus) {
    AnalysisStatus["identifying"] = "identifying";
    AnalysisStatus["awaiting_confirmation"] = "awaiting_confirmation";
    AnalysisStatus["confirmed"] = "confirmed";
    AnalysisStatus["graded"] = "graded";
    AnalysisStatus["failed"] = "failed";
    AnalysisStatus["canceled"] = "canceled";
})(AnalysisStatus || (exports.AnalysisStatus = AnalysisStatus = {}));
//# sourceMappingURL=analysis.interface.js.map