"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GradeLabel = void 0;
/** Human-readable band shown next to the numeric grade. */
var GradeLabel;
(function (GradeLabel) {
    GradeLabel["PR"] = "PR";
    GradeLabel["FR"] = "FR";
    GradeLabel["GOOD"] = "GOOD";
    GradeLabel["VG"] = "VG";
    GradeLabel["EX"] = "EX";
    GradeLabel["NM"] = "NM";
    GradeLabel["NM-MT"] = "NM-MT";
    GradeLabel["MINT"] = "MINT";
    GradeLabel["GEM-MT"] = "GEM-MT";
})(GradeLabel || (exports.GradeLabel = GradeLabel = {}));
//# sourceMappingURL=grading.interface.js.map