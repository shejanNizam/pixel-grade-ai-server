"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRole = void 0;
var UserRole;
(function (UserRole) {
    UserRole["user"] = "user";
    UserRole["admin"] = "admin";
    UserRole["super_admin"] = "super_admin";
})(UserRole || (exports.UserRole = UserRole = {}));
//# sourceMappingURL=user.interface.js.map