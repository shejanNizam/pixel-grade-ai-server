"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cloudinary_config_1 = require("../app/config/cloudinary.config");
const globalErrorHandler_1 = require("../app/middlewares/globalErrorHandler");
describe("Upload Error Handling & Cleanup Resilience", () => {
    it("deleteFromCloudinary should execute safely without throwing on invalid/undefined/null inputs", async () => {
        await expect((0, cloudinary_config_1.deleteFromCloudinary)(undefined)).resolves.not.toThrow();
        await expect((0, cloudinary_config_1.deleteFromCloudinary)(null)).resolves.not.toThrow();
        await expect((0, cloudinary_config_1.deleteFromCloudinary)("")).resolves.not.toThrow();
        await expect((0, cloudinary_config_1.deleteFromCloudinary)(123)).resolves.not.toThrow();
        await expect((0, cloudinary_config_1.deleteFromCloudinary)("invalid-url-without-upload")).resolves.not.toThrow();
    });
    it("globalErrorHandler should handle req.files with missing or undefined file paths gracefully without crashing the server process", async () => {
        const req = {
            file: undefined,
            files: [
                undefined,
                null,
                {},
                { path: undefined },
                { path: "" },
                { path: 123 },
            ],
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn(),
        };
        const next = jest.fn();
        const mockError = new Error("Multer upload aborted mid-stream");
        await expect((0, globalErrorHandler_1.globalErrorHandler)(mockError, req, res, next)).resolves.not.toThrow();
        expect(res.status).toHaveBeenCalledWith(500);
        expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
            success: false,
            message: "Multer upload aborted mid-stream",
        }));
    });
});
//# sourceMappingURL=uploadErrorHandling.test.js.map