"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TYPE_AUDIENCE = exports.NotifType = exports.NotifAudience = void 0;
/**
 * Who a notification is speaking to.
 *
 * NOT the same thing as who owns the row. Every notification is still stored
 * per-recipient — that is what gives each person their own read state — but an
 * admin account legitimately receives both kinds: personal ones about their own
 * scans and subscription, and operational ones about the platform. `audience`
 * is what lets the two dashboards show the right subset instead of mixing
 * "your grade is ready" into the staff queue.
 */
var NotifAudience;
(function (NotifAudience) {
    /** About the recipient's own activity. Shown in the user dashboard. */
    NotifAudience["user"] = "user";
    /** About platform operations. Shown in the admin dashboard, staff only. */
    NotifAudience["admin"] = "admin";
})(NotifAudience || (exports.NotifAudience = NotifAudience = {}));
var NotifType;
(function (NotifType) {
    // ---- user-facing ----
    NotifType["grade_ready"] = "grade_ready";
    NotifType["price_alert"] = "price_alert";
    NotifType["subscription"] = "subscription";
    NotifType["support"] = "support";
    /** Announcements broadcast by an admin. */
    NotifType["system"] = "system";
    // ---- staff-facing ----
    /** A user opened a new support ticket. */
    NotifType["support_ticket_new"] = "support_ticket_new";
    /** A user replied on an existing ticket, reopening it. */
    NotifType["support_ticket_reply"] = "support_ticket_reply";
    /** A paid subscription activated. */
    NotifType["subscription_started"] = "subscription_started";
    /** A subscription payment failed — the user may be about to churn. */
    NotifType["subscription_payment_failed"] = "subscription_payment_failed";
})(NotifType || (exports.NotifType = NotifType = {}));
/**
 * Which audience each type belongs to.
 *
 * Declared once here so a type cannot be delivered to the wrong dashboard by
 * accident: `create` and `createForStaff` both assert against this, which turns
 * "staff alert leaked into a customer's bell" from a silent data problem into a
 * loud failure at the call site.
 */
exports.TYPE_AUDIENCE = {
    [NotifType.grade_ready]: NotifAudience.user,
    [NotifType.price_alert]: NotifAudience.user,
    [NotifType.subscription]: NotifAudience.user,
    [NotifType.support]: NotifAudience.user,
    [NotifType.system]: NotifAudience.user,
    [NotifType.support_ticket_new]: NotifAudience.admin,
    [NotifType.support_ticket_reply]: NotifAudience.admin,
    [NotifType.subscription_started]: NotifAudience.admin,
    [NotifType.subscription_payment_failed]: NotifAudience.admin,
};
//# sourceMappingURL=notification.interface.js.map