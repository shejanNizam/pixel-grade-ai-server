"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PriceControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const scrydex_client_1 = require("../../services/scrydex/scrydex.client");
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const price_service_1 = require("./price.service");
const ALLOWED_WINDOWS = ["24h", "7d", "30d", "1y"];
const parseWindow = (raw) => ALLOWED_WINDOWS.includes(raw) ? raw : "30d";
const getCardPrice = (0, catchAsync_1.default)(async (req, res) => {
    const result = await price_service_1.PriceServices.getCardPrice(req.params.cardId, parseWindow(req.query.window));
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Price history retrieved successfully!",
        data: result,
    });
});
/** Sparklines for a whole table in one call — see getHistoryBatch. */
const getHistoryBatch = (0, catchAsync_1.default)(async (req, res) => {
    const raw = req.query.cardIds;
    const cardIds = (Array.isArray(raw) ? raw.join(",") : String(raw ?? ""))
        .split(",")
        .map((id) => id.trim())
        .filter(Boolean);
    const result = await price_service_1.PriceServices.getHistoryBatch(cardIds, parseWindow(req.query.window));
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Price history retrieved successfully!",
        data: result,
    });
});
const getPortfolioSummary = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await price_service_1.PriceServices.getPortfolioSummary(userId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Portfolio summary retrieved successfully!",
        data: result,
    });
});
/** Manual trigger for the sweep the cron also runs — useful for admin recovery
 *  after an outage without waiting for the next scheduled tick. */
const refreshNow = (0, catchAsync_1.default)(async (req, res) => {
    const limit = Number(req.query.limit) || 200;
    const result = await price_service_1.PriceServices.refreshStalest(limit);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Price refresh completed.",
        data: result,
    });
});
/**
 * Scrydex credit consumption for the current billing period (admin only).
 *
 * Worth having a route for because Scrydex does not stop serving at the
 * allowance — it rolls silently into billed overage at $0.006/credit on the
 * Starter tier the client is on. Without this, the first sign of a runaway
 * price sweep or a scan spike is an invoice.
 *
 * The usage endpoint does not itself consume credits, so polling it is free.
 */
const getVendorUsage = (0, catchAsync_1.default)(async (_req, res) => {
    const result = await scrydex_client_1.ScrydexClient.getUsage();
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Scrydex usage retrieved successfully!",
        data: result,
    });
});
exports.PriceControllers = {
    getCardPrice,
    getHistoryBatch,
    getPortfolioSummary,
    refreshNow,
    getVendorUsage,
};
//# sourceMappingURL=price.controller.js.map