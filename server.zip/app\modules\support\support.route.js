"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupportRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const validateRequest_1 = __importDefault(require("../../middlewares/validateRequest"));
const user_interface_1 = require("../user/user.interface");
const support_controller_1 = require("./support.controller");
const support_validation_1 = require("./support.validation");
const router = (0, express_1.Router)();
const anyUser = Object.values(user_interface_1.UserRole);
/**
 * @swagger
 * /support:
 *   post:
 *     tags: [Support]
 *     summary: Open a support ticket
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       201:
 *         description: Ticket created
 *       422:
 *         description: Validation error
 *   get:
 *     tags: [Support]
 *     summary: List the caller's own tickets
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Tickets
 */
router.post("/", (0, checkAuth_1.checkAuth)(...anyUser), (0, validateRequest_1.default)(support_validation_1.createTicketZodSchema), support_controller_1.SupportControllers.createTicket);
router.get("/", (0, checkAuth_1.checkAuth)(...anyUser), support_controller_1.SupportControllers.getMyTickets);
/**
 * @swagger
 * /support/all:
 *   get:
 *     tags: [Support]
 *     summary: List every ticket (admin only)
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [open, answered, resolved, closed]
 *     responses:
 *       200:
 *         description: Tickets
 *       403:
 *         description: Forbidden — insufficient role
 */
router.get("/all", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), support_controller_1.SupportControllers.getAllTickets);
/**
 * @swagger
 * /support/{id}:
 *   get:
 *     tags: [Support]
 *     summary: Get a ticket with its full message thread
 *     description: >
 *       Users may only open their own tickets; admins may open any. Ownership is
 *       checked against the document, not the role alone.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Ticket and messages
 *       403:
 *         description: Not your ticket
 *       404:
 *         description: Ticket not found
 */
router.get("/:id", (0, checkAuth_1.checkAuth)(...anyUser), support_controller_1.SupportControllers.getTicket);
/**
 * @swagger
 * /support/{id}/message:
 *   post:
 *     tags: [Support]
 *     summary: Reply on a ticket
 *     description: >
 *       A staff reply moves the ticket to `answered` and notifies the owner.
 *       A user reply reopens an answered ticket. Closed tickets reject replies.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       201:
 *         description: Message added
 *       400:
 *         description: Ticket is closed
 *       403:
 *         description: Not your ticket
 */
router.post("/:id/message", (0, checkAuth_1.checkAuth)(...anyUser), (0, validateRequest_1.default)(support_validation_1.addTicketMessageZodSchema), support_controller_1.SupportControllers.addMessage);
/**
 * @swagger
 * /support/{id}/status:
 *   patch:
 *     tags: [Support]
 *     summary: Change a ticket's status (admin only)
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Status updated
 *       403:
 *         description: Forbidden — insufficient role
 */
router.patch("/:id/status", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), (0, validateRequest_1.default)(support_validation_1.updateTicketStatusZodSchema), support_controller_1.SupportControllers.updateStatus);
router.patch("/:id/reopen", (0, checkAuth_1.checkAuth)(...anyUser), support_controller_1.SupportControllers.reopenTicket);
exports.SupportRoutes = router;
//# sourceMappingURL=support.route.js.map