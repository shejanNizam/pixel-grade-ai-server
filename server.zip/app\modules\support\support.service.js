"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupportServices = void 0;
const http_status_1 = __importDefault(require("http-status"));
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const captcha_provider_1 = require("../../services/captcha.provider");
const QueryBuilder_1 = require("../../utils/QueryBuilder");
const notification_interface_1 = require("../notification/notification.interface");
const notification_service_1 = require("../notification/notification.service");
const user_interface_1 = require("../user/user.interface");
const support_interface_1 = require("./support.interface");
const support_model_1 = require("./support.model");
const createTicket = async (userId, payload, remoteIp) => {
    // Before anything is written. A ticket that reached the database and then
    // failed the captcha would still have consumed the caller's one active slot.
    await captcha_provider_1.CaptchaProvider.verifyCaptcha(payload.captchaToken, remoteIp);
    const activeTicket = await support_model_1.SupportTicket.findOne({
        user: userId,
        status: { $in: [support_interface_1.TicketStatus.open, support_interface_1.TicketStatus.answered] },
    });
    if (activeTicket) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "You already have an active support ticket. Please wait until it is resolved or closed before creating another.");
    }
    const ticket = await support_model_1.SupportTicket.create({
        user: userId,
        subject: payload.subject,
        status: support_interface_1.TicketStatus.open,
        reopenCount: 0,
    });
    await support_model_1.SupportTicketMessage.create({
        ticket: ticket._id,
        sender: userId,
        isAdmin: false,
        message: payload.message,
    });
    // Tell the staff queue. Before this, a new ticket notified nobody — it sat
    // in the admin list until someone thought to look.
    await notification_service_1.NotificationServices.createForStaff(notification_interface_1.NotifType.support_ticket_new, "New support ticket", payload.subject, `/admin/support/${String(ticket._id)}`);
    return ticket;
};
const reopenTicket = async (ticketId, userId) => {
    const ticket = await support_model_1.SupportTicket.findOne({ _id: ticketId, user: userId });
    if (!ticket)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Ticket not found");
    if (ticket.status !== support_interface_1.TicketStatus.closed && ticket.status !== support_interface_1.TicketStatus.resolved) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Only closed or resolved tickets can be reopened.");
    }
    if ((ticket.reopenCount ?? 0) >= 1) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "This ticket has already been reopened once. You cannot reopen it again.");
    }
    ticket.status = support_interface_1.TicketStatus.open;
    ticket.reopenCount = (ticket.reopenCount ?? 0) + 1;
    await ticket.save();
    await notification_service_1.NotificationServices.createForStaff(notification_interface_1.NotifType.support_ticket_reply, "Ticket Reopened", `User reopened ticket: ${ticket.subject}`, `/admin/support/${ticketId}`);
    return ticket;
};
const getMyTickets = async (userId, query) => {
    const queryBuilder = new QueryBuilder_1.QueryBuilder(support_model_1.SupportTicket.find({ user: userId }), query);
    const tickets = await queryBuilder.filter().sort().paginate().build();
    const meta = await queryBuilder.getMeta();
    return { data: tickets, meta };
};
const getAllTickets = async (query) => {
    const queryBuilder = new QueryBuilder_1.QueryBuilder(support_model_1.SupportTicket.find().populate("user", "name email avatar"), query);
    const tickets = await queryBuilder
        .search(["subject"])
        .filter()
        .sort()
        .paginate()
        .build();
    const meta = await queryBuilder.getMeta();
    return { data: tickets, meta };
};
/**
 * Fetches a thread. Regular users may only open their own ticket; admins may
 * open any. The ownership check happens here rather than in a route guard
 * because the answer depends on the document, not just the role.
 */
const getTicket = async (ticketId, userId, role) => {
    const ticket = await support_model_1.SupportTicket.findById(ticketId).populate("user", "name email avatar");
    if (!ticket)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Ticket not found");
    const isStaff = role === user_interface_1.UserRole.admin || role === user_interface_1.UserRole.super_admin;
    if (!isStaff && String(ticket.user._id ?? ticket.user) !== userId) {
        throw new AppError_1.default(http_status_1.default.FORBIDDEN, "You are not authorized");
    }
    const messages = await support_model_1.SupportTicketMessage.find({ ticket: ticketId })
        .populate("sender", "name email avatar role")
        .sort({ createdAt: 1 });
    return { ticket, messages };
};
/**
 * Appends to a thread.
 *
 * `isAdmin` is derived from the sender's role at send time and stored on the
 * message, so a user later promoted to admin does not retroactively turn their
 * old messages into staff replies.
 *
 * A staff reply moves the ticket to `answered` and notifies the owner in real
 * time; a user reply reopens an answered ticket, so a follow-up question does
 * not sit unnoticed in a resolved queue.
 */
const addMessage = async (ticketId, senderId, role, message) => {
    const ticket = await support_model_1.SupportTicket.findById(ticketId);
    if (!ticket)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Ticket not found");
    const isStaff = role === user_interface_1.UserRole.admin || role === user_interface_1.UserRole.super_admin;
    if (!isStaff && String(ticket.user) !== senderId) {
        throw new AppError_1.default(http_status_1.default.FORBIDDEN, "You are not authorized");
    }
    if (ticket.status === support_interface_1.TicketStatus.closed) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "This ticket is closed. Open a new ticket to continue.");
    }
    const created = await support_model_1.SupportTicketMessage.create({
        ticket: ticketId,
        sender: senderId,
        isAdmin: isStaff,
        message,
    });
    ticket.status = isStaff ? support_interface_1.TicketStatus.answered : support_interface_1.TicketStatus.open;
    await ticket.save();
    if (isStaff) {
        await notification_service_1.NotificationServices.create(ticket.user, notification_interface_1.NotifType.support, "Support replied to your ticket", ticket.subject, `/user-dashboard/support/${ticketId}`);
    }
    else {
        // A user reply reopens the ticket, so the staff queue has to hear about it
        // — otherwise a follow-up question sits unread in an "answered" thread.
        await notification_service_1.NotificationServices.createForStaff(notification_interface_1.NotifType.support_ticket_reply, "User replied to a ticket", ticket.subject, `/admin/support/${ticketId}`);
    }
    return created;
};
const updateStatus = async (ticketId, status) => {
    const ticket = await support_model_1.SupportTicket.findByIdAndUpdate(ticketId, { status }, { returnDocument: "after", runValidators: true });
    if (!ticket)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Ticket not found");
    if (status === support_interface_1.TicketStatus.resolved) {
        await notification_service_1.NotificationServices.create(ticket.user, notification_interface_1.NotifType.support, "Your support ticket was resolved", ticket.subject);
    }
    return ticket;
};
exports.SupportServices = {
    createTicket,
    reopenTicket,
    getMyTickets,
    getAllTickets,
    getTicket,
    addMessage,
    updateStatus,
};
//# sourceMappingURL=support.service.js.map