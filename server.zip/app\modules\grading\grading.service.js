"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GradingServices = void 0;
const http_status_1 = __importDefault(require("http-status"));
const constants_1 = require("../../constants");
const index_1 = require("../../config/index");
const redis_config_1 = require("../../config/redis.config");
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const index_2 = require("../../services/grading/index");
const QueryBuilder_1 = require("../../utils/QueryBuilder");
const logger_1 = require("../../utils/logger");
const analysis_interface_1 = require("../analysis/analysis.interface");
const analysis_model_1 = require("../analysis/analysis.model");
const card_model_1 = require("../card/card.model");
const credit_service_1 = require("../credit/credit.service");
const grading_pdf_1 = require("./grading.pdf");
const notification_interface_1 = require("../notification/notification.interface");
const notification_service_1 = require("../notification/notification.service");
const user_interface_1 = require("../user/user.interface");
const grading_model_1 = require("./grading.model");
/** Cache key includes the model version, so a model upgrade re-grades rather
 *  than serving stale results produced by a different model. */
const cacheKey = (imageSetHash, modelVersion) => `${constants_1.REDIS_KEYS.gradingResult}${modelVersion}:${imageSetHash}`;
const readCache = async (key) => {
    try {
        const hit = await redis_config_1.redisClient.get(key);
        return hit ? JSON.parse(hit) : null;
    }
    catch (error) {
        // A cache outage must not block grading — it costs consistency for this one
        // request, which is strictly better than refusing to grade at all.
        logger_1.logger.error("Grading cache read failed", { key, error });
        return null;
    }
};
const writeCache = async (key, value) => {
    try {
        // No TTL: the consistency guarantee is "the same images always produce the
        // same grade", which an expiring key would quietly break.
        await redis_config_1.redisClient.set(key, JSON.stringify(value));
    }
    catch (error) {
        logger_1.logger.error("Grading cache write failed", { key, error });
    }
};
/**
 * Grades a confirmed analysis.
 *
 * The repeatability invariant lives here, not in the model: identical image sets
 * resolve to the same `imageSetHash`, hit the cache, and replay the original
 * scores. The provider is called at most once per distinct image set.
 */
const gradeAnalysis = async (userId, analysisId) => {
    const analysis = await analysis_model_1.CardAnalysis.findOne({
        _id: analysisId,
        user: userId,
    });
    if (!analysis)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Analysis not found");
    // Hard gate #3: no confirmation, no grade.
    if (!analysis.confirmedCard) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Confirm the card match before grading.");
    }
    // A canceled or failed scan has already had its credits returned. Grading it
    // now would hand out a report nobody paid for.
    if (analysis.status === analysis_interface_1.AnalysisStatus.canceled ||
        analysis.status === analysis_interface_1.AnalysisStatus.failed) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "This scan was canceled and its credits refunded. Start a new scan to grade this card.");
    }
    if (analysis.status === analysis_interface_1.AnalysisStatus.graded) {
        const existing = await grading_model_1.GradingReport.findOne({
            analysis: analysis._id,
        }).populate("card");
        if (existing)
            return existing;
    }
    const images = await analysis_model_1.AnalysisImage.find({ analysis: analysis._id }).sort({
        side: 1,
        slotIndex: 1,
    });
    if (images.length === 0) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "This scan has no images.");
    }
    const card = await card_model_1.Card.findById(analysis.confirmedCard);
    const key = cacheKey(analysis.imageSetHash, index_1.configs.GRADING.model_version);
    let result = await readCache(key);
    if (!result) {
        try {
            const fresh = await index_2.GradingProvider.grade({
                imageUrls: images.map((i) => i.imageUrl),
                cardName: card?.name,
                cardSet: card?.setExpansion,
            });
            result = fresh;
            await writeCache(key, fresh);
        }
        catch (error) {
            // The scan was paid for at identification, but the invariant the credits
            // express is "10 credits per finished report" — and this one produced
            // none. Refund here rather than in the cancel path, because only here is
            // it certain the model never returned: a cancel racing an in-flight
            // grade could otherwise refund a scan that is about to succeed.
            analysis.status = analysis_interface_1.AnalysisStatus.failed;
            await analysis.save();
            try {
                await credit_service_1.CreditServices.refundScan(userId, analysis._id);
            }
            catch (refundError) {
                // Never mask the grading failure with a refund failure, but never lose
                // it either — the sweeper does not cover confirmed scans, so an
                // unlogged failure here is credits silently gone.
                logger_1.logger.error("Failed to refund credits after a failed grade", {
                    analysisId: String(analysis._id),
                    userId,
                    error: refundError,
                });
            }
            throw error;
        }
    }
    // Server-derived, from the stored analysis and the model's confidence. The
    // request body is never consulted.
    const pixelVerified = index_2.GradingProvider.isPixelVerified(analysis.source, result.confidence);
    const report = await grading_model_1.GradingReport.create({
        analysis: analysis._id,
        user: userId,
        card: analysis.confirmedCard,
        grade: result.grade,
        gradeLabel: result.gradeLabel,
        scoreSurface: result.scoreSurface,
        scoreCorners: result.scoreCorners,
        scoreEdges: result.scoreEdges,
        scoreCentering: result.scoreCentering,
        confidence: result.confidence,
        reasoning: result.reasoning,
        imageQuality: result.imageQuality,
        centering: result.centering,
        detectedDefects: result.detectedDefects,
        pixelVerified,
        modelVersion: result.modelVersion,
        rawOutput: result.raw,
    });
    analysis.status = analysis_interface_1.AnalysisStatus.graded;
    await analysis.save();
    await notification_service_1.NotificationServices.create(userId, notification_interface_1.NotifType.grade_ready, "Your grading report is ready", `${card?.name ?? "Your card"} graded ${result.grade} (${result.gradeLabel}).`);
    // Populated on the way out: the result screen shows the card's name, number,
    // and set alongside the grade, and a bare ObjectId would leave it with
    // nothing to render but the grade band.
    return report.populate("card");
};
const getMyReports = async (userId, query) => {
    const queryBuilder = new QueryBuilder_1.QueryBuilder(grading_model_1.GradingReport.find({ user: userId }).populate("card"), query);
    const reports = await queryBuilder.filter().sort().paginate().build();
    const meta = await queryBuilder.getMeta();
    return { data: reports, meta };
};
/** Admins may read any report; users only their own. */
const getReport = async (reportId, userId, role) => {
    const report = await grading_model_1.GradingReport.findById(reportId)
        .populate("card")
        .populate("analysis");
    if (!report)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Report not found");
    const isStaff = role === user_interface_1.UserRole.admin || role === user_interface_1.UserRole.super_admin;
    if (!isStaff && String(report.user) !== userId) {
        throw new AppError_1.default(http_status_1.default.FORBIDDEN, "You are not authorized");
    }
    return report;
};
const getAllReports = async (query) => {
    const queryBuilder = new QueryBuilder_1.QueryBuilder(grading_model_1.GradingReport.find().populate("card").populate("user", "name email"), query);
    const reports = await queryBuilder.filter().sort().paginate().build();
    const meta = await queryBuilder.getMeta();
    return { data: reports, meta };
};
/**
 * Resolves the Pixel ID printed on a slab to a PUBLIC, view-only summary.
 *
 * This is what the band's QR code points at, so it is deliberately
 * unauthenticated — anyone handed the physical slab can check that the grade on
 * it was really issued by us. That makes the shape of the response the whole
 * security boundary:
 *
 *   • It is a fixed projection, never the report document. The raw model
 *     output, the reasoning, the analysis, and the owner's email are all
 *     training/internal data and must not appear here.
 *   • It exposes the owner's `username` — the public handle already printed on
 *     the band beside their avatar — and never the email behind it.
 *   • It answers only for an exact Pixel ID. There is no listing endpoint, so
 *     the ids cannot be enumerated without the slabs.
 *
 * Widening this projection is a privacy decision, not a formatting one.
 */
const verifyByPixelId = async (rawPixelId) => {
    // The printed form is `PG-` + the last 10 hex chars of the report id,
    // upper-cased. Accept it with or without the prefix and in any case.
    const suffix = rawPixelId
        .trim()
        .replace(/^PG-/i, "")
        .toLowerCase();
    if (!/^[0-9a-f]{10}$/.test(suffix)) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "That is not a valid Pixel ID.");
    }
    // The id is a SUFFIX of the ObjectId, so the full id can't be reconstructed —
    // the last 10 of the 24 hex characters have to be matched server-side.
    const matches = await grading_model_1.GradingReport.find({
        $expr: {
            $eq: [{ $substrCP: [{ $toString: "$_id" }, 14, 10] }, suffix],
        },
    })
        .populate("card")
        .populate("user", "username avatar")
        .limit(2);
    if (matches.length === 0) {
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "No graded card matches that Pixel ID.");
    }
    // 10 hex characters make this effectively impossible, but returning an
    // arbitrary one of two reports would be a wrong answer presented as a
    // verification. Refuse instead.
    if (matches.length > 1) {
        logger_1.logger.error("Pixel ID collision", { suffix });
        throw new AppError_1.default(http_status_1.default.CONFLICT, "That Pixel ID is ambiguous. Please contact support.");
    }
    const report = matches[0];
    const card = report.card;
    const owner = report.user;
    // `timestamps: true` on the schema; IGradingReport doesn't declare them.
    const { createdAt } = report;
    return {
        pixelId: `PG-${suffix.toUpperCase()}`,
        grade: report.grade,
        gradeLabel: report.gradeLabel,
        confidence: report.confidence,
        pixelVerified: report.pixelVerified,
        scores: {
            surface: report.scoreSurface,
            corners: report.scoreCorners,
            edges: report.scoreEdges,
            centering: report.scoreCentering,
        },
        card: {
            name: card?.name,
            setExpansion: card?.setExpansion,
            cardNumber: card?.cardNumber,
            rarity: card?.rarity,
            language: card?.language,
            releaseYear: card?.releaseYear,
            officialImageUrl: card?.officialImageUrl,
        },
        owner: {
            username: owner?.username,
            avatarUrl: owner?.avatar?.url,
        },
        gradedAt: createdAt,
        modelVersion: report.modelVersion,
    };
};
/** Whether this user's plan gets a clean PDF or a watermarked one. */
const shouldWatermark = async (userId) => {
    const plan = await credit_service_1.CreditServices.resolvePlan(userId);
    return plan.watermarkReports;
};
/**
 * Renders the report as a PDF, watermarked per the OWNER's plan — not the
 * requester's, so an admin downloading a Free user's report sees exactly what
 * that user would. Rendered fresh on every download rather than cached: the
 * watermark must track the owner's current plan, and a stored file would
 * fossilise whichever plan they had when it was first generated.
 */
const getReportPdf = async (reportId, userId, role) => {
    const report = await getReport(reportId, userId, role);
    const watermark = await shouldWatermark(String(report.user));
    const card = report.card;
    const pdf = await (0, grading_pdf_1.buildReportPdf)(report, card ?? {}, watermark);
    return { pdf, reportId: String(report._id) };
};
exports.GradingServices = {
    gradeAnalysis,
    getMyReports,
    getReport,
    getAllReports,
    shouldWatermark,
    getReportPdf,
    verifyByPixelId,
};
//# sourceMappingURL=grading.service.js.map