"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const stripe_service_1 = require("../../services/stripe.service");
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const subscription_service_1 = require("./subscription.service");
const createCheckout = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await subscription_service_1.SubscriptionServices.createCheckoutSession(userId, req.body.planId, req.body.interval);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Checkout session created successfully!",
        data: result,
    });
});
/**
 * Stripe webhook.
 *
 * Requires the raw body — see the express.raw mount in app.ts. A 2xx is
 * returned even for events we do not handle, otherwise Stripe retries them
 * forever.
 */
const webhook = (0, catchAsync_1.default)(async (req, res) => {
    const signature = req.headers["stripe-signature"];
    if (typeof signature !== "string") {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Missing stripe-signature header");
    }
    const event = (0, stripe_service_1.constructWebhookEvent)(req.body, signature);
    const result = await subscription_service_1.SubscriptionServices.handleWebhookEvent(event);
    res.status(http_status_1.default.OK).json({ received: true, ...result });
});
const cancel = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await subscription_service_1.SubscriptionServices.cancelSubscription(userId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Subscription will end at the close of the current billing period.",
        data: result,
    });
});
const getMySubscription = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await subscription_service_1.SubscriptionServices.getMySubscription(userId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Subscription retrieved successfully!",
        data: result,
    });
});
const listSubscribers = (0, catchAsync_1.default)(async (req, res) => {
    const result = await subscription_service_1.SubscriptionServices.listSubscribers(req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Subscribers retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getSubscriberStats = (0, catchAsync_1.default)(async (_req, res) => {
    const result = await subscription_service_1.SubscriptionServices.getSubscriberStats();
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Subscription stats retrieved successfully!",
        data: result,
    });
});
exports.SubscriptionControllers = {
    createCheckout,
    listSubscribers,
    getSubscriberStats,
    webhook,
    cancel,
    getMySubscription,
};
//# sourceMappingURL=subscription.controller.js.map