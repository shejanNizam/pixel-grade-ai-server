"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlabOrderControllers = void 0;
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const slabOrder_service_1 = require("./slabOrder.service");
const createOrder = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await slabOrder_service_1.SlabOrderServices.createOrder(userId, req.body);
    (0, sendResponse_1.default)(res, {
        statusCode: 201,
        success: true,
        message: "Physical slab order placed successfully!",
        data: result,
    });
});
const getMyOrders = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await slabOrder_service_1.SlabOrderServices.getMyOrders(userId, req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: 200,
        success: true,
        message: "Fetched slab orders successfully",
        data: result.data,
        meta: result.meta,
    });
});
const getAllOrders = (0, catchAsync_1.default)(async (req, res) => {
    const result = await slabOrder_service_1.SlabOrderServices.getAllOrders({
        page: req.query.page ? Number(req.query.page) : undefined,
        limit: req.query.limit ? Number(req.query.limit) : undefined,
        status: req.query.status,
    });
    (0, sendResponse_1.default)(res, {
        statusCode: 200,
        success: true,
        message: "Fetched all slab orders successfully",
        data: result.data,
        meta: result.meta,
    });
});
const updateOrderStatus = (0, catchAsync_1.default)(async (req, res) => {
    const { id } = req.params;
    const result = await slabOrder_service_1.SlabOrderServices.updateOrderStatus(id, req.body);
    (0, sendResponse_1.default)(res, {
        statusCode: 200,
        success: true,
        message: "Order status updated successfully",
        data: result,
    });
});
exports.SlabOrderControllers = {
    createOrder,
    getMyOrders,
    getAllOrders,
    updateOrderStatus,
};
//# sourceMappingURL=slabOrder.controller.js.map