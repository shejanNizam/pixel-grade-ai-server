"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.globalErrorHandler = void 0;
const index_1 = require("../config/index");
const cloudinary_config_1 = require("../config/cloudinary.config");
const logger_1 = require("../utils/logger");
const AppError_1 = __importDefault(require("../errorHelpers/AppError"));
const handleCastError_1 = require("../helpers/handleCastError");
const handlerDuplicateError_1 = require("../helpers/handlerDuplicateError");
const handlerValidationError_1 = require("../helpers/handlerValidationError");
const handlerZodError_1 = require("../helpers/handlerZodError");
const swallowError = (_err) => undefined;
const globalErrorHandler = async (err, req, res, _next) => {
    if (index_1.configs.node_env === "development") {
        logger_1.logger.error(err);
    }
    // Delete any files uploaded to Cloudinary if the request failed
    try {
        if (req.file?.path) {
            await (0, cloudinary_config_1.deleteFromCloudinary)(req.file.path).catch(swallowError);
        }
        if (req.files) {
            const files = Array.isArray(req.files)
                ? req.files
                : Object.values(req.files).flat();
            const validFiles = files.filter((f) => Boolean(f && typeof f.path === "string" && f.path.trim().length > 0));
            await Promise.all(validFiles.map((f) => (0, cloudinary_config_1.deleteFromCloudinary)(f.path).catch(swallowError)));
        }
    }
    catch (cleanupErr) {
        logger_1.logger.error("Error during Cloudinary file cleanup in globalErrorHandler:", cleanupErr);
    }
    let errorSources = [];
    let statusCode = 500;
    let message = "Something went wrong!";
    if (err.code === 11000) {
        const simplified = (0, handlerDuplicateError_1.handlerDuplicateError)(err);
        statusCode = simplified.statusCode;
        message = simplified.message;
    }
    else if (err.name === "CastError") {
        const simplified = (0, handleCastError_1.handleCastError)(err);
        statusCode = simplified.statusCode;
        message = simplified.message;
    }
    else if (err.name === "ZodError") {
        const simplified = (0, handlerZodError_1.handlerZodError)(err);
        statusCode = simplified.statusCode;
        message = simplified.message;
        errorSources = simplified.errorSources;
    }
    else if (err.name === "ValidationError") {
        const simplified = (0, handlerValidationError_1.handlerValidationError)(err);
        statusCode = simplified.statusCode;
        message = simplified.message;
        errorSources = simplified.errorSources;
    }
    else if (err instanceof AppError_1.default) {
        statusCode = err.statusCode;
        message = err.message;
    }
    else if (err instanceof Error) {
        message = err.message;
    }
    const response = { success: false, message, errorSources };
    if (index_1.configs.node_env === "development") {
        response.err = err;
        response.stack = err.stack;
    }
    res.status(statusCode).json(response);
};
exports.globalErrorHandler = globalErrorHandler;
//# sourceMappingURL=globalErrorHandler.js.map