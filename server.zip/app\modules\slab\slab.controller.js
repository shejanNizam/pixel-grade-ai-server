"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlabControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const constants_1 = require("../../constants");
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const slab_service_1 = require("./slab.service");
const createLabel = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await slab_service_1.SlabServices.createLabel(userId, req.body.reportId, req.body.styleId ?? constants_1.SLAB_STYLES[0]);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.CREATED,
        success: true,
        message: "Slab label generated successfully!",
        data: result,
    });
});
const regenerate = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await slab_service_1.SlabServices.regenerateBackground(userId, req.params.id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Four new artwork options generated successfully!",
        data: result,
    });
});
/** Switches the selected EXT. ART option. Costs nothing at the provider —
 *  all four were rendered when the batch was generated. */
const selectVariant = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await slab_service_1.SlabServices.selectVariant(userId, req.params.id, Number(req.body.variantIndex));
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Artwork selected successfully!",
        data: result,
    });
});
/** Streams the PNG directly — a guide preview is a transient render and is
 *  deliberately not persisted to Cloudinary. */
const preview = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const png = await slab_service_1.SlabServices.previewWithGuides(userId, req.params.id);
    res.setHeader("Content-Type", "image/png");
    res.setHeader("Cache-Control", "no-store");
    res.status(http_status_1.default.OK).send(png);
});
const getMyLabels = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await slab_service_1.SlabServices.getMyLabels(userId, req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Slab labels retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getLabel = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await slab_service_1.SlabServices.getLabel(userId, req.params.id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Slab label retrieved successfully!",
        data: result,
    });
});
const exportPrintSlab = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const format = req.query.format === "png" ? "png" : "pdf";
    const file = await slab_service_1.SlabServices.exportPrintSlab(userId, req.params.id, format);
    res.setHeader("Content-Type", file.mimeType);
    res.setHeader("Content-Disposition", `attachment; filename="slab_print_${req.params.id}.${file.extension}"`);
    res.status(http_status_1.default.OK).send(file.buffer);
});
const exportLabelOnly = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const format = req.query.format === "png" ? "png" : "pdf";
    const file = await slab_service_1.SlabServices.exportLabelOnly(userId, req.params.id, format);
    res.setHeader("Content-Type", file.mimeType);
    res.setHeader("Content-Disposition", `attachment; filename="label_only_${req.params.id}.${file.extension}"`);
    res.status(http_status_1.default.OK).send(file.buffer);
});
exports.SlabControllers = {
    createLabel,
    regenerate,
    selectVariant,
    preview,
    exportPrintSlab,
    exportLabelOnly,
    getMyLabels,
    getLabel,
};
//# sourceMappingURL=slab.controller.js.map