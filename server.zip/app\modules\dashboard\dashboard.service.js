"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardServices = void 0;
const mongoose_1 = require("mongoose");
const dateWindows_1 = require("../../utils/dateWindows");
const analysis_model_1 = require("../analysis/analysis.model");
const collection_model_1 = require("../collection/collection.model");
const collection_service_1 = require("../collection/collection.service");
const grading_model_1 = require("../grading/grading.model");
const slab_model_1 = require("../slab/slab.model");
const slab_interface_1 = require("../slab/slab.interface");
const subscription_service_1 = require("../subscription/subscription.service");
const transaction_service_1 = require("../transaction/transaction.service");
const user_model_1 = require("../user/user.model");
const card = (value, previous) => ({
    value: Number(value.toFixed(2)),
    delta: (0, dateWindows_1.percentChange)(value, previous),
});
/**
 * Admin landing page: four stat cards and MRR.
 *
 * Each delta compares against the same point — the start of this month — so the
 * four cards are talking about the same period rather than each picking its own.
 *
 * The `subscribedUsers` baseline is an approximation and worth understanding
 * before trusting it: subscriptions record their current status, not a status
 * history, so "how many were active a month ago" cannot be answered exactly.
 * Today's active count minus this month's signups is used instead, which
 * undercounts churn — someone who subscribed in March and cancelled last week
 * is absent from both numbers rather than showing as a loss. Fixing it properly
 * needs a status audit trail.
 */
const getAdminOverview = async () => {
    const thisMonth = (0, dateWindows_1.startOfMonth)(0);
    const lastMonth = (0, dateWindows_1.startOfMonth)(1);
    const [totalUsers, usersBeforeThisMonth, subscriberStats, allTimeEarnings, thisMonthEarnings, lastMonthEarnings, totalScans, scansBeforeThisMonth,] = await Promise.all([
        user_model_1.User.countDocuments({ isDeleted: false }),
        user_model_1.User.countDocuments({ isDeleted: false, createdAt: { $lt: thisMonth } }),
        subscription_service_1.SubscriptionServices.getSubscriberStats(),
        transaction_service_1.TransactionServices.getEarnings(),
        transaction_service_1.TransactionServices.getEarnings(thisMonth),
        transaction_service_1.TransactionServices.getEarnings(lastMonth, thisMonth),
        analysis_model_1.CardAnalysis.countDocuments({}),
        analysis_model_1.CardAnalysis.countDocuments({ createdAt: { $lt: thisMonth } }),
    ]);
    const { activeSubscriptions, newThisMonth, mrr } = subscriberStats;
    return {
        totalUsers: card(totalUsers, usersBeforeThisMonth),
        subscribedUsers: card(activeSubscriptions, activeSubscriptions - newThisMonth),
        totalScans: card(totalScans, scansBeforeThisMonth),
        // The card shows lifetime revenue; the delta compares this month's take
        // against last month's, which is the number that actually moves.
        totalEarnings: {
            value: Number(allTimeEarnings.grossRevenue.toFixed(2)),
            delta: (0, dateWindows_1.percentChange)(thisMonthEarnings.grossRevenue, lastMonthEarnings.grossRevenue),
        },
        mrr,
    };
};
/**
 * User landing page: five stat cards.
 *
 * Collection value comes from the same series the trend chart plots, so the
 * headline figure and the chart's last point can never disagree.
 */
const getUserOverview = async (userId) => {
    const user = new mongoose_1.Types.ObjectId(userId);
    const thisMonth = (0, dateWindows_1.startOfMonth)(0);
    const [valueSeries, summary, cardsBeforeThisMonth, slabsOrdered, slabsBeforeThisMonth, totalScans, scansBeforeThisMonth, gradeThisMonth, gradeLastMonth,] = await Promise.all([
        collection_service_1.CollectionServices.getValueOverTime(userId, 2),
        collection_service_1.CollectionServices.getSummary(userId),
        collection_model_1.CollectionItem.aggregate([
            { $match: { user, addedAt: { $lt: thisMonth } } },
            { $group: { _id: null, total: { $sum: "$quantity" } } },
        ]),
        // Cancelled orders are not "ordered" — counting them would inflate the
        // figure with slabs the user explicitly backed out of.
        slab_model_1.SlabOrder.countDocuments({
            user,
            status: { $ne: slab_interface_1.SlabOrderStatus.canceled },
        }),
        slab_model_1.SlabOrder.countDocuments({
            user,
            status: { $ne: slab_interface_1.SlabOrderStatus.canceled },
            createdAt: { $lt: thisMonth },
        }),
        analysis_model_1.CardAnalysis.countDocuments({ user }),
        analysis_model_1.CardAnalysis.countDocuments({ user, createdAt: { $lt: thisMonth } }),
        grading_model_1.GradingReport.aggregate([
            { $match: { user, createdAt: { $gte: thisMonth } } },
            { $group: { _id: null, avg: { $avg: "$grade" } } },
        ]),
        grading_model_1.GradingReport.aggregate([
            {
                $match: {
                    user,
                    createdAt: { $gte: (0, dateWindows_1.startOfMonth)(1), $lt: thisMonth },
                },
            },
            { $group: { _id: null, avg: { $avg: "$grade" } } },
        ]),
    ]);
    // getValueOverTime always returns one entry per requested month, so with
    // months=2 these are last month and this month respectively.
    const previousValue = valueSeries[0]?.value ?? 0;
    const currentValue = valueSeries[valueSeries.length - 1]?.value ?? 0;
    return {
        collectionValue: card(currentValue, previousValue),
        cardsInCollection: card(summary.totalCards, cardsBeforeThisMonth[0]?.total ?? 0),
        slabsOrdered: card(slabsOrdered, slabsBeforeThisMonth),
        totalScans: card(totalScans, scansBeforeThisMonth),
        averageGrade: summary.averageGrade === null
            ? null
            : {
                value: summary.averageGrade,
                // Compares the grades awarded this month against last month's, not
                // the lifetime average against itself — the latter barely moves
                // once a collection is established and would read as flat forever.
                delta: (0, dateWindows_1.percentChange)(gradeThisMonth[0]?.avg ?? 0, gradeLastMonth[0]?.avg ?? 0),
            },
    };
};
exports.DashboardServices = {
    getAdminOverview,
    getUserOverview,
};
//# sourceMappingURL=dashboard.service.js.map