"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditLedger = exports.creditLedgerSchema = exports.CreditWallet = exports.creditWalletSchema = void 0;
const mongoose_1 = require("mongoose");
const credit_interface_1 = require("./credit.interface");
exports.creditWalletSchema = new mongoose_1.Schema({
    user: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "User",
        required: true,
        unique: true,
    },
    balance: { type: Number, default: 0, min: 0 },
    isUnlimited: { type: Boolean, default: false },
    periodStart: { type: Date },
    periodEnd: { type: Date },
    lastDailyGrantAt: { type: Date },
}, {
    timestamps: true,
    versionKey: false,
});
exports.CreditWallet = (0, mongoose_1.model)("CreditWallet", exports.creditWalletSchema);
exports.creditLedgerSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
    amount: { type: Number, required: true },
    reason: {
        type: String,
        enum: Object.values(credit_interface_1.CreditReason),
        required: true,
    },
    analysis: { type: mongoose_1.Schema.Types.ObjectId, ref: "CardAnalysis" },
    balanceAfter: { type: Number, required: true },
    meta: { type: mongoose_1.Schema.Types.Mixed },
}, {
    timestamps: true,
    versionKey: false,
});
// Retained indefinitely for audit and admin analytics — never pruned.
exports.creditLedgerSchema.index({ user: 1, createdAt: -1 });
/**
 * One debit and at most one refund per scan, enforced by the database.
 *
 * The service checks before refunding, but a check-then-write cannot survive
 * two concurrent cancels (a user closing the dialog at the same moment the
 * sweeper picks the scan up). This index makes the second write fail outright,
 * so a scan can never be refunded twice and mint credits.
 */
exports.creditLedgerSchema.index({ analysis: 1, reason: 1 }, {
    unique: true,
    partialFilterExpression: { analysis: { $exists: true } },
});
exports.CreditLedger = (0, mongoose_1.model)("CreditLedger", exports.creditLedgerSchema);
//# sourceMappingURL=credit.model.js.map