"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.seedAdmin = void 0;
const bcrypt_1 = __importDefault(require("bcrypt"));
const index_1 = require("../config/index");
const auth_identity_model_1 = require("../modules/auth_identity/auth_identity.model");
const user_interface_1 = require("../modules/user/user.interface");
const user_model_1 = require("../modules/user/user.model");
const logger_1 = require("./logger");
const seedAdmin = async () => {
    try {
        const exists = await user_model_1.User.findOne({ email: index_1.configs.admin_email });
        if (exists) {
            logger_1.logger.info("Admin already exists");
            return;
        }
        logger_1.logger.info("Creating Admin...");
        const hashedPassword = await bcrypt_1.default.hash(index_1.configs.admin_password, Number(index_1.configs.bcrypt_salt_round));
        const payload = {
            name: "Admin",
            role: user_interface_1.UserRole.admin,
            email: index_1.configs.admin_email,
            password: hashedPassword,
            isEmailVerified: true,
            status: "active",
            isDeleted: false,
        };
        const admin = await user_model_1.User.create(payload);
        await auth_identity_model_1.AuthIdentity.create({
            userId: admin._id,
            provider: "local",
            providerId: index_1.configs.admin_email,
        });
        logger_1.logger.info("Admin created successfully.");
    }
    catch (error) {
        logger_1.logger.error("Failed to seed admin", { error });
    }
};
exports.seedAdmin = seedAdmin;
//# sourceMappingURL=seedAdmin.js.map