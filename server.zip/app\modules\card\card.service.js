"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CardServices = void 0;
const http_status_1 = __importDefault(require("http-status"));
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const QueryBuilder_1 = require("../../utils/QueryBuilder");
const card_model_1 = require("./card.model");
/**
 * The catalogue is read-only over HTTP. Rows are written by the identification
 * pipeline, never by a client — there is deliberately no create, update, or
 * delete endpoint, since a hand-edited card would corrupt the pricing history
 * and every collection entry pointing at it.
 */
const getAllCards = async (query) => {
    const queryBuilder = new QueryBuilder_1.QueryBuilder(card_model_1.Card.find(), query);
    const cards = await queryBuilder
        .search(["name", "setExpansion", "cardNumber"])
        .filter()
        .sort()
        .paginate()
        .build();
    const meta = await queryBuilder.getMeta();
    return { data: cards, meta };
};
const getSingleCard = async (id) => {
    const card = await card_model_1.Card.findById(id);
    if (!card)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Card not found");
    return card;
};
/** Upsert by the identification service's id. Used by the identification
 *  pipeline so a card seen twice updates in place rather than duplicating. */
const upsertByScrydexId = async (payload) => {
    if (!payload.scrydexCardId) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "scrydexCardId is required");
    }
    return card_model_1.Card.findOneAndUpdate({ scrydexCardId: payload.scrydexCardId }, { $set: payload }, { returnDocument: "after", upsert: true, runValidators: true });
};
/** Distinct set names, for the collection's "group by set" filter. */
const getSets = async () => {
    return card_model_1.Card.distinct("setExpansion");
};
exports.CardServices = {
    getAllCards,
    getSingleCard,
    upsertByScrydexId,
    getSets,
};
//# sourceMappingURL=card.service.js.map