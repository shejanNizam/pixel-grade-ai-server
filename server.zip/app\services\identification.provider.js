"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IdentificationProvider = void 0;
const http_status_1 = __importDefault(require("http-status"));
const AppError_1 = __importDefault(require("../errorHelpers/AppError"));
const scrydex_client_1 = require("./scrydex/scrydex.client");
const scrydex_games_1 = require("./scrydex/scrydex.games");
const scrydex_mapper_1 = require("./scrydex/scrydex.mapper");
const scrydex_mock_1 = require("./scrydex.mock");
/**
 * Credentials present. Note that this is NOT the same as "Vision will work".
 *
 * Vision is separately entitled: the client's Starter-tier credentials read the
 * catalogue and pricing fine but are rejected by `/vision/v1/cards/identify`
 * with `{"error":"You do not have access to this endpoint"}` (verified
 * 2026-07-31), even though Scrydex's pricing page lists Vision on every tier.
 * There is no endpoint that reports entitlement, so the only way to learn this
 * is to call and read the 401 body — which `toAppError` puts in the message
 * verbatim for exactly that reason.
 */
const isConfigured = () => scrydex_mock_1.ScrydexMock.visionEnabled() || (0, scrydex_client_1.isConfigured)();
/**
 * Identifies the card in a single image.
 *
 * Takes the whole set for signature compatibility but deliberately sends only
 * the first image — see the cost note in the file header.
 */
const identify = async (imageUrls, game) => {
    if (scrydex_mock_1.ScrydexMock.visionEnabled())
        return scrydex_mock_1.ScrydexMock.identify(game);
    if (!imageUrls.length) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "No image to identify.");
    }
    const games = [(0, scrydex_games_1.requireVisionSlug)(game)];
    const maxAttempts = Math.min(imageUrls.length, 3);
    let lastResult = { candidates: [] };
    for (let i = 0; i < maxAttempts; i++) {
        const imageUrl = imageUrls[i];
        try {
            const payload = await (0, scrydex_client_1.request)("/vision/v1/cards/identify", {
                method: "POST",
                body: { image_url: imageUrl, games },
                vision: true,
                operation: "Card identification",
            });
            const analysis = payload.data?.analysis;
            const candidates = (0, scrydex_mapper_1.toIdentifiedCards)(payload.data?.matches ?? [], game, analysis?.language_code);
            const graded = analysis?.graded_details;
            lastResult = {
                candidates,
                languageCode: analysis?.language_code,
                gradedDetails: graded?.company
                    ? {
                        company: graded.company,
                        gradeLabel: graded.grade_label,
                        gradeNumber: graded.grade_number,
                        year: graded.year,
                        cert: graded.cert,
                    }
                    : undefined,
            };
            if (candidates.length > 0) {
                return lastResult;
            }
        }
        catch (err) {
            if (i === maxAttempts - 1 && lastResult.candidates.length === 0) {
                throw err;
            }
        }
    }
    return lastResult;
};
exports.IdentificationProvider = {
    identify,
    isConfigured,
};
//# sourceMappingURL=identification.provider.js.map