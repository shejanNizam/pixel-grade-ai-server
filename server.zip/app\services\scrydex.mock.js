"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScrydexMock = void 0;
const crypto_1 = __importDefault(require("crypto"));
const index_1 = require("../config/index");
const card_interface_1 = require("../modules/card/card.interface");
const price_interface_1 = require("../modules/price/price.interface");
const logger_1 = require("../utils/logger");
/**
 * ⚠️ DEV-ONLY SCRYDEX MOCK — identification + pricing.
 *
 * Exists so frontend integration of the scan flow and the price tracker can
 * proceed without live vendor access.
 *
 * DOUBLE-GATED: the `MOCK_SCRYDEX` env flag AND `NODE_ENV=development` — the
 * NODE_ENV half is enforced inside config/index.ts, so neither gate below can
 * be true in production no matter what the env file says.
 *
 * ⚠️ The two halves are now SEPARATE, and that is not tidiness — it reflects
 * what the client's credentials actually do (2026-07-31):
 *
 *   - Pricing and the catalogue work. `MOCK_SCRYDEX=true` there would replace
 *     real market data with fabricated numbers, which is strictly worse.
 *   - Vision returns 401 "You do not have access to this endpoint". Until
 *     Scrydex enables it for the team, dev has no way to run a scan end to end.
 *
 * Hence `MOCK_SCRYDEX=vision`: fake identification, real prices. A single
 * all-or-nothing flag would force a choice between a working scan flow and a
 * working price tracker.
 *
 * Every fabricated record is marked: card ids carry a `mock-` prefix. If one
 * ever shows up outside a dev database, that prefix is the tell.
 *
 * CLAUDE.md forbids stubs that fabricate plausible data precisely because
 * they flow through confirmation into permanent reports. This mock is the
 * sanctioned exception: loud, explicitly opted into, dev-only, and marked.
 */
/** Identification is mocked (`MOCK_SCRYDEX=true` or `=vision`). */
const visionEnabled = () => index_1.configs.SCRYDEX.mock_vision;
/** Pricing is mocked (`MOCK_SCRYDEX=true` only). */
const pricingEnabled = () => index_1.configs.SCRYDEX.mock_pricing;
/** True when anything at all is mocked. Used by boot-time warnings. */
const enabled = () => visionEnabled() || pricingEnabled();
/** Logged once per boot path, so a dev seeing fake candidates knows why. */
let announced = false;
const announce = () => {
    if (announced)
        return;
    announced = true;
    const mocked = [
        visionEnabled() ? "identification" : null,
        pricingEnabled() ? "pricing" : null,
    ]
        .filter(Boolean)
        .join(" and ");
    logger_1.logger.warn(`⚠️ MOCK_SCRYDEX is active — ${mocked} returns fabricated dev data`);
};
/**
 * The marker that reaches the SCREEN, not just the database.
 *
 * The `mock-` id prefix marks fabricated rows for developers, but nobody
 * reviewing the app sees an id — they see a card name. On 2026-08-01 the client
 * scanned a card, was shown these three cards, and reported Scrydex as broken;
 * they had no way to tell placeholder data from a real (wrong) match. The
 * suffix below makes that unmistakable on the confirmation screen itself.
 *
 * Do not remove it to make a demo look tidier. Unlabelled fake data on a screen
 * that also shows real grades is how a placeholder gets mistaken for a defect —
 * or worse, for a result.
 */
const SAMPLE_SUFFIX = " (SAMPLE DATA — Scrydex Vision not connected)";
// Real, well-known cards with stable public images (Pokémon TCG API CDN), so
// the confirmation screen renders realistically. Ids are mock-prefixed.
const MOCK_CANDIDATES = [
    {
        scrydexCardId: "mock-base1-4",
        name: "Charizard",
        game: card_interface_1.CardGame.pokemon,
        language: "English",
        releaseYear: 1999,
        setExpansion: "Base Set",
        cardNumber: "4/102",
        rarity: "Holo Rare",
        officialImageUrl: "https://images.pokemontcg.io/base1/4_hires.png",
        // Scrydex's real scale is ~0.7–1.3+ and unbounded — mimic it faithfully
        // so nobody renders it as a percentage during integration.
        matchScore: 1.12,
    },
    {
        scrydexCardId: "mock-base1-58",
        name: "Pikachu",
        game: card_interface_1.CardGame.pokemon,
        language: "English",
        releaseYear: 1999,
        setExpansion: "Base Set",
        cardNumber: "58/102",
        rarity: "Common",
        officialImageUrl: "https://images.pokemontcg.io/base1/58_hires.png",
        matchScore: 0.94,
    },
    {
        scrydexCardId: "mock-base1-2",
        name: "Blastoise",
        game: card_interface_1.CardGame.pokemon,
        language: "English",
        releaseYear: 1999,
        setExpansion: "Base Set",
        cardNumber: "2/102",
        rarity: "Holo Rare",
        officialImageUrl: "https://images.pokemontcg.io/base1/2_hires.png",
        matchScore: 0.81,
    },
];
const identify = (game) => {
    announce();
    return {
        // The suffix is applied HERE rather than baked into MOCK_CANDIDATES so the
        // underlying fixture stays a clean card record — and so the label cannot be
        // lost by anything that reads the fixture directly.
        candidates: MOCK_CANDIDATES.map((c) => ({
            ...c,
            game,
            name: `${c.name}${SAMPLE_SUFFIX}`,
        })),
        languageCode: "en",
    };
};
/**
 * Deterministic pseudo-market price: a stable per-card base plus a daily
 * drift, so repeated daily refreshes build a history that actually moves —
 * which is what the sparklines and change-percent columns need to demo.
 */
const getPrice = (scrydexCardId) => {
    announce();
    const hash = crypto_1.default.createHash("sha256").update(scrydexCardId).digest();
    const base = 15 + (hash.readUInt16BE(0) % 385); // $15–$400 per card, stable
    // Day-indexed drift: ±8% swing over a ~2-week cycle plus small daily noise.
    const day = Math.floor(Date.now() / 86_400_000);
    const salt = hash.readUInt16BE(2);
    const cycle = Math.sin((day + salt) / 4.5) * 0.08;
    const noise = (((salt ^ day) % 21) - 10) / 500; // ±2%
    const price = Number((base * (1 + cycle + noise)).toFixed(2));
    return {
        price,
        currency: "USD",
        source: price_interface_1.PriceSource.scrydex,
        capturedAt: new Date(),
        // Mirrors the real provider, which only ever returns raw on the current
        // plan — a mock that omitted the basis would let a UI that forgets to
        // render it pass in dev and break invariant #9 in production.
        basis: card_interface_1.PriceBasis.raw,
        condition: "NM",
    };
};
exports.ScrydexMock = {
    enabled,
    visionEnabled,
    pricingEnabled,
    identify,
    getPrice,
};
//# sourceMappingURL=scrydex.mock.js.map