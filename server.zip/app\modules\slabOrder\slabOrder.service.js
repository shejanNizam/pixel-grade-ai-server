"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlabOrderServices = void 0;
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const slab_model_1 = require("../slab/slab.model");
const slabOrder_model_1 = require("./slabOrder.model");
const sendEmail_1 = require("../../utils/sendEmail");
const logger_1 = require("../../utils/logger");
const PHYSICAL_SLAB_UNIT_PRICE = 9.99; // $9.99 sale price per custom physical slab
const USPS_SHIPPING_FEE = 4.99; // $4.99 USPS Flat Rate
const TAX_RATE = 0.08; // 8% Estimated Tax Rate
const createOrder = async (userId, payload) => {
    const targetId = payload.slabId || payload.slabLabel;
    const slab = await slab_model_1.SlabLabel.findById(targetId).populate("report");
    if (!slab) {
        throw new AppError_1.default(404, "Slab label not found");
    }
    const quantity = Math.max(1, payload.quantity ?? 1);
    const subtotal = Number((quantity * PHYSICAL_SLAB_UNIT_PRICE).toFixed(2));
    const shippingFee = payload.shippingFee ?? USPS_SHIPPING_FEE;
    const taxAmount = payload.taxAmount ?? Number((subtotal * TAX_RATE).toFixed(2));
    const totalAmount = Number((subtotal + shippingFee + taxAmount).toFixed(2));
    // Auto-generate USPS Tracking Number upon checkout submission
    const autoTrackingNumber = `USPS-9400111899${Math.floor(100000 + Math.random() * 900000)}`;
    const order = await slabOrder_model_1.SlabOrder.create({
        user: userId,
        slab: slab._id,
        slabLabel: slab._id,
        report: slab.report,
        shippingAddress: payload.shippingAddress,
        quantity,
        unitPrice: PHYSICAL_SLAB_UNIT_PRICE,
        subtotal,
        shippingFee,
        taxAmount,
        totalAmount,
        amount: totalAmount,
        shippingCarrier: "USPS",
        paymentStatus: "paid",
        orderStatus: "processing",
        status: "processing",
        trackingNumber: autoTrackingNumber,
        notes: "Order placed & shipping label created via USPS Standard Service.",
    });
    const populatedOrder = await order.populate([
        { path: "user", select: "name email phone username avatar" },
        {
            path: "slab",
            populate: { path: "report", populate: { path: "card" } },
        },
    ]);
    // Send automated HTML order & shipping confirmation email to customer
    const userObj = populatedOrder.user;
    const recipientEmail = userObj?.email;
    if (recipientEmail) {
        try {
            await (0, sendEmail_1.sendEmail)({
                to: recipientEmail,
                subject: `Order & Shipping Confirmation - #${String(populatedOrder._id).slice(-8).toUpperCase()}`,
                templateName: "orderConfirmation",
                templateData: {
                    name: populatedOrder.shippingAddress?.fullName || userObj?.name || "Collector",
                    orderId: String(populatedOrder._id),
                    quantity: populatedOrder.quantity,
                    subtotal: populatedOrder.subtotal?.toFixed(2),
                    shippingFee: populatedOrder.shippingFee?.toFixed(2),
                    taxAmount: populatedOrder.taxAmount?.toFixed(2),
                    totalAmount: populatedOrder.totalAmount?.toFixed(2),
                    trackingNumber: populatedOrder.trackingNumber,
                    shippingAddress: populatedOrder.shippingAddress,
                },
            });
        }
        catch (err) {
            logger_1.logger.error("Failed to send order confirmation email", { error: err });
        }
    }
    return populatedOrder;
};
const getMyOrders = async (userId, query) => {
    const page = Math.max(1, Number(query.page ?? 1));
    const limit = Math.max(1, Number(query.limit ?? 20));
    const skip = (page - 1) * limit;
    const [data, total] = await Promise.all([
        slabOrder_model_1.SlabOrder.find({ user: userId })
            .sort("-createdAt")
            .skip(skip)
            .limit(limit)
            .populate([
            { path: "user", select: "name email phone username avatar" },
            {
                path: "slab",
                populate: { path: "report", populate: { path: "card" } },
            },
        ]),
        slabOrder_model_1.SlabOrder.countDocuments({ user: userId }),
    ]);
    return {
        data,
        meta: {
            page,
            limit,
            total,
            totalPage: Math.ceil(total / limit) || 1,
        },
    };
};
const getAllOrders = async (query) => {
    const page = Math.max(1, Number(query.page ?? 1));
    const limit = Math.max(1, Number(query.limit ?? 20));
    const skip = (page - 1) * limit;
    const filter = {};
    if (query.status) {
        filter.orderStatus = query.status;
    }
    const [data, total] = await Promise.all([
        slabOrder_model_1.SlabOrder.find(filter)
            .sort("-createdAt")
            .skip(skip)
            .limit(limit)
            .populate([
            { path: "user", select: "name email phone username avatar" },
            {
                path: "slab",
                populate: { path: "report", populate: { path: "card" } },
            },
        ]),
        slabOrder_model_1.SlabOrder.countDocuments(filter),
    ]);
    return {
        data,
        meta: {
            page,
            limit,
            total,
            totalPage: Math.ceil(total / limit) || 1,
        },
    };
};
const updateOrderStatus = async (orderId, payload) => {
    const order = await slabOrder_model_1.SlabOrder.findById(orderId);
    if (!order) {
        throw new AppError_1.default(404, "Slab order not found");
    }
    if (payload.orderStatus) {
        order.orderStatus = payload.orderStatus;
    }
    if (payload.trackingNumber !== undefined) {
        order.trackingNumber = payload.trackingNumber;
    }
    if (payload.notes !== undefined) {
        order.notes = payload.notes;
    }
    await order.save();
    return await order.populate([
        { path: "user", select: "name email phone username avatar" },
        {
            path: "slab",
            populate: { path: "report", populate: { path: "card" } },
        },
    ]);
};
exports.SlabOrderServices = {
    createOrder,
    getMyOrders,
    getAllOrders,
    updateOrderStatus,
};
//# sourceMappingURL=slabOrder.service.js.map