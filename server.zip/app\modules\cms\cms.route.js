"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CmsRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const validateRequest_1 = __importDefault(require("../../middlewares/validateRequest"));
const user_interface_1 = require("../user/user.interface");
const cms_controller_1 = require("./cms.controller");
const cms_validation_1 = require("./cms.validation");
const router = (0, express_1.Router)();
/**
 * @swagger
 * /cms:
 *   get:
 *     tags: [CMS]
 *     summary: List all pages with their last editor (admin only)
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: All CMS pages
 *       403:
 *         description: Forbidden — insufficient role
 */
router.get("/", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), cms_controller_1.CmsControllers.getAllPages);
/**
 * @swagger
 * /cms/{slug}:
 *   get:
 *     tags: [CMS]
 *     summary: Get a public page (about, terms, or privacy)
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema:
 *           type: string
 *           enum: [about, terms, privacy]
 *     responses:
 *       200:
 *         description: Page content
 *       400:
 *         description: Unknown slug
 *       404:
 *         description: Page not found
 *   patch:
 *     tags: [CMS]
 *     summary: Edit a page (admin only)
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema:
 *           type: string
 *           enum: [about, terms, privacy]
 *     responses:
 *       200:
 *         description: Page updated
 *       403:
 *         description: Forbidden — insufficient role
 */
router.get("/:slug", cms_controller_1.CmsControllers.getPage);
router.patch("/:slug", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), (0, validateRequest_1.default)(cms_validation_1.updateCmsPageZodSchema), cms_controller_1.CmsControllers.updatePage);
exports.CmsRoutes = router;
//# sourceMappingURL=cms.route.js.map