"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CollectionRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const validateRequest_1 = __importDefault(require("../../middlewares/validateRequest"));
const user_interface_1 = require("../user/user.interface");
const collection_controller_1 = require("./collection.controller");
const collection_validation_1 = require("./collection.validation");
const router = (0, express_1.Router)();
const anyUser = Object.values(user_interface_1.UserRole);
// NOTE: no plan gate here yet — whether Free gets collection access, and any
// size cap, is unresolved (docs/OPEN-QUESTIONS.md #5).
/**
 * @swagger
 * /collection:
 *   get:
 *     tags: [Collection]
 *     summary: List the caller's collection
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: searchTerm
 *         schema:
 *           type: string
 *         description: Matches card name
 *       - in: query
 *         name: set
 *         schema:
 *           type: string
 *       - in: query
 *         name: rarity
 *         schema:
 *           type: string
 *       - in: query
 *         name: minGrade
 *         schema:
 *           type: number
 *       - in: query
 *         name: maxGrade
 *         schema:
 *           type: number
 *       - in: query
 *         name: minPrice
 *         schema:
 *           type: number
 *       - in: query
 *         name: maxPrice
 *         schema:
 *           type: number
 *       - in: query
 *         name: favorite
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [addedAt, price, grade, name]
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *     responses:
 *       200:
 *         description: Paginated collection entries with card and report joined
 *   post:
 *     tags: [Collection]
 *     summary: Add a card — scanned (via report) or manual (via card)
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       201:
 *         description: Added
 *       404:
 *         description: Card or report not found
 */
router.get("/", (0, checkAuth_1.checkAuth)(...anyUser), collection_controller_1.CollectionControllers.getMyCollection);
router.post("/", (0, checkAuth_1.checkAuth)(...anyUser), (0, validateRequest_1.default)(collection_validation_1.addCollectionItemZodSchema), collection_controller_1.CollectionControllers.addItem);
/**
 * @swagger
 * /collection/summary:
 *   get:
 *     tags: [Collection]
 *     summary: Total value, card count, and average grade
 *     description: >
 *       Quantity-weighted. Average grade covers graded entries only — manual
 *       entries without a report are excluded rather than counted as zero.
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Summary metrics
 */
router.get("/summary", (0, checkAuth_1.checkAuth)(...anyUser), collection_controller_1.CollectionControllers.getSummary);
/**
 * @swagger
 * /collection/value-over-time:
 *   get:
 *     tags: [Collection]
 *     summary: Collection value per calendar month
 *     description: >
 *       Backs the dashboard trend chart. Two documented approximations: today's
 *       quantity is applied to every month (entries keep no quantity history),
 *       and for months before a card's price history begins its earliest known
 *       price is carried backwards rather than reading as zero.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: months
 *         schema:
 *           type: integer
 *         description: How many months back, 1-36. Defaults to 12.
 *     responses:
 *       200:
 *         description: One point per month, oldest-first, as YYYY-MM plus value
 */
router.get("/value-over-time", (0, checkAuth_1.checkAuth)(...anyUser), collection_controller_1.CollectionControllers.getValueOverTime);
/**
 * @swagger
 * /collection/by-set:
 *   get:
 *     tags: [Collection]
 *     summary: Collection grouped by set/expansion
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Count and value per set
 */
router.get("/by-set", (0, checkAuth_1.checkAuth)(...anyUser), collection_controller_1.CollectionControllers.getBySet);
/**
 * @swagger
 * /collection/{id}:
 *   get:
 *     tags: [Collection]
 *     summary: Get one entry with its card and grading report
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Entry
 *       404:
 *         description: Not found, or not owned by the caller
 *   patch:
 *     tags: [Collection]
 *     summary: Update quantity, favourite flag, or external grade
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Updated
 *   delete:
 *     tags: [Collection]
 *     summary: Remove an entry
 *     description: >
 *       Removes the collection entry only. The grading report and its uploaded
 *       images are retained permanently as training data.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Removed
 */
router.get("/:id", (0, checkAuth_1.checkAuth)(...anyUser), collection_controller_1.CollectionControllers.getSingleItem);
router.patch("/:id", (0, checkAuth_1.checkAuth)(...anyUser), (0, validateRequest_1.default)(collection_validation_1.updateCollectionItemZodSchema), collection_controller_1.CollectionControllers.updateItem);
router.delete("/:id", (0, checkAuth_1.checkAuth)(...anyUser), collection_controller_1.CollectionControllers.removeItem);
exports.CollectionRoutes = router;
//# sourceMappingURL=collection.route.js.map