"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlanControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const plan_service_1 = require("./plan.service");
const getAllPlans = (0, catchAsync_1.default)(async (_req, res) => {
    const result = await plan_service_1.PlanServices.getAllPlans();
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Plans retrieved successfully!",
        data: result,
    });
});
const getAllPlansForAdmin = (0, catchAsync_1.default)(async (_req, res) => {
    const result = await plan_service_1.PlanServices.getAllPlansForAdmin();
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Plans retrieved successfully!",
        data: result,
    });
});
const getSinglePlan = (0, catchAsync_1.default)(async (req, res) => {
    const result = await plan_service_1.PlanServices.getSinglePlan(req.params.id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Plan retrieved successfully!",
        data: result,
    });
});
const updatePlan = (0, catchAsync_1.default)(async (req, res) => {
    const result = await plan_service_1.PlanServices.updatePlan(req.params.id, req.body);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Plan updated successfully!",
        data: result,
    });
});
exports.PlanControllers = {
    getAllPlans,
    getAllPlansForAdmin,
    getSinglePlan,
    updatePlan,
};
//# sourceMappingURL=plan.controller.js.map