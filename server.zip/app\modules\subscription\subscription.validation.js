"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCheckoutZodSchema = void 0;
const zod_1 = __importDefault(require("zod"));
const subscription_interface_1 = require("./subscription.interface");
/** Nothing about price or status is accepted — both are derived from the plan
 *  and from verified Stripe events. */
exports.createCheckoutZodSchema = zod_1.default.object({
    planId: zod_1.default
        .string()
        .regex(/^[0-9a-fA-F]{24}$/, { message: "Must be a valid ObjectId." }),
    interval: zod_1.default.enum(Object.values(subscription_interface_1.BillingInterval)),
});
//# sourceMappingURL=subscription.validation.js.map