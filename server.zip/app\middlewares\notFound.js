"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = notFound;
const http_status_1 = __importDefault(require("http-status"));
function notFound(req, res, next) {
    // return res.status(404).json({
    return res.status(http_status_1.default.NOT_FOUND).json({
        success: false,
        message: "API not found",
        error: "",
    });
}
//# sourceMappingURL=notFound.js.map