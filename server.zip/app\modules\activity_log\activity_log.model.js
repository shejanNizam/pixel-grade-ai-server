"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActivityLog = exports.activityLogSchema = void 0;
const mongoose_1 = require("mongoose");
const activity_log_interface_1 = require("./activity_log.interface");
exports.activityLogSchema = new mongoose_1.Schema({
    // Optional by design — a failed login has an IP but no user.
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User" },
    action: {
        type: String,
        enum: Object.values(activity_log_interface_1.ActivityAction),
        required: true,
    },
    meta: { type: mongoose_1.Schema.Types.Mixed },
    ipAddress: { type: String },
}, {
    timestamps: { createdAt: true, updatedAt: false },
    versionKey: false,
});
exports.activityLogSchema.index({ user: 1, createdAt: -1 });
exports.activityLogSchema.index({ action: 1, createdAt: -1 });
exports.activityLogSchema.index({ createdAt: -1 });
exports.ActivityLog = (0, mongoose_1.model)("ActivityLog", exports.activityLogSchema);
//# sourceMappingURL=activity_log.model.js.map