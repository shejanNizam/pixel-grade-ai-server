"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const card_interface_1 = require("../app/modules/card/card.interface");
const scrydex_games_1 = require("../app/services/scrydex/scrydex.games");
const scrydex_mapper_1 = require("../app/services/scrydex/scrydex.mapper");
/**
 * Scrydex mapping.
 *
 * The fixtures below are trimmed copies of real `api.scrydex.com` responses
 * captured on 2026-07-31, not invented shapes — including the parts that look
 * like mistakes. `base1-4`'s 1st Edition Shadowless printing really does report
 * $250 Near Mint and $10,000 Moderately Played, and that pair is the whole
 * reason condition ranking beats "take the biggest number".
 *
 * These assertions guard money on a user's dashboard. A wrong variant or a
 * wrong condition does not throw — it prints a plausible figure that is off by
 * an order of magnitude, which nobody notices until a collector prices a sale
 * off it.
 */
/** Trimmed from GET /pokemon/v1/cards?q=name:charizard expansion.id:base1 */
const charizard = {
    id: "base1-4",
    name: "Charizard",
    printed_number: "4/102",
    rarity: "Holo Rare",
    language: "English",
    images: [
        { type: "front", small: "s.png", medium: "m.png", large: "l.png" },
    ],
    expansion: { id: "base1", name: "Base Set", release_date: "1999/01/09" },
    variants: [
        {
            name: "firstEditionShadowlessHolofoil",
            prices: [
                { condition: "NM", type: "raw", market: 250.0, currency: "USD" },
                // Vendor noise: an MP copy priced 40× the NM copy.
                { condition: "MP", type: "raw", market: 10000.0, currency: "USD" },
                { condition: "DM", type: "raw", market: 4200.0, currency: "USD" },
            ],
        },
        {
            name: "jumbo",
            prices: [
                { condition: "NM", type: "raw", low: 500.0, market: 400.0, currency: "USD" },
            ],
        },
        {
            name: "unlimitedHolofoil",
            prices: [
                { condition: "NM", type: "raw", low: 919.49, market: 800.43, currency: "USD" },
                { condition: "LP", type: "raw", low: 510.0, market: 510.07, currency: "USD" },
            ],
        },
    ],
};
describe("Scrydex price selection", () => {
    it("prefers the variant Vision actually matched", () => {
        const quote = (0, scrydex_mapper_1.selectQuote)(charizard, {
            preferredVariant: "firstEditionShadowlessHolofoil",
        });
        expect(quote?.variantName).toBe("firstEditionShadowlessHolofoil");
        expect(quote?.price).toBe(250);
    });
    it("takes the best condition, not the biggest number", () => {
        // $10,000 MP sits in the same variant. Taking a max() would put it on the
        // user's dashboard; Near Mint is what "the price of this card" means.
        const quote = (0, scrydex_mapper_1.selectQuote)(charizard, {
            preferredVariant: "firstEditionShadowlessHolofoil",
        });
        expect(quote?.condition).toBe("NM");
        expect(quote?.price).toBe(250);
    });
    it("falls back to a standard printing, never a jumbo or metal replica", () => {
        // No variant known. `jumbo` is an A3 box-topper — a different object from
        // the card in the user's hand — so it must never win a fallback.
        const quote = (0, scrydex_mapper_1.selectQuote)(charizard);
        expect(quote?.variantName).toBe("unlimitedHolofoil");
    });
    it("matches variant names case- and punctuation-insensitively", () => {
        const quote = (0, scrydex_mapper_1.selectQuote)(charizard, {
            preferredVariant: "Unlimited Holofoil",
        });
        expect(quote?.variantName).toBe("unlimitedHolofoil");
    });
    it("labels every quote with its basis", () => {
        // CLAUDE.md invariant #9 — a figure without its basis is worse than none.
        const quote = (0, scrydex_mapper_1.selectQuote)(charizard);
        expect(quote?.basis).toBe(card_interface_1.PriceBasis.raw);
        expect(quote?.gradeRef).toBeUndefined();
    });
    describe("graded comps", () => {
        // Live since the Growth upgrade (2026-08-04) — Base Set alone returns
        // ~3,700 graded prices across PSA, CGC, BGS, SGC, TAG, ACE and others.
        // Still not wired to the UI: which grade to quote is an open client
        // decision (OPEN-QUESTIONS §C), so these pin the mapping, not the product.
        const gradedOnly = {
            id: "x",
            variants: [
                {
                    name: "normal",
                    prices: [
                        { type: "graded", company: "PSA", grade: "9", market: 900, currency: "USD" },
                        { type: "graded", company: "PSA", grade: "10", market: 2567.88, currency: "USD" },
                    ],
                },
            ],
        };
        it("reads as graded, with the company and grade attached", () => {
            const quote = (0, scrydex_mapper_1.selectQuote)(gradedOnly, { preferGraded: true });
            expect(quote?.basis).toBe(card_interface_1.PriceBasis.graded);
            expect(quote?.gradeRef).toBe("PSA 10");
            expect(quote?.price).toBe(2567.88);
        });
        it("prefers the benchmark grader over a higher grade from a minor one", () => {
            // Scrydex returns a long tail of graders. A BCCG 10 is not what anyone
            // means by "the graded price" — PSA sets the market and the rest trade
            // at a discount, so company outranks grade.
            const quote = (0, scrydex_mapper_1.selectQuote)({
                id: "x",
                variants: [
                    {
                        name: "normal",
                        prices: [
                            { type: "graded", company: "BCCG", grade: "10", market: 400, currency: "USD" },
                            { type: "graded", company: "TAG", grade: "10", market: 550, currency: "USD" },
                            { type: "graded", company: "PSA", grade: "9", market: 900, currency: "USD" },
                        ],
                    },
                ],
            }, { preferGraded: true });
            expect(quote?.gradeRef).toBe("PSA 9");
        });
        it("never silently substitutes a graded comp for a raw one", () => {
            // The whole point of invariant #9: the two differ by multiples. A card
            // whose basis flipped between refreshes would write market movement into
            // the price history that never happened. No raw price means no price.
            expect((0, scrydex_mapper_1.selectQuote)(gradedOnly)).toBeNull();
        });
    });
    it("ignores signed and misprinted comps", () => {
        // An autographed Charizard trades on its own market and is not evidence of
        // what an ordinary copy is worth.
        const quote = (0, scrydex_mapper_1.selectQuote)({
            id: "x",
            variants: [
                {
                    name: "normal",
                    prices: [
                        { condition: "NM", type: "raw", market: 9999, is_signed: true },
                        { condition: "NM", type: "raw", market: 8888, is_error: true },
                        { condition: "LP", type: "raw", market: 42, currency: "USD" },
                    ],
                },
            ],
        });
        expect(quote?.price).toBe(42);
    });
    it("prefers market over low, which the feed sometimes reports above it", () => {
        const quote = (0, scrydex_mapper_1.selectQuote)(charizard, {
            preferredVariant: "unlimitedHolofoil",
        });
        expect(quote?.price).toBe(800.43); // not the 919.49 `low`
    });
    it("returns null rather than a zero when a card has no quotable price", () => {
        // A sweep over a thousand cards must treat this as a skip, not a $0 write.
        expect((0, scrydex_mapper_1.selectQuote)({ id: "x", variants: [{ name: "normal", prices: [] }] })).toBeNull();
        expect((0, scrydex_mapper_1.selectQuote)({ id: "x", variants: [] })).toBeNull();
        expect((0, scrydex_mapper_1.selectQuote)(undefined)).toBeNull();
    });
});
describe("PSA graded ladder", () => {
    // Client 2026-08-06: "show both the raw card value and the PSA graded market
    // value". These guard the half of that which can silently mislead.
    const laddered = {
        id: "x",
        variants: [
            {
                name: "unlimitedHolofoil",
                prices: [
                    { condition: "NM", type: "raw", market: 800, currency: "USD" },
                    { type: "graded", company: "PSA", grade: "10", market: 12000, currency: "USD" },
                    { type: "graded", company: "PSA", grade: "9", market: 3000, currency: "USD" },
                    { type: "graded", company: "PSA", grade: "7", market: 900, currency: "USD" },
                    // Other graders are returned by Scrydex and must not leak into a
                    // ladder the UI labels "PSA".
                    { type: "graded", company: "CGC", grade: "10", market: 8000, currency: "USD" },
                    { type: "graded", company: "BGS", grade: "9.5", market: 6000, currency: "USD" },
                ],
            },
        ],
    };
    it("collects PSA comps only, cheapest rung first", () => {
        const ladder = (0, scrydex_mapper_1.selectGradedLadder)(laddered);
        expect(ladder.map((c) => c.grade)).toEqual(["7", "9", "10"]);
        expect(ladder.map((c) => c.price)).toEqual([900, 3000, 12000]);
    });
    it("reads the ladder off the same printing as the raw quote", () => {
        // A ladder from a different variant would put two unrelated markets side by
        // side on one report.
        const twoVariants = {
            id: "y",
            variants: [
                {
                    name: "jumbo",
                    prices: [
                        { type: "graded", company: "PSA", grade: "10", market: 50, currency: "USD" },
                    ],
                },
                {
                    name: "unlimitedHolofoil",
                    prices: [
                        { type: "graded", company: "PSA", grade: "10", market: 12000, currency: "USD" },
                    ],
                },
            ],
        };
        const ladder = (0, scrydex_mapper_1.selectGradedLadder)(twoVariants, {
            preferredVariant: "unlimitedHolofoil",
        });
        expect(ladder[0].price).toBe(12000);
    });
    it("prices a predicted grade at its own rung", () => {
        const ladder = (0, scrydex_mapper_1.selectGradedLadder)(laddered);
        expect((0, scrydex_mapper_1.pickGradedComp)(ladder, 9)?.price).toBe(3000);
        expect((0, scrydex_mapper_1.pickGradedComp)(ladder, 10)?.price).toBe(12000);
    });
    it("rounds DOWN to the next rung, never up", () => {
        // A card predicted 8.7 is not a PSA 9 — quoting the PSA 9 comp would price
        // a sale the card would not fetch. Erring low understates rather than
        // oversells.
        const ladder = (0, scrydex_mapper_1.selectGradedLadder)(laddered);
        expect((0, scrydex_mapper_1.pickGradedComp)(ladder, 8.7)?.grade).toBe("7");
        expect((0, scrydex_mapper_1.pickGradedComp)(ladder, 9.9)?.grade).toBe("9");
    });
    it("returns nothing when the grade is below the whole ladder", () => {
        // No comp beats a misleading one — a 3.0 card has no PSA market here.
        const ladder = (0, scrydex_mapper_1.selectGradedLadder)(laddered);
        expect((0, scrydex_mapper_1.pickGradedComp)(ladder, 3)).toBeNull();
        expect((0, scrydex_mapper_1.pickGradedComp)([], 9)).toBeNull();
    });
    it("is empty for a card with no graded comps at all", () => {
        // The state of every card while the client was on Starter. Consumers must
        // render without it.
        expect((0, scrydex_mapper_1.selectGradedLadder)({
            id: "z",
            variants: [{ name: "normal", prices: [{ condition: "NM", type: "raw", market: 5 }] }],
        })).toEqual([]);
    });
});
describe("Scrydex card mapping", () => {
    it("keeps the printed number, falling back to the internal one", () => {
        const [card] = (0, scrydex_mapper_1.toIdentifiedCards)([{ score: 1.12, variant: "unlimitedHolofoil", card: charizard }], card_interface_1.CardGame.pokemon);
        expect(card.cardNumber).toBe("4/102");
        // Modern and digital-only sets null `printed_number`.
        const [modern] = (0, scrydex_mapper_1.toIdentifiedCards)([{ score: 1, card: { id: "tcgp-B2b-9", number: "9", printed_number: null } }], card_interface_1.CardGame.pokemon);
        expect(modern.cardNumber).toBe("9");
    });
    it("carries the matched variant through to the catalogue", () => {
        // Without this the card is priced off a guessed printing forever after.
        const [card] = (0, scrydex_mapper_1.toIdentifiedCards)([{ score: 1.12, variant: "unlimitedHolofoil", card: charizard }], card_interface_1.CardGame.pokemon);
        expect(card.scrydexVariant).toBe("unlimitedHolofoil");
    });
    it("sorts candidates best-first and drops matches without an id", () => {
        const cards = (0, scrydex_mapper_1.toIdentifiedCards)([
            { score: 0.81, card: { id: "base1-2", name: "Blastoise" } },
            { score: 1.12, card: { id: "base1-4", name: "Charizard" } },
            // No id — cannot be upserted or confirmed against, so unusable.
            { score: 1.3, card: { name: "Ghost" } },
        ], card_interface_1.CardGame.pokemon);
        expect(cards.map((c) => c.scrydexCardId)).toEqual(["base1-4", "base1-2"]);
    });
    it("parses the vendor's slash-separated release dates", () => {
        expect((0, scrydex_mapper_1.parseYear)("1999/01/09")).toBe(1999);
        expect((0, scrydex_mapper_1.parseYear)("2026-03-25")).toBe(2026);
        expect((0, scrydex_mapper_1.parseYear)(undefined)).toBeUndefined();
        expect((0, scrydex_mapper_1.parseYear)("not a date")).toBeUndefined();
    });
    it("picks the large front image — the slab prints it at 300 DPI", () => {
        expect((0, scrydex_mapper_1.pickImageUrl)(charizard)).toBe("l.png");
        expect((0, scrydex_mapper_1.pickImageUrl)({ images: [{ type: "front", small: "s.png" }] })).toBe("s.png");
        expect((0, scrydex_mapper_1.pickImageUrl)({ images: [] })).toBeUndefined();
    });
});
describe("Scrydex game registry", () => {
    it("serves Pokémon", () => {
        expect((0, scrydex_games_1.requireGameSegment)(card_interface_1.CardGame.pokemon)).toBe("pokemon");
        expect((0, scrydex_games_1.requireVisionSlug)(card_interface_1.CardGame.pokemon)).toBe("pokemon");
    });
    it("refuses games Scrydex has no catalogue for, by name", () => {
        // /yugioh/v1/cards and /sports/v1/cards both 404 — shipping them needs a
        // second vendor, so the message must not read like a transient outage.
        expect(() => (0, scrydex_games_1.requireGameSegment)(card_interface_1.CardGame.yugioh)).toThrow(/not covered/);
        expect(() => (0, scrydex_games_1.requireGameSegment)(card_interface_1.CardGame.sports)).toThrow(/not covered/);
    });
    it("distinguishes 'not switched on' from 'no catalogue'", () => {
        // Magic is fully available at Scrydex, just not enabled for us — a
        // different fix, so a different message.
        expect(scrydex_games_1.SCRYDEX_GAMES[card_interface_1.CardGame.magic].pathSegment).toBe("magicthegathering");
        expect(() => (0, scrydex_games_1.requireGameSegment)(card_interface_1.CardGame.magic)).toThrow(/coming soon/i);
    });
});
//# sourceMappingURL=scrydexMapping.test.js.map