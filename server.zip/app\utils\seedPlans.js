"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.seedPlans = exports.grantAdminEnterpriseAccess = void 0;
const constants_1 = require("../constants");
const plan_interface_1 = require("../modules/plan/plan.interface");
const plan_model_1 = require("../modules/plan/plan.model");
const logger_1 = require("./logger");
/**
 * The four fixed tiers. Mirrors `pixel-grade-ai/src/config/plans.ts` — if you
 * change prices, credits, or features here, change them there too.
 *
 * `priceYearly` is the *effective monthly* rate on a yearly subscription; the
 * customer is charged that × 12 up front. Credits still refresh monthly.
 *
 * ⚠️ `creditAmount` is in CREDITS, but the client specifies plans in SCANS
 * (2026-08-10: Free 5/day, Collector 300/month, Pro 1,200/month, Enterprise
 * unlimited). Multiply by CREDITS_PER_SCAN. Pasting the scan count in here
 * fails silently — the plan still works, it just sells a fifth of what was
 * advertised.
 */
const planCatalog = [
    {
        name: plan_interface_1.PlanName.Free,
        tagline: "For trying it out",
        priceMonthly: 0,
        priceYearly: 0,
        creditAmount: constants_1.FREE_DAILY_CREDITS,
        creditInterval: plan_interface_1.CreditInterval.daily,
        pixelscope: false,
        priceTracking: false,
        watermarkReports: true,
        features: [
            "Standard scan (phone camera)",
            "Basic AI grading report",
            "Order custom slab labels",
            "No PixelScope",
            "No Pixel Verified badge",
        ],
        isActive: true,
    },
    {
        name: plan_interface_1.PlanName.Collector,
        tagline: "For active collectors",
        priceMonthly: 10,
        priceYearly: 8,
        // 600 scans/month = 3,000 credits
        creditAmount: 600 * constants_1.CREDITS_PER_SCAN,
        creditInterval: plan_interface_1.CreditInterval.monthly,
        pixelscope: true,
        priceTracking: true,
        watermarkReports: false,
        features: [
            "Standard & Advanced (PixelScope) scans",
            "Pixel Verified badge",
            "Full AI grading reports",
            "Unlimited report history",
            "Collection management",
            "Price tracking",
            "Order custom slab labels",
        ],
        isActive: true,
    },
    {
        name: plan_interface_1.PlanName.Pro,
        tagline: "For power users",
        priceMonthly: 25,
        priceYearly: 20,
        // 1,500 scans/month = 7,500 credits
        creditAmount: 1500 * constants_1.CREDITS_PER_SCAN,
        creditInterval: plan_interface_1.CreditInterval.monthly,
        pixelscope: true,
        priceTracking: true,
        watermarkReports: false,
        features: [
            "Everything in Collector",
            "Priority AI processing",
            "Bulk grading",
            "Advanced analytics",
            "Collection insights",
            "Early access to new AI features",
            "Priority support",
        ],
        isActive: true,
    },
    {
        name: plan_interface_1.PlanName.Enterprise,
        tagline: "For businesses & card shops",
        priceMonthly: 119,
        priceYearly: 99,
        // null = unlimited
        creditAmount: null,
        creditInterval: plan_interface_1.CreditInterval.monthly,
        pixelscope: true,
        priceTracking: true,
        watermarkReports: false,
        features: [
            "Everything in Pro",
            "Custom grading reports",
            "Team accounts",
            "Card Shop Dashboard",
            "API access (coming soon)",
            "Dedicated account manager",
            "Priority feature requests",
        ],
        isActive: true,
    },
];
const user_model_1 = require("../modules/user/user.model");
const subscription_model_1 = require("../modules/subscription/subscription.model");
const subscription_interface_1 = require("../modules/subscription/subscription.interface");
const grantAdminEnterpriseAccess = async () => {
    try {
        const adminEmails = ["admin@pixelgradeai.com", "superadmin@pixelgradeai.com"];
        const enterprisePlan = await plan_model_1.Plan.findOne({ name: plan_interface_1.PlanName.Enterprise });
        if (!enterprisePlan)
            return;
        for (const email of adminEmails) {
            const user = await user_model_1.User.findOne({ email });
            if (user) {
                const existingSub = await subscription_model_1.Subscription.findOne({ user: user._id });
                if (existingSub) {
                    existingSub.plan = enterprisePlan._id;
                    existingSub.status = subscription_interface_1.SubStatus.active;
                    await existingSub.save();
                }
                else {
                    await subscription_model_1.Subscription.create({
                        user: user._id,
                        plan: enterprisePlan._id,
                        status: subscription_interface_1.SubStatus.active,
                        interval: subscription_interface_1.BillingInterval.yearly,
                        currentPeriodEnd: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
                    });
                }
                logger_1.logger.info(`Granted Enterprise access to admin: ${email}`);
            }
        }
    }
    catch (error) {
        logger_1.logger.error("Failed to grant admin enterprise access", { error });
    }
};
exports.grantAdminEnterpriseAccess = grantAdminEnterpriseAccess;
/**
 * Inserts any missing tier and grants admin Enterprise access.
 */
const seedPlans = async () => {
    try {
        for (const plan of planCatalog) {
            const exists = await plan_model_1.Plan.findOne({ name: plan.name });
            if (exists) {
                if (exists.creditAmount !== plan.creditAmount) {
                    exists.creditAmount = plan.creditAmount;
                    await exists.save();
                    logger_1.logger.info(`Updated creditAmount for plan: ${plan.name}`);
                }
                continue;
            }
            await plan_model_1.Plan.create(plan);
            logger_1.logger.info(`Seeded plan: ${plan.name}`);
        }
        await (0, exports.grantAdminEnterpriseAccess)();
    }
    catch (error) {
        logger_1.logger.error("Failed to seed plans", { error });
    }
};
exports.seedPlans = seedPlans;
//# sourceMappingURL=seedPlans.js.map