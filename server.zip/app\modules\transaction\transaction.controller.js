"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const transaction_service_1 = require("./transaction.service");
const getMyTransactions = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await transaction_service_1.TransactionServices.getMyTransactions(userId, req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Billing history retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getAllTransactions = (0, catchAsync_1.default)(async (req, res) => {
    const result = await transaction_service_1.TransactionServices.getAllTransactions(req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Transactions retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getEarnings = (0, catchAsync_1.default)(async (req, res) => {
    const from = req.query.from ? new Date(String(req.query.from)) : undefined;
    const to = req.query.to ? new Date(String(req.query.to)) : undefined;
    const result = await transaction_service_1.TransactionServices.getEarnings(from, to);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Earnings retrieved successfully!",
        data: result,
    });
});
const getRevenueByMonth = (0, catchAsync_1.default)(async (req, res) => {
    const months = Number(req.query.months) || 12;
    const result = await transaction_service_1.TransactionServices.getRevenueByMonth(months);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Revenue breakdown retrieved successfully!",
        data: result,
    });
});
exports.TransactionControllers = {
    getMyTransactions,
    getAllTransactions,
    getEarnings,
    getRevenueByMonth,
};
//# sourceMappingURL=transaction.controller.js.map