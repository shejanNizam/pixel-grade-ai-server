"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GradingControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const grading_service_1 = require("./grading.service");
const gradeAnalysis = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await grading_service_1.GradingServices.gradeAnalysis(userId, req.params.analysisId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.CREATED,
        success: true,
        message: "Grading report generated successfully!",
        data: result,
    });
});
const getMyReports = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await grading_service_1.GradingServices.getMyReports(userId, req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Reports retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getReport = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId, role } = req.user;
    const result = await grading_service_1.GradingServices.getReport(req.params.id, userId, role);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Report retrieved successfully!",
        data: result,
    });
});
const getAllReports = (0, catchAsync_1.default)(async (req, res) => {
    const result = await grading_service_1.GradingServices.getAllReports(req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Reports retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
/** Streams PDF bytes, not the JSON envelope — this is a file download. */
const downloadReportPdf = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId, role } = req.user;
    const { pdf, reportId } = await grading_service_1.GradingServices.getReportPdf(req.params.id, userId, role);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="pixelgrade-report-${reportId}.pdf"`);
    // The watermark tracks the owner's current plan, so this must not be cached.
    res.setHeader("Cache-Control", "no-store");
    res.send(pdf);
});
/**
 * PUBLIC — no auth. This is what the slab's QR code resolves to, so a collector
 * holding the physical card can check the grade without an account. The service
 * returns a fixed view-only projection; see `verifyByPixelId`.
 */
const verifyPixelId = (0, catchAsync_1.default)(async (req, res) => {
    const result = await grading_service_1.GradingServices.verifyByPixelId(req.params.pixelId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Grading report verified successfully!",
        data: result,
    });
});
exports.GradingControllers = {
    gradeAnalysis,
    getMyReports,
    getReport,
    getAllReports,
    downloadReportPdf,
    verifyPixelId,
};
//# sourceMappingURL=grading.controller.js.map