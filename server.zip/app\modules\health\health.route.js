"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthRoutes = void 0;
const express_1 = require("express");
const health_controller_1 = require("./health.controller");
const router = (0, express_1.Router)();
// GET /health — readiness probe (checks DB + Redis)
router.get("/", health_controller_1.healthCheck);
// GET /health/live — liveness probe (just "am I running?")
router.get("/live", health_controller_1.liveness);
exports.HealthRoutes = router;
//# sourceMappingURL=health.route.js.map