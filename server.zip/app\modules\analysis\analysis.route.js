"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnalysisRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const checkEntitlement_1 = require("../../middlewares/checkEntitlement");
const validateRequest_1 = __importDefault(require("../../middlewares/validateRequest"));
const user_interface_1 = require("../user/user.interface");
const analysis_controller_1 = require("./analysis.controller");
const analysis_validation_1 = require("./analysis.validation");
const router = (0, express_1.Router)();
const anyUser = Object.values(user_interface_1.UserRole);
/**
 * @swagger
 * /analysis:
 *   post:
 *     tags: [Analysis]
 *     summary: Start a scan — upload images and identify the card
 *     description: >
 *       Costs 10 credits per finished report. The guard order is deliberate:
 *       authenticate, validate the body, check the PixelScope entitlement, then
 *       check the credit balance. The actual debit happens inside the service
 *       after the images are stored, and is refunded if identification fails,
 *       if the scan is canceled, or if it is left unconfirmed past the
 *       abandoned-scan timeout.
 *       Send a unique `clientRequestId` to make the call idempotent — a retry
 *       carrying the same key returns the original scan instead of charging
 *       again.
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       201:
 *         description: Scan started; status is `awaiting_confirmation`
 *       402:
 *         description: Not enough credits
 *       403:
 *         description: PixelScope requires the Collector plan or above
 *       503:
 *         description: Identification service is not configured
 *   get:
 *     tags: [Analysis]
 *     summary: List the caller's scans
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Paginated scans
 */
router.post("/", (0, checkAuth_1.checkAuth)(...anyUser), (0, validateRequest_1.default)(analysis_validation_1.createAnalysisZodSchema), checkEntitlement_1.requirePixelScope, checkEntitlement_1.requireCredits, analysis_controller_1.AnalysisControllers.createAnalysis);
router.get("/", (0, checkAuth_1.checkAuth)(...anyUser), analysis_controller_1.AnalysisControllers.getMyAnalyses);
/**
 * @swagger
 * /analysis/{id}:
 *   get:
 *     tags: [Analysis]
 *     summary: Get a scan with its images and candidate matches
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Scan, images, and ranked candidates
 *       404:
 *         description: Not found, or not owned by the caller
 */
router.get("/:id", (0, checkAuth_1.checkAuth)(...anyUser), analysis_controller_1.AnalysisControllers.getAnalysis);
/**
 * @swagger
 * /analysis/{id}/confirm:
 *   patch:
 *     tags: [Analysis]
 *     summary: Confirm which card the images actually show
 *     description: >
 *       The mandatory identification gate. Grading and slab generation refuse to
 *       run until this succeeds. The chosen card must be one of the candidates
 *       the system offered. Picking a card other than the suggested best match
 *       records `wasCorrected`, which is retained permanently as training data.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Confirmed; status is `confirmed`
 *       400:
 *         description: Not awaiting confirmation, or card was not a candidate
 */
router.patch("/:id/confirm", (0, checkAuth_1.checkAuth)(...anyUser), (0, validateRequest_1.default)(analysis_validation_1.confirmCardZodSchema), analysis_controller_1.AnalysisControllers.confirmCard);
/**
 * @swagger
 * /analysis/{id}/cancel:
 *   patch:
 *     tags: [Analysis]
 *     summary: Abandon a scan and get the credits back
 *     description: >
 *       Ends a scan that never became a report — typically the user closing the
 *       confirmation dialog without picking a card — and refunds its 10 credits.
 *       Idempotent: cancelling an already-ended scan succeeds without refunding
 *       twice. A graded scan cannot be canceled. Scans left unconfirmed are
 *       swept and refunded automatically after the timeout, so this endpoint is
 *       the fast path, not the only one.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Canceled; credits returned
 *       400:
 *         description: Already graded
 *       404:
 *         description: Not found, or not owned by the caller
 */
router.patch("/:id/cancel", (0, checkAuth_1.checkAuth)(...anyUser), analysis_controller_1.AnalysisControllers.cancelAnalysis);
exports.AnalysisRoutes = router;
//# sourceMappingURL=analysis.route.js.map