"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PricingProvider = void 0;
const card_interface_1 = require("../modules/card/card.interface");
const price_interface_1 = require("../modules/price/price.interface");
const logger_1 = require("../utils/logger");
const scrydex_catalogue_1 = require("./scrydex/scrydex.catalogue");
const scrydex_client_1 = require("./scrydex/scrydex.client");
const scrydex_mapper_1 = require("./scrydex/scrydex.mapper");
const scrydex_mock_1 = require("./scrydex.mock");
/**
 * Pricing is configured exactly when Scrydex is.
 *
 * There is no separate PRICING_API_KEY any more — Scrydex covers pricing on the
 * same credentials, and the old check meant the daily sweep silently skipped
 * every run while the unused key sat empty.
 */
const isConfigured = () => scrydex_mock_1.ScrydexMock.pricingEnabled() || (0, scrydex_client_1.isConfigured)();
/** One card. Prefer `getPrices` for anything that loops. */
const getPrice = async (scrydexCardId, game = card_interface_1.CardGame.pokemon, preferredVariant) => {
    if (scrydex_mock_1.ScrydexMock.pricingEnabled())
        return scrydex_mock_1.ScrydexMock.getPrice(scrydexCardId);
    const card = await scrydex_catalogue_1.ScrydexCatalogue.getCardWithPrices(game, scrydexCardId);
    if (!card)
        return null;
    const selected = (0, scrydex_mapper_1.selectQuote)(card, { preferredVariant });
    if (!selected)
        return null;
    return {
        price: selected.price,
        currency: selected.currency,
        source: price_interface_1.PriceSource.scrydex,
        capturedAt: new Date(),
        basis: selected.basis,
        gradeRef: selected.gradeRef,
        condition: selected.condition,
        variantName: selected.variantName,
        // Read off the SAME printing the raw quote came from — see
        // selectGradedLadder. Free: the comps are already in this response.
        gradedLadder: (0, scrydex_mapper_1.selectGradedLadder)(card, {
            preferredVariant: selected.variantName ?? preferredVariant,
        }),
    };
};
/**
 * Many cards in one round trip — 100 per Scrydex credit instead of one.
 *
 * This is what keeps a daily sweep cheap: 1,000 cards costs 10 credits here
 * against 1,000 credits card-by-card — the difference between 0.6% and 60% of
 * the monthly Scrydex budget. Cards Scrydex has no price for are simply absent
 * from the returned map.
 */
const getPrices = async (cards) => {
    const quotes = new Map();
    if (cards.length === 0)
        return quotes;
    if (scrydex_mock_1.ScrydexMock.pricingEnabled()) {
        for (const card of cards) {
            quotes.set(card.scrydexCardId, scrydex_mock_1.ScrydexMock.getPrice(card.scrydexCardId));
        }
        return quotes;
    }
    // Scrydex's catalogues are per-game paths, so a mixed batch has to be split
    // by game before it can be batched by id.
    const byGame = new Map();
    for (const card of cards) {
        const bucket = byGame.get(card.game) ?? [];
        bucket.push(card);
        byGame.set(card.game, bucket);
    }
    const capturedAt = new Date();
    for (const [game, gameCards] of byGame) {
        let fetched;
        try {
            fetched = await scrydex_catalogue_1.ScrydexCatalogue.getCardsWithPrices(game, gameCards.map((card) => card.scrydexCardId));
        }
        catch (error) {
            // One game failing (an unsupported game slipped into the catalogue, a
            // transient 502) must not cost us the games that would have succeeded.
            logger_1.logger.error("Batch price lookup failed for a game", { game, error });
            continue;
        }
        for (const card of gameCards) {
            const vendorCard = fetched.get(card.scrydexCardId);
            if (!vendorCard)
                continue;
            const selected = (0, scrydex_mapper_1.selectQuote)(vendorCard, {
                preferredVariant: card.scrydexVariant,
            });
            if (!selected)
                continue;
            quotes.set(card.scrydexCardId, {
                price: selected.price,
                currency: selected.currency,
                source: price_interface_1.PriceSource.scrydex,
                // One timestamp for the whole sweep, so a batch lands as a single
                // column in the history rather than smeared across the minutes the
                // sweep took to run.
                capturedAt,
                basis: selected.basis,
                gradeRef: selected.gradeRef,
                condition: selected.condition,
                variantName: selected.variantName,
                gradedLadder: (0, scrydex_mapper_1.selectGradedLadder)(vendorCard, {
                    preferredVariant: selected.variantName ?? card.scrydexVariant,
                }),
            });
        }
    }
    return quotes;
};
/**
 * Past daily prices for one card, oldest first.
 *
 * Seeds a card's history the first time we see it so the price tracker draws a
 * real 30-day sparkline immediately, instead of a flat line that only becomes a
 * chart a month after launch. One credit, ~90 days — see PRICE_HISTORY_DAYS for
 * why it stops there rather than pulling a full year.
 *
 * Each day in the feed carries every variant/condition combination, so the same
 * `selectQuote` rules that pick today's price pick each historical day's — the
 * history and the current price must be measuring the same printing or the
 * change percentages are fiction.
 */
const getPriceHistory = async (scrydexCardId, game = card_interface_1.CardGame.pokemon, options = {}) => {
    if (scrydex_mock_1.ScrydexMock.pricingEnabled())
        return [];
    const points = await scrydex_catalogue_1.ScrydexCatalogue.getPriceHistory(game, scrydexCardId, options.days, options.pages);
    const quotes = [];
    for (const point of points) {
        if (!point.date || !point.prices?.length)
            continue;
        // The history endpoint flattens variants into each price row, so rebuild
        // the variant grouping `selectQuote` expects rather than duplicating its
        // condition and basis rules here.
        const grouped = new Map();
        for (const price of point.prices) {
            const key = price.variant ?? "";
            const bucket = grouped.get(key) ?? [];
            bucket.push(price);
            grouped.set(key, bucket);
        }
        const selected = (0, scrydex_mapper_1.selectQuote)({
            variants: [...grouped].map(([name, prices]) => ({ name, prices })),
        }, { preferredVariant: options.preferredVariant });
        if (!selected)
            continue;
        // Scrydex dates are "YYYY/MM/DD". Parsed as UTC midnight so a point does
        // not drift across a day boundary depending on server timezone.
        const capturedAt = new Date(`${point.date.replace(/\//g, "-")}T00:00:00Z`);
        if (Number.isNaN(capturedAt.getTime()))
            continue;
        quotes.push({
            price: selected.price,
            currency: selected.currency,
            source: price_interface_1.PriceSource.scrydex,
            capturedAt,
            basis: selected.basis,
            gradeRef: selected.gradeRef,
            condition: selected.condition,
            variantName: selected.variantName,
        });
    }
    return quotes.sort((a, b) => a.capturedAt.getTime() - b.capturedAt.getTime());
};
exports.PricingProvider = {
    getPrice,
    getPrices,
    getPriceHistory,
    isConfigured,
};
//# sourceMappingURL=pricing.provider.js.map