"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkResetToken = exports.checkAuth = void 0;
const http_status_1 = __importDefault(require("http-status"));
const index_1 = require("../config/index");
const AppError_1 = __importDefault(require("../errorHelpers/AppError"));
const user_model_1 = require("../modules/user/user.model");
const jwt_1 = require("../utils/jwt");
const checkAuth = (...authRole) => async (req, _res, next) => {
    try {
        const accessToken = req.headers.authorization?.split(" ")[1];
        if (!accessToken) {
            throw new AppError_1.default(http_status_1.default.UNAUTHORIZED, "Please provide a valid access token.");
        }
        let verifiedToken;
        try {
            verifiedToken = (0, jwt_1.verifyToken)(accessToken, index_1.configs.jwt_access_secret);
        }
        catch {
            throw new AppError_1.default(http_status_1.default.UNAUTHORIZED, "Invalid or expired access token.");
        }
        const user = await user_model_1.User.findOne({ email: verifiedToken.email });
        if (!user) {
            throw new AppError_1.default(http_status_1.default.UNAUTHORIZED, "User does not exist");
        }
        if (!user.isEmailVerified) {
            throw new AppError_1.default(http_status_1.default.FORBIDDEN, "Email is not verified");
        }
        if (user.status === "blocked") {
            throw new AppError_1.default(http_status_1.default.FORBIDDEN, "Account is blocked");
        }
        if (user.isDeleted) {
            throw new AppError_1.default(http_status_1.default.FORBIDDEN, "Account has been deleted");
        }
        if (!authRole.includes(verifiedToken.role)) {
            throw new AppError_1.default(http_status_1.default.FORBIDDEN, "You are not permitted to access this route.");
        }
        req.user = verifiedToken;
        next();
    }
    catch (error) {
        next(error);
    }
};
exports.checkAuth = checkAuth;
const checkResetToken = async (req, _res, next) => {
    try {
        const token = req.headers.authorization?.split(" ")[1];
        if (!token) {
            throw new AppError_1.default(http_status_1.default.UNAUTHORIZED, "No reset token provided.");
        }
        const decoded = (0, jwt_1.verifyToken)(token, index_1.configs.jwt_reset_secret);
        req.user = decoded;
        next();
    }
    catch (error) {
        next(error);
    }
};
exports.checkResetToken = checkResetToken;
//# sourceMappingURL=checkAuth.js.map