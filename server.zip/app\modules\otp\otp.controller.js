"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OTPController = void 0;
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const otp_service_1 = require("./otp.service");
const sendOTP = (0, catchAsync_1.default)(async (req, res) => {
    const { email } = req.body;
    await otp_service_1.OTPService.sendOTP(email);
    (0, sendResponse_1.default)(res, {
        statusCode: 200,
        success: true,
        message: "OTP sent successfully",
        data: null,
    });
});
const verifyOTP = (0, catchAsync_1.default)(async (req, res) => {
    const { email, otp } = req.body;
    await otp_service_1.OTPService.verifyOTP(email, otp);
    (0, sendResponse_1.default)(res, {
        statusCode: 200,
        success: true,
        message: "OTP verified successfully",
        data: null,
    });
});
exports.OTPController = {
    sendOTP,
    verifyOTP,
};
//# sourceMappingURL=otp.controller.js.map