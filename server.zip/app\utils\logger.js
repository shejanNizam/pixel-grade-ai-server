"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const winston_1 = __importDefault(require("winston"));
const { combine, timestamp, errors, printf, json, colorize } = winston_1.default.format;
const devFormat = combine(colorize(), timestamp({ format: "YYYY-MM-DD HH:mm:ss" }), errors({ stack: true }), printf(({ timestamp: ts, level, message, stack, ...meta }) => {
    const metaStr = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : "";
    return `${ts} [${level}]: ${stack ?? message}${metaStr}`;
}));
const prodFormat = combine(timestamp(), errors({ stack: true }), json());
const isTest = process.env.NODE_ENV === "test";
const isProd = process.env.NODE_ENV === "production";
exports.logger = winston_1.default.createLogger({
    level: isProd ? "info" : "debug",
    format: isProd ? prodFormat : devFormat,
    transports: [
        new winston_1.default.transports.Console({ silent: isTest }),
        ...(isProd
            ? [
                new winston_1.default.transports.File({ filename: "logs/error.log", level: "error" }),
                new winston_1.default.transports.File({ filename: "logs/combined.log" }),
            ]
            : []),
    ],
});
//# sourceMappingURL=logger.js.map