"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OTPService = void 0;
const crypto_1 = __importDefault(require("crypto"));
const redis_config_1 = require("../../config/redis.config");
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const sendEmail_1 = require("../../utils/sendEmail");
const user_model_1 = require("../user/user.model");
const OTP_EXPIRATION = 2 * 60;
const OTP_MAX_ATTEMPTS = 5;
const OTP_LOCKOUT_WINDOW = 10 * 60;
const generateOtp = (length = 6) => {
    const otp = crypto_1.default.randomInt(10 ** (length - 1), 10 ** length);
    return otp;
};
const sendOTP = async (email) => {
    const user = await user_model_1.User.findOne({ email });
    if (!user) {
        throw new AppError_1.default(404, "User not found");
    }
    if (user.isEmailVerified) {
        throw new AppError_1.default(401, "You are already verified");
    }
    const otp = generateOtp();
    const redisKey = `otp:${email}`;
    const attemptsKey = `otp:attempts:${email}`;
    await Promise.all([
        redis_config_1.redisClient.set(redisKey, String(otp), {
            expiration: { type: "EX", value: OTP_EXPIRATION },
        }),
        redis_config_1.redisClient.del([attemptsKey]),
    ]);
    await (0, sendEmail_1.sendEmail)({
        to: email,
        subject: "Your OTP Code",
        templateName: "otp",
        templateData: { name: user.name, otp },
    });
};
const verifyOTP = async (email, otp) => {
    const user = await user_model_1.User.findOne({ email });
    if (!user) {
        throw new AppError_1.default(404, "User not found");
    }
    if (user.isEmailVerified) {
        throw new AppError_1.default(401, "You are already verified");
    }
    const redisKey = `otp:${email}`;
    const attemptsKey = `otp:attempts:${email}`;
    const attempts = await redis_config_1.redisClient.get(attemptsKey);
    if (Number(attempts) >= OTP_MAX_ATTEMPTS) {
        throw new AppError_1.default(429, "Too many failed attempts. Please request a new OTP.");
    }
    const savedOtp = await redis_config_1.redisClient.get(redisKey);
    if (!savedOtp) {
        throw new AppError_1.default(401, "OTP expired or not found. Please request a new one.");
    }
    if (savedOtp !== otp) {
        const newAttempts = await redis_config_1.redisClient.incr(attemptsKey);
        if (newAttempts === 1) {
            await redis_config_1.redisClient.expire(attemptsKey, OTP_LOCKOUT_WINDOW);
        }
        const remaining = OTP_MAX_ATTEMPTS - newAttempts;
        const msg = remaining > 0
            ? `Invalid OTP. ${remaining} attempt${remaining === 1 ? "" : "s"} remaining.`
            : "Too many failed attempts. Please request a new OTP.";
        throw new AppError_1.default(401, msg);
    }
    await Promise.all([
        user_model_1.User.updateOne({ email }, { isEmailVerified: true }, { runValidators: true }),
        redis_config_1.redisClient.del([redisKey]),
        redis_config_1.redisClient.del([attemptsKey]),
    ]);
};
exports.OTPService = {
    sendOTP,
    verifyOTP,
};
//# sourceMappingURL=otp.service.js.map