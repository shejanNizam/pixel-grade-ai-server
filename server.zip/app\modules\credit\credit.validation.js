"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminAdjustCreditsZodSchema = void 0;
const zod_1 = __importDefault(require("zod"));
/** There is deliberately no user-facing schema that grants credits. The only
 *  way credits enter a wallet is a scheduled grant, a refund, or this
 *  admin-guarded adjustment. */
exports.adminAdjustCreditsZodSchema = zod_1.default.object({
    amount: zod_1.default
        .number({ error: "amount must be a number" })
        .int({ message: "Adjustment must be a whole number." })
        .refine((n) => n !== 0, { message: "Adjustment cannot be zero." }),
    note: zod_1.default.string().max(280).optional(),
});
//# sourceMappingURL=credit.validation.js.map