"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CollectionControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const collection_service_1 = require("./collection.service");
const getMyCollection = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await collection_service_1.CollectionServices.getMyCollection(userId, req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Collection retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getSummary = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await collection_service_1.CollectionServices.getSummary(userId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Collection summary retrieved successfully!",
        data: result,
    });
});
const getValueOverTime = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await collection_service_1.CollectionServices.getValueOverTime(userId, Number(req.query.months) || 12);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Collection value over time retrieved successfully!",
        data: result,
    });
});
const getBySet = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await collection_service_1.CollectionServices.getBySet(userId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Collection by set retrieved successfully!",
        data: result,
    });
});
const addItem = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await collection_service_1.CollectionServices.addItem(userId, req.body);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.CREATED,
        success: true,
        message: "Card added to collection successfully!",
        data: result,
    });
});
const getSingleItem = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await collection_service_1.CollectionServices.getSingleItem(userId, req.params.id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Collection item retrieved successfully!",
        data: result,
    });
});
const updateItem = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await collection_service_1.CollectionServices.updateItem(userId, req.params.id, req.body);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Collection item updated successfully!",
        data: result,
    });
});
const removeItem = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    await collection_service_1.CollectionServices.removeItem(userId, req.params.id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Card removed from collection successfully!",
        data: null,
    });
});
exports.CollectionControllers = {
    getMyCollection,
    getSummary,
    getValueOverTime,
    getBySet,
    addItem,
    getSingleItem,
    updateItem,
    removeItem,
};
//# sourceMappingURL=collection.controller.js.map