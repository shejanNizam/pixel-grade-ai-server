"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.broadcastNotificationZodSchema = exports.updateNotificationSettingsZodSchema = void 0;
const zod_1 = __importDefault(require("zod"));
/** No create schema — ordinary notifications are minted server-side only, from
 *  platform events. The single exception is the admin broadcast below. */
exports.updateNotificationSettingsZodSchema = zod_1.default.object({
    inappEnabled: zod_1.default.boolean().optional(),
    emailGradeReady: zod_1.default.boolean().optional(),
    emailPriceAlert: zod_1.default.boolean().optional(),
    emailSubscription: zod_1.default.boolean().optional(),
    emailSupport: zod_1.default.boolean().optional(),
    /** Staff only. A non-staff account may store it, but nothing reads it —
     *  staff-audience notifications are never written to a customer. */
    emailAdminAlerts: zod_1.default.boolean().optional(),
});
/**
 * Admin announcement.
 *
 * Deliberately narrow: a title, an optional body, and an optional in-app path.
 * There is no `type` or `audience` field — both are fixed server-side to
 * `system`/`user`, so this route cannot be used to forge a "grade ready" or a
 * billing message, and cannot address the staff queue.
 */
exports.broadcastNotificationZodSchema = zod_1.default.object({
    title: zod_1.default
        .string({ error: "Title must be string" })
        .trim()
        .min(3, { message: "Title must be at least 3 characters long." })
        .max(120, { message: "Title cannot exceed 120 characters." }),
    body: zod_1.default
        .string({ error: "Body must be string" })
        .trim()
        .max(500, { message: "Body cannot exceed 500 characters." })
        .optional(),
    /** An in-app path, never an absolute URL — an announcement that can point at
     *  an external site is a phishing vector aimed at every user at once. */
    link: zod_1.default
        .string({ error: "Link must be string" })
        .trim()
        .regex(/^\/[\w\-/?=&#.]*$/, {
        message: "Link must be an in-app path beginning with /",
    })
        .max(200)
        .optional(),
});
//# sourceMappingURL=notification.validation.js.map