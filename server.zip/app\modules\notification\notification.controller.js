"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const notification_service_1 = require("./notification.service");
const getMyNotifications = (0, catchAsync_1.default)(async (req, res) => {
    // Role comes from the verified token, never from the query — `audience` is
    // authorised against it inside the service.
    const { _id: userId, role } = req.user;
    const result = await notification_service_1.NotificationServices.getMyNotifications(userId, role, req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Notifications retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getUnreadCount = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId, role } = req.user;
    const result = await notification_service_1.NotificationServices.getUnreadCount(userId, role, req.query.audience);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Unread count retrieved successfully!",
        data: result,
    });
});
const markAsRead = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await notification_service_1.NotificationServices.markAsRead(userId, req.params.id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Notification marked as read!",
        data: result,
    });
});
const markAllAsRead = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId, role } = req.user;
    const result = await notification_service_1.NotificationServices.markAllAsRead(userId, role, (req.query.audience ?? req.body?.audience));
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "All notifications marked as read!",
        data: result,
    });
});
const remove = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    await notification_service_1.NotificationServices.remove(userId, req.params.id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Notification deleted successfully!",
        data: null,
    });
});
const getSettings = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await notification_service_1.NotificationServices.getSettings(userId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Notification settings retrieved successfully!",
        data: result,
    });
});
const updateSettings = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await notification_service_1.NotificationServices.updateSettings(userId, req.body);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Notification settings updated successfully!",
        data: result,
    });
});
/** Admin announcement to every active customer. Guarded at the route. */
const broadcast = (0, catchAsync_1.default)(async (req, res) => {
    const result = await notification_service_1.NotificationServices.broadcast(req.body.title, req.body.body, req.body.link);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: `Announcement sent to ${result.delivered} of ${result.recipients} users.`,
        data: result,
    });
});
exports.NotificationControllers = {
    getMyNotifications,
    broadcast,
    getUnreadCount,
    markAsRead,
    markAllAsRead,
    remove,
    getSettings,
    updateSettings,
};
//# sourceMappingURL=notification.controller.js.map