"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateCollectionItemZodSchema = exports.addCollectionItemZodSchema = void 0;
const zod_1 = __importDefault(require("zod"));
const objectId = zod_1.default
    .string()
    .regex(/^[0-9a-fA-F]{24}$/, { message: "Must be a valid ObjectId." });
/**
 * Either path is valid: supply `report` for a scanned card (the card is then
 * read from the report), or `card` for a manual entry. `currentPrice` is absent
 * by design — price is system-owned and seeded from the catalogue.
 */
exports.addCollectionItemZodSchema = zod_1.default
    .object({
    card: objectId.optional(),
    report: objectId.optional(),
    manualImageUrl: zod_1.default.string().url({ message: "Must be a valid URL." }).optional(),
    externalGrade: zod_1.default.string().max(50).optional(),
    quantity: zod_1.default.number().int().min(1).optional(),
    favorite: zod_1.default.boolean().optional(),
})
    .refine((data) => data.card ?? data.report, {
    message: "Provide either `card` (manual entry) or `report` (scanned card).",
    path: ["card"],
});
exports.updateCollectionItemZodSchema = zod_1.default.object({
    quantity: zod_1.default.number().int().min(1).optional(),
    favorite: zod_1.default.boolean().optional(),
    externalGrade: zod_1.default.string().max(50).optional(),
    manualImageUrl: zod_1.default.string().url({ message: "Must be a valid URL." }).optional(),
});
//# sourceMappingURL=collection.validation.js.map