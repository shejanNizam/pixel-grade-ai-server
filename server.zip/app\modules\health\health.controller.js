"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.liveness = exports.healthCheck = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const redis_config_1 = require("../../config/redis.config");
const healthCheck = async (_req, res) => {
    const mongoState = mongoose_1.default.connection.readyState;
    const mongoStatus = mongoState === 1 ? "connected" : "disconnected";
    let redisStatus = "disconnected";
    try {
        await redis_config_1.redisClient.ping();
        redisStatus = "connected";
    }
    catch {
        // redis unavailable — status stays "disconnected"
    }
    const isHealthy = mongoStatus === "connected" && redisStatus === "connected";
    res.status(isHealthy ? 200 : 503).json({
        status: isHealthy ? "ok" : "degraded",
        timestamp: new Date().toISOString(),
        uptime: Math.floor(process.uptime()),
        memory: {
            heapUsedMB: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
            heapTotalMB: Math.round(process.memoryUsage().heapTotal / 1024 / 1024),
            rssMB: Math.round(process.memoryUsage().rss / 1024 / 1024),
        },
        services: {
            database: mongoStatus,
            redis: redisStatus,
        },
    });
};
exports.healthCheck = healthCheck;
// Lightweight liveness probe — no DB/Redis check, just "am I up?"
const liveness = (_req, res) => {
    res.status(200).json({ status: "ok" });
};
exports.liveness = liveness;
//# sourceMappingURL=health.controller.js.map