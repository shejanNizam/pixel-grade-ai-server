"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const validateRequest_1 = __importDefault(require("../../middlewares/validateRequest"));
const user_interface_1 = require("../user/user.interface");
const notification_controller_1 = require("./notification.controller");
const notification_validation_1 = require("./notification.validation");
const router = (0, express_1.Router)();
const anyUser = Object.values(user_interface_1.UserRole);
const staffOnly = [user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin];
/**
 * @swagger
 * /notification:
 *   get:
 *     tags: [Notification]
 *     summary: Paginated notification history
 *     description: >
 *       Notifications are created server-side only from platform events — the
 *       one exception is POST /notification/broadcast, which is admin-guarded.
 *       New notifications are also pushed live over Socket.io as
 *       `notification:new`.
 *
 *       Scoped to the caller AND to one audience. `audience=user` (default)
 *       returns notifications about the caller's own activity; `audience=admin`
 *       returns platform-operations alerts and is refused for non-staff.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: audience
 *         schema:
 *           type: string
 *           enum: [user, admin]
 *           default: user
 *     responses:
 *       200:
 *         description: Notifications, newest first
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Non-staff requested the admin audience
 */
router.get("/", (0, checkAuth_1.checkAuth)(...anyUser), notification_controller_1.NotificationControllers.getMyNotifications);
/**
 * @swagger
 * /notification/broadcast:
 *   post:
 *     tags: [Notification]
 *     summary: Send an announcement to every active user (admin only)
 *     description: >
 *       Writes a `system` notification to every active customer. Type and
 *       audience are fixed server-side, so this cannot forge a grading or
 *       billing message, and cannot address the staff queue. `link` must be an
 *       in-app path.
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [title]
 *             properties:
 *               title: { type: string, maxLength: 120 }
 *               body: { type: string, maxLength: 500 }
 *               link: { type: string, example: "/user-dashboard/subscription" }
 *     responses:
 *       200:
 *         description: Delivery counts
 *       403:
 *         description: Not staff
 */
router.post("/broadcast", (0, checkAuth_1.checkAuth)(...staffOnly), (0, validateRequest_1.default)(notification_validation_1.broadcastNotificationZodSchema), notification_controller_1.NotificationControllers.broadcast);
/**
 * @swagger
 * /notification/unread-count:
 *   get:
 *     tags: [Notification]
 *     summary: Unread badge count
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Unread count
 */
router.get("/unread-count", (0, checkAuth_1.checkAuth)(...anyUser), notification_controller_1.NotificationControllers.getUnreadCount);
/**
 * @swagger
 * /notification/settings:
 *   get:
 *     tags: [Notification]
 *     summary: Get delivery preferences
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Settings
 *   patch:
 *     tags: [Notification]
 *     summary: Update delivery preferences
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Settings updated
 */
router.get("/settings", (0, checkAuth_1.checkAuth)(...anyUser), notification_controller_1.NotificationControllers.getSettings);
router.patch("/settings", (0, checkAuth_1.checkAuth)(...anyUser), (0, validateRequest_1.default)(notification_validation_1.updateNotificationSettingsZodSchema), notification_controller_1.NotificationControllers.updateSettings);
/**
 * @swagger
 * /notification/read-all:
 *   patch:
 *     tags: [Notification]
 *     summary: Mark every notification as read
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: All marked read
 */
router.patch("/read-all", (0, checkAuth_1.checkAuth)(...anyUser), notification_controller_1.NotificationControllers.markAllAsRead);
/**
 * @swagger
 * /notification/{id}/read:
 *   patch:
 *     tags: [Notification]
 *     summary: Mark one notification as read
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Marked read
 *       404:
 *         description: Not found, or not owned by the caller
 */
router.patch("/:id/read", (0, checkAuth_1.checkAuth)(...anyUser), notification_controller_1.NotificationControllers.markAsRead);
/**
 * @swagger
 * /notification/{id}:
 *   delete:
 *     tags: [Notification]
 *     summary: Delete a notification
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Deleted
 *       404:
 *         description: Not found, or not owned by the caller
 */
router.delete("/:id", (0, checkAuth_1.checkAuth)(...anyUser), notification_controller_1.NotificationControllers.remove);
exports.NotificationRoutes = router;
//# sourceMappingURL=notification.route.js.map