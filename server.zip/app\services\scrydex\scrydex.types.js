"use strict";
/**
 * Scrydex wire types — the vendor's shapes, not ours.
 *
 * Everything here mirrors what api.scrydex.com actually returns (verified
 * against the live account on 2026-07-31), so it is deliberately loose: almost
 * every field is optional because Scrydex omits rather than nulls large parts
 * of a card, and a card that is missing `printed_number` must not throw.
 *
 * Nothing outside `services/scrydex/` should import these. The mapper turns
 * them into our own types; the rest of the app never sees a snake_case field.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=scrydex.types.js.map