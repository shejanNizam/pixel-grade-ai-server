"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GradingReport = exports.gradingReportSchema = void 0;
const mongoose_1 = require("mongoose");
const grading_interface_1 = require("./grading.interface");
const subScore = { type: Number, required: true, min: 0, max: 10 };
exports.gradingReportSchema = new mongoose_1.Schema({
    analysis: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "CardAnalysis",
        required: true,
        unique: true,
    },
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
    card: { type: mongoose_1.Schema.Types.ObjectId, ref: "Card", required: true },
    grade: { type: Number, required: true, min: 0, max: 10 },
    gradeLabel: {
        type: String,
        enum: Object.values(grading_interface_1.GradeLabel),
        required: true,
    },
    scoreSurface: subScore,
    scoreCorners: subScore,
    scoreEdges: subScore,
    scoreCentering: subScore,
    confidence: { type: Number, required: true, min: 0, max: 100 },
    reasoning: { type: String },
    // All three are optional so reports written before pixelgrade-v2 still
    // load. Nothing back-fills them — an old report keeps the grade it was
    // issued with, and the UI degrades to the v1 layout when they are absent.
    imageQuality: {
        type: new mongoose_1.Schema({
            score: { type: Number, min: 0, max: 100 },
            issues: { type: [String], default: [] },
        }, { _id: false }),
        required: false,
    },
    centering: {
        type: new mongoose_1.Schema({
            leftPct: { type: Number, min: 0, max: 100 },
            topPct: { type: Number, min: 0, max: 100 },
        }, { _id: false }),
        required: false,
    },
    detectedDefects: {
        type: [
            new mongoose_1.Schema({
                category: { type: String },
                severity: { type: String },
                location: { type: String },
                description: { type: String },
            }, { _id: false }),
        ],
        default: undefined,
    },
    // Server-set only. There is deliberately no validation path that accepts
    // this from a request body — see the grading service.
    pixelVerified: { type: Boolean, default: false },
    modelVersion: { type: String, required: true },
    rawOutput: { type: mongoose_1.Schema.Types.Mixed },
    reportPdfUrl: { type: String },
}, {
    timestamps: true,
    versionKey: false,
});
exports.gradingReportSchema.index({ user: 1, createdAt: -1 });
exports.gradingReportSchema.index({ card: 1 });
exports.GradingReport = (0, mongoose_1.model)("GradingReport", exports.gradingReportSchema);
//# sourceMappingURL=grading.model.js.map