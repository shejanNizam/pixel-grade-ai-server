"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthServices = void 0;
const bcrypt_1 = __importDefault(require("bcrypt"));
const http_status_1 = __importDefault(require("http-status"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const index_1 = require("../../config/index");
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const auth_identity_model_1 = require("../auth_identity/auth_identity.model");
const user_model_1 = require("../user/user.model");
const sendEmail_1 = require("../../utils/sendEmail");
const userTokens_1 = require("../../utils/userTokens");
const credentialLogin = async (payload) => {
    const { email, password } = payload;
    if (!email)
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Email is required");
    const isUserExist = await user_model_1.User.findOne({ email }).select("+password");
    if (!isUserExist) {
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "User with this email not found");
    }
    if (!isUserExist.password) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "No password set. Please login with Google.");
    }
    if (!isUserExist.isEmailVerified) {
        throw new AppError_1.default(http_status_1.default.FORBIDDEN, "Please verify your email before logging in");
    }
    if (isUserExist.status === "blocked") {
        throw new AppError_1.default(http_status_1.default.FORBIDDEN, "Your account has been blocked");
    }
    if (isUserExist.isDeleted) {
        throw new AppError_1.default(http_status_1.default.FORBIDDEN, "Account no longer exists");
    }
    const isPasswordMatch = await bcrypt_1.default.compare(password, isUserExist.password);
    if (!isPasswordMatch) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Incorrect password");
    }
    const userTokens = (0, userTokens_1.createUserTokens)(isUserExist);
    await user_model_1.User.findByIdAndUpdate(isUserExist._id, {
        lastLoginAt: new Date(),
    });
    const userObj = isUserExist.toObject();
    delete userObj.password;
    return {
        accessToken: userTokens.accessToken,
        refreshToken: userTokens.refreshToken,
        user: userObj,
    };
};
const getNewAccessToken = async (refreshToken) => {
    const newAccessToken = await (0, userTokens_1.createNewAccessTokenWithRefreshToken)(refreshToken);
    return { accessToken: newAccessToken };
};
const changePassword = async (oldPassword, newPassword, decodedToken) => {
    const user = await user_model_1.User.findById(decodedToken._id).select("+password");
    if (!user)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "User not found");
    if (!oldPassword || !newPassword) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Old and new passwords are required");
    }
    if (oldPassword === newPassword) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "New password cannot be the same as the old password");
    }
    const isMatch = await bcrypt_1.default.compare(oldPassword, user.password);
    if (!isMatch) {
        throw new AppError_1.default(http_status_1.default.UNAUTHORIZED, "Old password does not match");
    }
    user.password = await bcrypt_1.default.hash(newPassword, Number(index_1.configs.bcrypt_salt_round));
    await user.save();
};
const setPassword = async (userId, plainPassword) => {
    const user = await user_model_1.User.findById(userId).select("+password");
    if (!user)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "User not found");
    const localIdentity = await auth_identity_model_1.AuthIdentity.findOne({
        userId,
        provider: "local",
    });
    if (localIdentity && user.password) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Password already set. Use change-password instead.");
    }
    user.password = await bcrypt_1.default.hash(plainPassword, Number(index_1.configs.bcrypt_salt_round));
    await user.save();
    if (!localIdentity) {
        await auth_identity_model_1.AuthIdentity.create({
            userId: user._id,
            provider: "local",
            providerId: user.email,
        });
    }
};
const forgotPassword = async (email) => {
    const user = await user_model_1.User.findOne({ email });
    if (!user)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "User not found");
    if (!user.isEmailVerified) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Email is not verified");
    }
    if (user.status === "blocked") {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Account is blocked");
    }
    if (user.isDeleted) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Account has been deleted");
    }
    const resetToken = jsonwebtoken_1.default.sign({ _id: user._id?.toString(), email: user.email, role: user.role }, index_1.configs.jwt_reset_secret, { expiresIn: "10m" });
    const resetUILink = `${index_1.configs.frontend_url}/reset-password?id=${user._id}&token=${resetToken}`;
    await (0, sendEmail_1.sendEmail)({
        to: user.email,
        subject: "Password Reset",
        templateName: "forgetPassword",
        templateData: { name: user.name, resetUILink },
    });
};
const resetPassword = async (payload, decodedToken) => {
    const { id, newPassword } = payload;
    if (!id || !newPassword) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Id and new password required");
    }
    if (id !== decodedToken._id) {
        throw new AppError_1.default(http_status_1.default.UNAUTHORIZED, "Cannot reset password");
    }
    const user = await user_model_1.User.findById(decodedToken._id);
    if (!user)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "User not found");
    user.password = await bcrypt_1.default.hash(newPassword, Number(index_1.configs.bcrypt_salt_round));
    await user.save();
};
exports.AuthServices = {
    credentialLogin,
    getNewAccessToken,
    changePassword,
    setPassword,
    forgotPassword,
    resetPassword,
};
//# sourceMappingURL=auth.service.js.map