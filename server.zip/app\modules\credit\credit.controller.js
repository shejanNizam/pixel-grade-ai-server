"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const credit_service_1 = require("./credit.service");
const getMyBalance = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await credit_service_1.CreditServices.getBalance(userId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Credit balance retrieved successfully!",
        data: result,
    });
});
const getMyLedger = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await credit_service_1.CreditServices.getLedger(userId, req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Credit history retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getUserLedger = (0, catchAsync_1.default)(async (req, res) => {
    const result = await credit_service_1.CreditServices.getLedger(req.params.userId, req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Credit history retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const adminAdjust = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: adminId } = req.user;
    const result = await credit_service_1.CreditServices.adminAdjust(req.params.userId, req.body.amount, adminId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Credits adjusted successfully!",
        data: result,
    });
});
exports.CreditControllers = {
    getMyBalance,
    getMyLedger,
    getUserLedger,
    adminAdjust,
};
//# sourceMappingURL=credit.controller.js.map