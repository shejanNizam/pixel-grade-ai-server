"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlabOrder = exports.SlabLabel = exports.slabLabelSchema = void 0;
const mongoose_1 = require("mongoose");
const constants_1 = require("../../constants");
exports.slabLabelSchema = new mongoose_1.Schema({
    report: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "GradingReport",
        required: true,
    },
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
    styleId: {
        type: String,
        enum: constants_1.SLAB_STYLES,
        default: constants_1.SLAB_STYLES[0],
    },
    // The four EXT. ART options. Empty on labels created before 2026-07-30 —
    // those still render from `backgroundUrl` alone.
    variants: {
        type: [
            new mongoose_1.Schema({
                index: { type: Number, required: true, min: 1 },
                artworkUrl: { type: String, required: true },
                compositeUrl: { type: String },
            }, { _id: false }),
        ],
        default: [],
    },
    selectedVariant: { type: Number, min: 1 },
    // Frozen once resolved — see ISlabLabelInitial.cardImageUrl.
    cardImageUrl: { type: String },
    cardImageSource: { type: String, enum: constants_1.SLAB_CARD_RENDER_MODES },
    backgroundUrl: { type: String },
    compositeUrl: { type: String },
    exportPngUrl: { type: String },
    exportPdfUrl: { type: String },
    widthMm: { type: Number, default: constants_1.SLAB_DEFAULTS.widthMm },
    heightMm: { type: Number, default: constants_1.SLAB_DEFAULTS.heightMm },
    openingWMm: { type: Number, default: constants_1.SLAB_DEFAULTS.openingWidthMm },
    openingHMm: { type: Number, default: constants_1.SLAB_DEFAULTS.openingHeightMm },
    labelWMm: { type: Number, default: constants_1.SLAB_DEFAULTS.labelWidthMm },
    labelHMm: { type: Number, default: constants_1.SLAB_DEFAULTS.labelHeightMm },
    bleedMm: { type: Number, default: constants_1.SLAB_DEFAULTS.bleedMm },
    safeMm: { type: Number, default: constants_1.SLAB_DEFAULTS.safeMm },
    version: { type: Number, default: 1, min: 1 },
}, {
    timestamps: true,
    versionKey: false,
});
// A report accumulates label versions; the latest is read most often.
exports.slabLabelSchema.index({ report: 1, version: -1 });
exports.slabLabelSchema.index({ user: 1, createdAt: -1 });
exports.SlabLabel = (0, mongoose_1.model)("SlabLabel", exports.slabLabelSchema);
var slabOrder_model_1 = require("../slabOrder/slabOrder.model");
Object.defineProperty(exports, "SlabOrder", { enumerable: true, get: function () { return slabOrder_model_1.SlabOrder; } });
//# sourceMappingURL=slab.model.js.map