"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupportTicketMessage = exports.supportTicketMessageSchema = exports.SupportTicket = exports.supportTicketSchema = void 0;
const mongoose_1 = require("mongoose");
const support_interface_1 = require("./support.interface");
exports.supportTicketSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
    subject: { type: String, required: true },
    status: {
        type: String,
        enum: Object.values(support_interface_1.TicketStatus),
        default: support_interface_1.TicketStatus.open,
    },
    reopenCount: { type: Number, default: 0 },
}, {
    timestamps: true,
    versionKey: false,
});
exports.supportTicketSchema.index({ user: 1, createdAt: -1 });
exports.supportTicketSchema.index({ status: 1, updatedAt: -1 });
exports.SupportTicket = (0, mongoose_1.model)("SupportTicket", exports.supportTicketSchema);
exports.supportTicketMessageSchema = new mongoose_1.Schema({
    ticket: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "SupportTicket",
        required: true,
    },
    sender: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
    isAdmin: { type: Boolean, default: false },
    message: { type: String, required: true },
}, {
    timestamps: true,
    versionKey: false,
});
// A thread is always read oldest-first for one ticket.
exports.supportTicketMessageSchema.index({ ticket: 1, createdAt: 1 });
exports.SupportTicketMessage = (0, mongoose_1.model)("SupportTicketMessage", exports.supportTicketMessageSchema);
//# sourceMappingURL=support.model.js.map