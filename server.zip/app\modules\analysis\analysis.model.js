"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CardCandidate = exports.cardCandidateSchema = exports.AnalysisImage = exports.analysisImageSchema = exports.CardAnalysis = exports.cardAnalysisSchema = void 0;
const mongoose_1 = require("mongoose");
const card_interface_1 = require("../card/card.interface");
const analysis_interface_1 = require("./analysis.interface");
exports.cardAnalysisSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
    source: {
        type: String,
        enum: Object.values(analysis_interface_1.UploadSource),
        default: analysis_interface_1.UploadSource.standard,
    },
    game: {
        type: String,
        enum: Object.values(card_interface_1.CardGame),
        default: card_interface_1.CardGame.pokemon,
    },
    language: { type: String },
    imageSetHash: { type: String, required: true },
    status: {
        type: String,
        enum: Object.values(analysis_interface_1.AnalysisStatus),
        default: analysis_interface_1.AnalysisStatus.identifying,
    },
    clientRequestId: { type: String },
    bestMatchCard: { type: mongoose_1.Schema.Types.ObjectId, ref: "Card" },
    confirmedCard: { type: mongoose_1.Schema.Types.ObjectId, ref: "Card" },
    wasCorrected: { type: Boolean, default: false },
    detectedExternalGrade: { type: String },
}, {
    timestamps: true,
    versionKey: false,
});
exports.cardAnalysisSchema.index({ user: 1, createdAt: -1 });
// Not unique: two users may legitimately scan identical images, and each needs
// their own analysis. The grading *cache* dedupes on this hash, not the record.
exports.cardAnalysisSchema.index({ imageSetHash: 1 });
exports.cardAnalysisSchema.index({ status: 1 });
// Idempotency. Scoped to the user so two accounts can never collide on a
// guessed key, and partial so the many older rows without one do not all
// collide on `null`.
exports.cardAnalysisSchema.index({ user: 1, clientRequestId: 1 }, {
    unique: true,
    partialFilterExpression: { clientRequestId: { $type: "string" } },
});
// Drives the abandoned-scan sweeper, which scans by status and age.
exports.cardAnalysisSchema.index({ status: 1, createdAt: 1 });
exports.CardAnalysis = (0, mongoose_1.model)("CardAnalysis", exports.cardAnalysisSchema);
exports.analysisImageSchema = new mongoose_1.Schema({
    analysis: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "CardAnalysis",
        required: true,
    },
    imageUrl: { type: String, required: true },
    side: {
        type: String,
        enum: Object.values(analysis_interface_1.ImageSide),
        default: analysis_interface_1.ImageSide.front,
    },
    slotIndex: { type: Number, default: 0, min: 0, max: 9 },
    qualityScore: { type: Number, min: 0, max: 100 },
}, {
    timestamps: true,
    versionKey: false,
});
exports.analysisImageSchema.index({ analysis: 1 });
exports.AnalysisImage = (0, mongoose_1.model)("AnalysisImage", exports.analysisImageSchema);
exports.cardCandidateSchema = new mongoose_1.Schema({
    analysis: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "CardAnalysis",
        required: true,
    },
    card: { type: mongoose_1.Schema.Types.ObjectId, ref: "Card", required: true },
    rank: { type: Number, required: true, min: 0 },
    // Vendor-defined scale, NOT a percentage. Scrydex returns roughly 0.7–1.3+
    // and it is not bounded at 1 — an upper limit here would reject good
    // matches, so only the lower bound is enforced.
    matchScore: { type: Number, required: true, min: 0 },
}, {
    timestamps: true,
    versionKey: false,
});
// Candidates are always read as an ordered list for one analysis.
exports.cardCandidateSchema.index({ analysis: 1, rank: 1 });
exports.CardCandidate = (0, mongoose_1.model)("CardCandidate", exports.cardCandidateSchema);
//# sourceMappingURL=analysis.model.js.map