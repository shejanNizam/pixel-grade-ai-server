"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateTicketStatusZodSchema = exports.addTicketMessageZodSchema = exports.createTicketZodSchema = void 0;
const zod_1 = __importDefault(require("zod"));
const support_interface_1 = require("./support.interface");
exports.createTicketZodSchema = zod_1.default.object({
    subject: zod_1.default
        .string({ error: "Subject must be string" })
        .min(3, { message: "Subject must be at least 3 characters long." })
        .max(150, { message: "Subject cannot exceed 150 characters." }),
    message: zod_1.default
        .string({ error: "Message must be string" })
        .min(1, { message: "Message cannot be empty." })
        .max(5000, { message: "Message cannot exceed 5000 characters." }),
    /** Cloudflare Turnstile solution. Optional HERE so the schema still passes
     *  when captcha is unconfigured; whether it is actually required is decided
     *  in `verifyCaptcha`, which is the only place that knows if it's enabled. */
    captchaToken: zod_1.default.string().optional(),
});
exports.addTicketMessageZodSchema = zod_1.default.object({
    message: zod_1.default
        .string({ error: "Message must be string" })
        .min(1, { message: "Message cannot be empty." })
        .max(5000, { message: "Message cannot exceed 5000 characters." }),
});
exports.updateTicketStatusZodSchema = zod_1.default.object({
    status: zod_1.default.enum(Object.values(support_interface_1.TicketStatus)),
});
//# sourceMappingURL=support.validation.js.map