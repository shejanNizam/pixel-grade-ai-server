"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.requirePriceTracking = exports.requirePixelScope = exports.requireCredits = void 0;
const http_status_1 = __importDefault(require("http-status"));
const constants_1 = require("../constants");
const AppError_1 = __importDefault(require("../errorHelpers/AppError"));
const credit_service_1 = require("../modules/credit/credit.service");
const analysis_interface_1 = require("../modules/analysis/analysis.interface");
/**
 * Server-side feature gating.
 *
 * The frontend also hides locked features, but that is presentation only — these
 * middlewares are the actual enforcement. Every entitlement is resolved from the
 * user's active plan on the server; nothing is read from the request body.
 */
/**
 * Refuses a scan when the wallet cannot cover it.
 *
 * This checks but does not debit. The debit happens inside the scan pipeline
 * once the upload has succeeded, so a user is never charged for a request that
 * failed before any work was done. The check here exists to fail fast and give
 * a clear error rather than letting an expensive upload run first.
 */
const requireCredits = async (req, _res, next) => {
    try {
        const { _id: userId } = req.user;
        const balance = await credit_service_1.CreditServices.getBalance(userId);
        if (balance.isUnlimited)
            return next();
        if ((balance.balance ?? 0) < constants_1.CREDITS_PER_SCAN) {
            throw new AppError_1.default(http_status_1.default.PAYMENT_REQUIRED, `A scan costs ${constants_1.CREDITS_PER_SCAN} credits and your balance is ${balance.balance}. Top up or upgrade your plan to continue.`);
        }
        next();
    }
    catch (error) {
        next(error);
    }
};
exports.requireCredits = requireCredits;
/**
 * Gates the Advanced multi-image upload to plans that include PixelScope.
 *
 * Reads the requested mode from the body, but the *entitlement* comes from the
 * plan — a client asking for `pixelscope` on a Free plan is rejected here rather
 * than quietly downgraded, so the failure is visible instead of producing a
 * standard scan the user did not ask for.
 */
const requirePixelScope = async (req, _res, next) => {
    try {
        if (req.body?.source !== analysis_interface_1.UploadSource.pixelscope)
            return next();
        const { _id: userId } = req.user;
        const plan = await credit_service_1.CreditServices.resolvePlan(userId);
        if (!plan.pixelscope) {
            throw new AppError_1.default(http_status_1.default.FORBIDDEN, "PixelScope is available on the Collector plan and above. Upgrade to use Advanced scans and earn the Pixel Verified badge.");
        }
        next();
    }
    catch (error) {
        next(error);
    }
};
exports.requirePixelScope = requirePixelScope;
/** Price tracking is a free feature for all registered users. */
const requirePriceTracking = async (_req, _res, next) => {
    next();
};
exports.requirePriceTracking = requirePriceTracking;
//# sourceMappingURL=checkEntitlement.js.map