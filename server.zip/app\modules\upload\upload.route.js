"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadRoutes = void 0;
const multer_1 = __importDefault(require("multer"));
const express_1 = require("express");
const http_status_1 = __importDefault(require("http-status"));
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const multer_config_1 = require("../../config/multer.config");
const checkAuth_1 = require("../../middlewares/checkAuth");
const user_interface_1 = require("../user/user.interface");
const upload_controller_1 = require("./upload.controller");
const logger_1 = require("../../utils/logger");
const router = (0, express_1.Router)();
const allRoles = Object.values(user_interface_1.UserRole);
/**
 * @swagger
 * /upload:
 *   post:
 *     tags: [Upload]
 *     summary: Upload one or more files to Cloudinary
 *     description: Send 1 file to get a single `{ url, publicId }` object back. Send 2–10 files to get an array.
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required: [files]
 *             properties:
 *               files:
 *                 type: array
 *                 items:
 *                   type: string
 *                   format: binary
 *                 minItems: 1
 *                 maxItems: 10
 *                 description: Field name must be "files"
 *     responses:
 *       200:
 *         description: File(s) uploaded successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/UploadResponse'
 *       400:
 *         description: No files provided
 *       401:
 *         description: Unauthorized
 */
router.post("/", (0, checkAuth_1.checkAuth)(...allRoles), (req, res, next) => {
    try {
        multer_config_1.multerUpload.array("files", 10)(req, res, (err) => {
            if (err) {
                logger_1.logger.error("Multer image upload error:", { error: err });
                if (err instanceof multer_1.default.MulterError) {
                    if (err.code === "LIMIT_FILE_SIZE") {
                        return next(new AppError_1.default(http_status_1.default.BAD_REQUEST, "File size exceeds the maximum limit (10MB)."));
                    }
                    if (err.code === "LIMIT_UNEXPECTED_FILE") {
                        return next(new AppError_1.default(http_status_1.default.BAD_REQUEST, "Unexpected field or maximum 10 files allowed under field 'files'."));
                    }
                    return next(new AppError_1.default(http_status_1.default.BAD_REQUEST, `Upload error: ${err.message}`));
                }
                return next(new AppError_1.default(http_status_1.default.BAD_REQUEST, err.message || "File upload failed. Please check file size, format, and credentials."));
            }
            next();
        });
    }
    catch (error) {
        next(error);
    }
}, upload_controller_1.UploadControllers.uploadFiles);
exports.UploadRoutes = router;
//# sourceMappingURL=upload.route.js.map