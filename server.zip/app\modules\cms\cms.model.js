"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CmsPage = exports.cmsPageSchema = void 0;
const mongoose_1 = require("mongoose");
const cms_interface_1 = require("./cms.interface");
exports.cmsPageSchema = new mongoose_1.Schema({
    slug: {
        type: String,
        enum: Object.values(cms_interface_1.CmsSlug),
        required: true,
        unique: true,
    },
    htmlContent: { type: String, default: "" },
    updatedBy: { type: mongoose_1.Schema.Types.ObjectId, ref: "User" },
}, {
    timestamps: true,
    versionKey: false,
});
exports.CmsPage = (0, mongoose_1.model)("CmsPage", exports.cmsPageSchema);
//# sourceMappingURL=cms.model.js.map