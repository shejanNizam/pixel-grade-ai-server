"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Subscription = exports.subscriptionSchema = void 0;
const mongoose_1 = require("mongoose");
const subscription_interface_1 = require("./subscription.interface");
exports.subscriptionSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
    plan: { type: mongoose_1.Schema.Types.ObjectId, ref: "Plan", required: true },
    interval: {
        type: String,
        enum: Object.values(subscription_interface_1.BillingInterval),
        default: subscription_interface_1.BillingInterval.monthly,
    },
    status: {
        type: String,
        enum: Object.values(subscription_interface_1.SubStatus),
        default: subscription_interface_1.SubStatus.active,
    },
    currentPeriodEnd: { type: Date },
    cancelAtPeriodEnd: { type: Boolean, default: false },
    stripeSubscriptionId: { type: String },
}, {
    timestamps: true,
    versionKey: false,
});
exports.subscriptionSchema.index({ user: 1, status: 1 });
// Sparse: rows exist before Stripe assigns an id, and for the Free tier which
// never reaches Stripe at all. A plain unique index would collide on null.
exports.subscriptionSchema.index({ stripeSubscriptionId: 1 }, { unique: true, sparse: true });
exports.Subscription = (0, mongoose_1.model)("Subscription", exports.subscriptionSchema);
//# sourceMappingURL=subscription.model.js.map