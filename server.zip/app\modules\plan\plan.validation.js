"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updatePlanZodSchema = void 0;
const zod_1 = __importDefault(require("zod"));
const plan_interface_1 = require("./plan.interface");
/** Edit-only by design. There is no create schema and no delete route — the four
 *  tiers are fixed, so `name` is deliberately absent here and cannot be changed. */
exports.updatePlanZodSchema = zod_1.default.object({
    tagline: zod_1.default.string().max(120).optional(),
    priceMonthly: zod_1.default
        .number({ error: "priceMonthly must be a number" })
        .min(0, { message: "Price cannot be negative." })
        .optional(),
    priceYearly: zod_1.default
        .number({ error: "priceYearly must be a number" })
        .min(0, { message: "Price cannot be negative." })
        .optional(),
    // `null` is a valid value meaning unlimited, so nullable() is load-bearing —
    // dropping it would make Enterprise un-editable.
    creditAmount: zod_1.default
        .number({ error: "creditAmount must be a number" })
        .int({ message: "Credits must be a whole number." })
        .min(0, { message: "Credits cannot be negative." })
        .nullable()
        .optional(),
    creditInterval: zod_1.default.enum(Object.values(plan_interface_1.CreditInterval)).optional(),
    pixelscope: zod_1.default.boolean().optional(),
    priceTracking: zod_1.default.boolean().optional(),
    watermarkReports: zod_1.default.boolean().optional(),
    features: zod_1.default.array(zod_1.default.string()).optional(),
    isActive: zod_1.default.boolean().optional(),
    stripePriceIdMonth: zod_1.default.string().optional(),
    stripePriceIdYear: zod_1.default.string().optional(),
});
//# sourceMappingURL=plan.validation.js.map