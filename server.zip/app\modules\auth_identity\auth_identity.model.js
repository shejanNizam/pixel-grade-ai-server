"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthIdentity = void 0;
const mongoose_1 = require("mongoose");
const authIdentitySchema = new mongoose_1.Schema({
    userId: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
    provider: {
        type: String,
        enum: ["local", "google", "apple"],
        required: true,
    },
    providerId: { type: String, required: true },
}, { timestamps: true, versionKey: false });
authIdentitySchema.index({ provider: 1, providerId: 1 }, { unique: true });
authIdentitySchema.index({ userId: 1 });
exports.AuthIdentity = (0, mongoose_1.model)("AuthIdentity", authIdentitySchema);
//# sourceMappingURL=auth_identity.model.js.map