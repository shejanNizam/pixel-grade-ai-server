"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.liveGames = exports.requireVisionSlug = exports.requireGameSegment = exports.SCRYDEX_UNMAPPED_GAMES = exports.SCRYDEX_GAMES = void 0;
const http_status_1 = __importDefault(require("http-status"));
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const card_interface_1 = require("../../modules/card/card.interface");
exports.SCRYDEX_GAMES = {
    [card_interface_1.CardGame.pokemon]: {
        pathSegment: "pokemon",
        visionSlug: "pokemon",
        live: true,
        label: "Pokémon",
    },
    [card_interface_1.CardGame.magic]: {
        // Verified live at Scrydex; switch `live` to true when the client asks for
        // it. Nothing else needs to change.
        pathSegment: "magicthegathering",
        visionSlug: "magicthegathering",
        live: false,
        label: "Magic: The Gathering",
    },
    [card_interface_1.CardGame.yugioh]: {
        pathSegment: null,
        visionSlug: null,
        live: false,
        label: "Yu-Gi-Oh!",
    },
    [card_interface_1.CardGame.sports]: {
        pathSegment: null,
        visionSlug: null,
        live: false,
        label: "Sports",
    },
};
/**
 * Scrydex catalogues that have no `CardGame` to map onto yet. Verified to
 * respond 200 on 2026-07-31. Documented so the expansion path is a known
 * quantity rather than something to re-discover.
 */
exports.SCRYDEX_UNMAPPED_GAMES = [
    "lorcana",
    "onepiece",
    "gundam",
    "riftbound",
];
/**
 * Resolves the Scrydex path segment for a game, or throws the specific reason
 * it cannot be served.
 *
 * Throwing here rather than letting the request 404 is what keeps a user who
 * picked Yu-Gi-Oh! from seeing "Identification service returned 404" — which
 * reads like an outage and would send them to support.
 */
const requireGameSegment = (game) => {
    const config = exports.SCRYDEX_GAMES[game];
    if (!config) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, `Unknown card game: ${game}`);
    }
    if (!config.pathSegment) {
        throw new AppError_1.default(http_status_1.default.NOT_IMPLEMENTED, `${config.label} is not covered by our card data provider yet. Pokémon is the only game available today.`);
    }
    if (!config.live) {
        throw new AppError_1.default(http_status_1.default.NOT_IMPLEMENTED, `${config.label} is coming soon. Pokémon is the only game available today.`);
    }
    return config.pathSegment;
};
exports.requireGameSegment = requireGameSegment;
/** The Vision `games[]` filter for a game. Same gating as above. */
const requireVisionSlug = (game) => {
    (0, exports.requireGameSegment)(game);
    return exports.SCRYDEX_GAMES[game].visionSlug;
};
exports.requireVisionSlug = requireVisionSlug;
/** Games a user may actually scan. Drives the UI's "Coming Soon" flags. */
const liveGames = () => Object.keys(exports.SCRYDEX_GAMES).filter((game) => exports.SCRYDEX_GAMES[game].live);
exports.liveGames = liveGames;
//# sourceMappingURL=scrydex.games.js.map