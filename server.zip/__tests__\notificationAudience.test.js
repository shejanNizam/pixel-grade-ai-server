"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const notification_interface_1 = require("../app/modules/notification/notification.interface");
const notification_service_1 = require("../app/modules/notification/notification.service");
const user_interface_1 = require("../app/modules/user/user.interface");
/**
 * The audience split is an authorisation boundary, not a display preference.
 *
 * Two things have to hold, and both fail silently if broken: a staff alert must
 * never be addressable to a single customer, and a customer must never be able
 * to read the staff queue. These tests pin the declarations both rules are
 * derived from.
 */
describe("notification audience mapping", () => {
    it("classifies every type exactly once", () => {
        // A type missing from the map would resolve to `undefined` and fall through
        // the create/createForStaff guards into whichever branch ran first.
        for (const type of Object.values(notification_interface_1.NotifType)) {
            expect(Object.values(notification_interface_1.NotifAudience)).toContain(notification_interface_1.TYPE_AUDIENCE[type]);
        }
        expect(Object.keys(notification_interface_1.TYPE_AUDIENCE).sort()).toEqual(Object.values(notification_interface_1.NotifType).sort());
    });
    it("keeps customer-facing types on the user audience", () => {
        for (const type of [
            notification_interface_1.NotifType.grade_ready,
            notification_interface_1.NotifType.price_alert,
            notification_interface_1.NotifType.subscription,
            notification_interface_1.NotifType.support,
            notification_interface_1.NotifType.system,
        ]) {
            expect(notification_interface_1.TYPE_AUDIENCE[type]).toBe(notification_interface_1.NotifAudience.user);
        }
    });
    it("keeps operational types on the admin audience", () => {
        for (const type of [
            notification_interface_1.NotifType.support_ticket_new,
            notification_interface_1.NotifType.support_ticket_reply,
            notification_interface_1.NotifType.subscription_started,
            notification_interface_1.NotifType.subscription_payment_failed,
        ]) {
            expect(notification_interface_1.TYPE_AUDIENCE[type]).toBe(notification_interface_1.NotifAudience.admin);
        }
    });
    it("never marks a support REPLY to a customer as staff-audience", () => {
        // Easy to conflate: `support` goes to the ticket owner, while
        // `support_ticket_reply` tells staff a customer wrote back. Swapping them
        // would mail every admin about their own replies and tell the customer
        // nothing.
        expect(notification_interface_1.TYPE_AUDIENCE[notification_interface_1.NotifType.support]).toBe(notification_interface_1.NotifAudience.user);
        expect(notification_interface_1.TYPE_AUDIENCE[notification_interface_1.NotifType.support_ticket_reply]).toBe(notification_interface_1.NotifAudience.admin);
    });
});
describe("isStaffRole", () => {
    it("admits admins and super admins", () => {
        expect((0, notification_service_1.isStaffRole)(user_interface_1.UserRole.admin)).toBe(true);
        expect((0, notification_service_1.isStaffRole)(user_interface_1.UserRole.super_admin)).toBe(true);
    });
    it("refuses regular users and anything unrecognised", () => {
        expect((0, notification_service_1.isStaffRole)(user_interface_1.UserRole.user)).toBe(false);
        expect((0, notification_service_1.isStaffRole)(undefined)).toBe(false);
        expect((0, notification_service_1.isStaffRole)("")).toBe(false);
        // A forged or renamed role must not accidentally pass.
        expect((0, notification_service_1.isStaffRole)("administrator")).toBe(false);
        expect((0, notification_service_1.isStaffRole)("ADMIN")).toBe(false);
    });
});
//# sourceMappingURL=notificationAudience.test.js.map