"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const user_service_1 = require("./user.service");
const createUser = (0, catchAsync_1.default)(async (req, res) => {
    const user = await user_service_1.UserServices.createUser(req.body);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.CREATED,
        success: true,
        message: "User registered successfully!",
        data: user,
    });
});
const updateUser = (0, catchAsync_1.default)(async (req, res) => {
    const user = await user_service_1.UserServices.updateUser(req.params.id, req.body, req.user);
    (0, sendResponse_1.default)(res, {
        success: true,
        statusCode: http_status_1.default.OK,
        message: "User updated successfully",
        data: user,
    });
});
const getAllUsers = (0, catchAsync_1.default)(async (req, res) => {
    const result = await user_service_1.UserServices.getAllUsers(req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Users retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getSingleUser = (0, catchAsync_1.default)(async (req, res) => {
    const result = await user_service_1.UserServices.getSingleUser(req.params.id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "User retrieved successfully!",
        data: result,
    });
});
const getMe = (0, catchAsync_1.default)(async (req, res) => {
    const decodedToken = req.user;
    const result = await user_service_1.UserServices.getMe(decodedToken._id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Profile retrieved successfully!",
        data: result,
    });
});
const deleteUser = (0, catchAsync_1.default)(async (req, res) => {
    await user_service_1.UserServices.deleteUser(req.params.id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "User deleted successfully!",
        data: null,
    });
});
const deleteMe = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    await user_service_1.UserServices.deleteMe(userId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Account deleted successfully!",
        data: null,
    });
});
const checkUsername = (0, catchAsync_1.default)(async (req, res) => {
    const username = req.query.username;
    const result = await user_service_1.UserServices.checkUsernameAvailability(username);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: result.message,
        data: result,
    });
});
exports.UserControllers = {
    createUser,
    updateUser,
    getAllUsers,
    getSingleUser,
    getMe,
    deleteUser,
    deleteMe,
    checkUsername,
};
//# sourceMappingURL=user.controller.js.map