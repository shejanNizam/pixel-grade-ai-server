"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PriceBasis = exports.CardLanguage = exports.CardGame = void 0;
/** Only Pokémon is live at launch; the rest are "Coming Soon" in the UI but the
 *  enum carries them so stored data does not need migrating when they ship. */
var CardGame;
(function (CardGame) {
    CardGame["pokemon"] = "pokemon";
    CardGame["magic"] = "magic";
    CardGame["yugioh"] = "yugioh";
    CardGame["sports"] = "sports";
})(CardGame || (exports.CardGame = CardGame = {}));
var CardLanguage;
(function (CardLanguage) {
    CardLanguage["English"] = "English";
    CardLanguage["Japanese"] = "Japanese";
})(CardLanguage || (exports.CardLanguage = CardLanguage = {}));
/**
 * What a stored price actually refers to.
 *
 * The client asked for reports to state whether a market value is for a raw
 * card or for one already graded (2026-07-29). The two differ by multiples for
 * the same card, so an unlabelled number is worse than no number — a collector
 * reading a raw price as a PSA 9 price will misprice a sale.
 *
 * Everything the pricing provider returns today is `raw`; `graded` exists so
 * the field does not need migrating when graded comps are wired up.
 */
var PriceBasis;
(function (PriceBasis) {
    PriceBasis["raw"] = "raw";
    PriceBasis["graded"] = "graded";
})(PriceBasis || (exports.PriceBasis = PriceBasis = {}));
//# sourceMappingURL=card.interface.js.map