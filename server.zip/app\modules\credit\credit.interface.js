"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditReason = void 0;
/** Why a credit entry exists. Every movement in or out of a wallet writes one
 *  ledger row with one of these — the ledger is the audit trail, so there is no
 *  such thing as an unexplained balance change. */
var CreditReason;
(function (CreditReason) {
    CreditReason["grant_daily"] = "grant_daily";
    CreditReason["grant_monthly"] = "grant_monthly";
    /** Spend. Always -CREDITS_PER_SCAN, and always carries an analysisId. */
    CreditReason["scan"] = "scan";
    CreditReason["refund"] = "refund";
    CreditReason["admin_adjust"] = "admin_adjust";
})(CreditReason || (exports.CreditReason = CreditReason = {}));
//# sourceMappingURL=credit.interface.js.map