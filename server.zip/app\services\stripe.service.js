"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.constructWebhookEvent = exports.isStripeConfigured = exports.getStripe = void 0;
const http_status_1 = __importDefault(require("http-status"));
const stripe_1 = __importDefault(require("stripe"));
const index_1 = require("../config/index");
const AppError_1 = __importDefault(require("../errorHelpers/AppError"));
/**
 * Stripe client.
 *
 * Lazily constructed so a missing key fails on the billing route with a clear
 * message rather than crashing the whole server at import time — the rest of
 * the product works fine without billing configured.
 */
let stripe = null;
const getStripe = () => {
    if (!index_1.configs.STRIPE.secret_key) {
        throw new AppError_1.default(http_status_1.default.SERVICE_UNAVAILABLE, "Billing is not configured — STRIPE_SECRET_KEY is missing.");
    }
    stripe ??= new stripe_1.default(index_1.configs.STRIPE.secret_key);
    return stripe;
};
exports.getStripe = getStripe;
const isStripeConfigured = () => Boolean(index_1.configs.STRIPE.secret_key);
exports.isStripeConfigured = isStripeConfigured;
/**
 * Verifies a webhook came from Stripe.
 *
 * Requires the RAW request body — if Express has already JSON-parsed it, the
 * bytes differ from what Stripe signed and every event fails verification. See
 * the raw-body mount in app.ts.
 */
const constructWebhookEvent = (rawBody, signature) => {
    if (!index_1.configs.STRIPE.webhook_secret) {
        throw new AppError_1.default(http_status_1.default.SERVICE_UNAVAILABLE, "Webhook handling is not configured — STRIPE_WEBHOOK_SECRET is missing.");
    }
    try {
        return (0, exports.getStripe)().webhooks.constructEvent(rawBody, signature, index_1.configs.STRIPE.webhook_secret);
    }
    catch (error) {
        // A failed signature check is an authentication failure, not a server bug —
        // returning 400 stops Stripe retrying a payload we will never accept.
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, `Stripe webhook signature verification failed: ${error.message}`);
    }
};
exports.constructWebhookEvent = constructWebhookEvent;
//# sourceMappingURL=stripe.service.js.map