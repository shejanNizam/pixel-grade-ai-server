"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const dashboard_service_1 = require("./dashboard.service");
const getAdminOverview = (0, catchAsync_1.default)(async (_req, res) => {
    const result = await dashboard_service_1.DashboardServices.getAdminOverview();
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Admin overview retrieved successfully!",
        data: result,
    });
});
const getUserOverview = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await dashboard_service_1.DashboardServices.getUserOverview(userId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Dashboard overview retrieved successfully!",
        data: result,
    });
});
exports.DashboardControllers = {
    getAdminOverview,
    getUserOverview,
};
//# sourceMappingURL=dashboard.controller.js.map