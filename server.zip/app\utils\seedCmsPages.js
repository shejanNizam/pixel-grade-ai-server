"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.seedCmsPages = void 0;
const cms_interface_1 = require("../modules/cms/cms.interface");
const cms_model_1 = require("../modules/cms/cms.model");
const logger_1 = require("./logger");
/**
 * Creates the three public pages as empty shells so the admin editor and the
 * public routes both have a row to work with from day one.
 *
 * Content is deliberately left blank rather than filled with placeholder copy —
 * "no placeholder content anywhere" is an acceptance criterion, and a real
 * empty page is easier to spot than convincing filler.
 */
const seedCmsPages = async () => {
    try {
        for (const slug of Object.values(cms_interface_1.CmsSlug)) {
            const exists = await cms_model_1.CmsPage.findOne({ slug });
            if (exists)
                continue;
            await cms_model_1.CmsPage.create({ slug, htmlContent: "" });
            logger_1.logger.info(`Seeded CMS page: ${slug}`);
        }
    }
    catch (error) {
        logger_1.logger.error("Failed to seed CMS pages", { error });
    }
};
exports.seedCmsPages = seedCmsPages;
//# sourceMappingURL=seedCmsPages.js.map