"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendEmail = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */
const ejs_1 = __importDefault(require("ejs"));
const nodemailer_1 = __importDefault(require("nodemailer"));
const path_1 = __importDefault(require("path"));
const index_1 = require("../config/index");
const AppError_1 = __importDefault(require("../errorHelpers/AppError"));
const logger_1 = require("./logger");
const smtpPort = Number.parseInt(index_1.configs.EMAIL_SENDER.smtp_port || "587", 10);
const smtpSecure = smtpPort === 465;
const transporter = nodemailer_1.default.createTransport({
    host: index_1.configs.EMAIL_SENDER.smtp_host,
    port: smtpPort,
    secure: smtpSecure,
    requireTLS: !smtpSecure,
    auth: {
        user: index_1.configs.EMAIL_SENDER.smtp_user,
        pass: index_1.configs.EMAIL_SENDER.smtp_pass,
    },
});
const sendEmail = async ({ to, subject, templateName, templateData, attachments, }) => {
    try {
        const templatePath = path_1.default.join(__dirname, "templates", `${templateName}.ejs`);
        const html = await ejs_1.default.renderFile(templatePath, templateData);
        const info = await transporter.sendMail({
            from: index_1.configs.EMAIL_SENDER.smtp_from || index_1.configs.EMAIL_SENDER.smtp_user,
            to: to,
            subject: subject,
            html: html,
            attachments: attachments?.map((attachment) => ({
                filename: attachment.filename,
                content: attachment.content,
                contentType: attachment.contentType,
            })),
        });
        logger_1.logger.info(`Email sent to ${to}: ${info.messageId}`);
    }
    catch (error) {
        logger_1.logger.error("Email sending error", {
            message: error.message,
            code: error.code,
            command: error.command,
            response: error.response,
        });
        throw new AppError_1.default(502, "Email not sent");
    }
};
exports.sendEmail = sendEmail;
//# sourceMappingURL=sendEmail.js.map