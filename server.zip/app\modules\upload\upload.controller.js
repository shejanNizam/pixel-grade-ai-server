"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const toFileResult = (file) => ({
    url: file.path,
    publicId: file.filename,
});
const uploadFiles = (0, catchAsync_1.default)(async (req, res) => {
    const files = req.files;
    if (!files || files.length === 0) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "No file provided");
    }
    const data = files.length === 1
        ? toFileResult(files[0])
        : files.map(toFileResult);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: `${files.length} file(s) uploaded successfully`,
        data,
    });
});
exports.UploadControllers = { uploadFiles };
//# sourceMappingURL=upload.controller.js.map