"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupportControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const support_service_1 = require("./support.service");
const createTicket = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await support_service_1.SupportServices.createTicket(userId, req.body, req.ip);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.CREATED,
        success: true,
        message: "Support ticket created successfully!",
        data: result,
    });
});
const getMyTickets = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await support_service_1.SupportServices.getMyTickets(userId, req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Tickets retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getAllTickets = (0, catchAsync_1.default)(async (req, res) => {
    const result = await support_service_1.SupportServices.getAllTickets(req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Tickets retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getTicket = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId, role } = req.user;
    const result = await support_service_1.SupportServices.getTicket(req.params.id, userId, role);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Ticket retrieved successfully!",
        data: result,
    });
});
const addMessage = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId, role } = req.user;
    const result = await support_service_1.SupportServices.addMessage(req.params.id, userId, role, req.body.message);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.CREATED,
        success: true,
        message: "Message sent successfully!",
        data: result,
    });
});
const updateStatus = (0, catchAsync_1.default)(async (req, res) => {
    const result = await support_service_1.SupportServices.updateStatus(req.params.id, req.body.status);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Ticket status updated successfully!",
        data: result,
    });
});
const reopenTicket = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await support_service_1.SupportServices.reopenTicket(req.params.id, userId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Ticket reopened successfully!",
        data: result,
    });
});
exports.SupportControllers = {
    createTicket,
    reopenTicket,
    getMyTickets,
    getAllTickets,
    getTicket,
    addMessage,
    updateStatus,
};
//# sourceMappingURL=support.controller.js.map