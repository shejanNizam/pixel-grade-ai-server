"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Plan = exports.planSchema = void 0;
const mongoose_1 = require("mongoose");
const plan_interface_1 = require("./plan.interface");
exports.planSchema = new mongoose_1.Schema({
    name: {
        type: String,
        enum: Object.values(plan_interface_1.PlanName),
        required: true,
        unique: true,
    },
    tagline: { type: String },
    priceMonthly: { type: Number, required: true, min: 0 },
    priceYearly: { type: Number, required: true, min: 0 },
    // `null` is meaningful here — it means unlimited, not missing. `default:
    // undefined` would let Mongoose drop the key, so the default is explicit.
    creditAmount: { type: Number, default: null, min: 0 },
    creditInterval: {
        type: String,
        enum: Object.values(plan_interface_1.CreditInterval),
        default: plan_interface_1.CreditInterval.monthly,
    },
    pixelscope: { type: Boolean, default: false },
    priceTracking: { type: Boolean, default: false },
    watermarkReports: { type: Boolean, default: true },
    features: { type: [String], default: [] },
    isActive: { type: Boolean, default: true },
    stripePriceIdMonth: { type: String },
    stripePriceIdYear: { type: String },
}, {
    timestamps: true,
    versionKey: false,
});
exports.Plan = (0, mongoose_1.model)("Plan", exports.planSchema);
//# sourceMappingURL=plan.model.js.map