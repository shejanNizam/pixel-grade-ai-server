"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const user_interface_1 = require("../user/user.interface");
const dashboard_controller_1 = require("./dashboard.controller");
const router = (0, express_1.Router)();
const anyUser = Object.values(user_interface_1.UserRole);
/**
 * @swagger
 * /dashboard/me:
 *   get:
 *     tags: [Dashboard]
 *     summary: Stat cards for the user dashboard landing page
 *     description: >
 *       Collection value, cards held, slabs ordered, scans run, and average
 *       grade — each with a month-over-month delta. A delta is null when the
 *       previous month was zero, since growth from nothing has no percentage;
 *       render no chip rather than substituting a number. Average grade is null
 *       outright for a collection with nothing graded in it.
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Five stat cards
 */
router.get("/me", (0, checkAuth_1.checkAuth)(...anyUser), dashboard_controller_1.DashboardControllers.getUserOverview);
/**
 * @swagger
 * /dashboard/admin:
 *   get:
 *     tags: [Dashboard]
 *     summary: Stat cards for the admin dashboard landing page (admin only)
 *     description: >
 *       Total users, active subscribers, new subscribers this month, lifetime
 *       earnings, and MRR. The subscriber delta is approximate — see the
 *       service for why churn is invisible to it.
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Four stat cards plus MRR
 *       403:
 *         description: Forbidden — insufficient role
 */
router.get("/admin", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), dashboard_controller_1.DashboardControllers.getAdminOverview);
exports.DashboardRoutes = router;
//# sourceMappingURL=dashboard.route.js.map