"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActivityAction = void 0;
/** Known actions. Kept as an enum so a typo cannot silently create a new
 *  category that admin analytics then never counts. */
var ActivityAction;
(function (ActivityAction) {
    ActivityAction["login"] = "login";
    ActivityAction["login_failed"] = "login_failed";
    ActivityAction["register"] = "register";
    ActivityAction["upload"] = "upload";
    ActivityAction["identify"] = "identify";
    ActivityAction["confirm_match"] = "confirm_match";
    ActivityAction["grade"] = "grade";
    ActivityAction["slab_export"] = "slab_export";
    ActivityAction["slab_order"] = "slab_order";
    ActivityAction["delete"] = "delete";
    ActivityAction["admin_action"] = "admin_action";
    ActivityAction["price_refresh"] = "price_refresh";
    ActivityAction["credit_grant"] = "credit_grant";
})(ActivityAction || (exports.ActivityAction = ActivityAction = {}));
//# sourceMappingURL=activity_log.interface.js.map