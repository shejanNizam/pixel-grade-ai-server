"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectRedis = exports.redisClient = exports.attachRedisLogging = exports.redisConnectionOptions = void 0;
const redis_1 = require("redis");
const logger_1 = require("../utils/logger");
const index_1 = require("./index");
/**
 * One place the Redis endpoint is described. The Socket.io adapter opens its own
 * pub/sub pair off the same options — three connections to one server, so they
 * must not be able to drift apart.
 */
console.log("Redis connection options:", {
    host: index_1.configs.REDIS.redis_host ?? "localhost",
    port: parseInt(index_1.configs.REDIS.redis_port ?? "6379"),
    username: index_1.configs.REDIS.redis_username ?? "default",
    password: index_1.configs.REDIS.redis_password ?? "",
});
exports.redisConnectionOptions = {
    username: index_1.configs.REDIS.redis_username ?? "default",
    password: index_1.configs.REDIS.redis_password ?? "",
    socket: {
        host: index_1.configs.REDIS.redis_host ?? "localhost",
        port: parseInt(index_1.configs.REDIS.redis_port ?? "6379"),
    },
};
/**
 * Connection lifecycle logging, shared by every client.
 *
 * Redis connections drop and come back on their own: a hosted provider culls
 * sockets that have been idle, and a suspended machine wakes to find all of them
 * reset (`ECONNRESET` on read). node-redis reconnects without help, so the gap
 * was never reliability — it was that recovery left no trace. The failure was
 * logged and the repair was not, which made a blip that healed in a second look
 * exactly like a Redis that never came back.
 *
 * Repeats of an identical error are swallowed until the client is `ready` again,
 * so a long outage costs one line per distinct fault instead of one per retry.
 */
const attachRedisLogging = (client, label) => {
    let hasConnected = false;
    let lastErrorCode;
    client.on("error", (error) => {
        const code = error?.code ?? error?.name ?? "unknown";
        console.log(`${label} error`, {
            code,
            syscall: error?.syscall,
            message: error?.message,
        });
        if (code === lastErrorCode)
            return;
        lastErrorCode = code;
        logger_1.logger.error(`${label} error`, {
            code,
            syscall: error?.syscall,
            message: error?.message,
        });
    });
    client.on("reconnecting", () => logger_1.logger.warn(`${label} reconnecting`));
    // `ready` also fires on the very first connect, which connectRedis already
    // reports — only the later ones are news.
    client.on("ready", () => {
        if (hasConnected)
            logger_1.logger.info(`${label} reconnected`);
        hasConnected = true;
        lastErrorCode = undefined;
    });
};
exports.attachRedisLogging = attachRedisLogging;
exports.redisClient = (0, redis_1.createClient)(exports.redisConnectionOptions);
(0, exports.attachRedisLogging)(exports.redisClient, "Redis client");
const connectRedis = async () => {
    if (!exports.redisClient.isOpen) {
        await exports.redisClient.connect();
        logger_1.logger.info("Redis Connected!");
    }
};
exports.connectRedis = connectRedis;
//# sourceMappingURL=redis.config.js.map