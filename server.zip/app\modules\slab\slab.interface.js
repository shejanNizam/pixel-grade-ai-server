"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlabOrderStatus = void 0;
/** Digital release or physical shipment is still unconfirmed by the client, so
 *  `fulfilled` deliberately means "delivered, however that ends up working" and
 *  there are no shipping fields yet. See docs/OPEN-QUESTIONS.md. */
var SlabOrderStatus;
(function (SlabOrderStatus) {
    SlabOrderStatus["pending"] = "pending";
    SlabOrderStatus["paid"] = "paid";
    SlabOrderStatus["fulfilled"] = "fulfilled";
    SlabOrderStatus["canceled"] = "canceled";
})(SlabOrderStatus || (exports.SlabOrderStatus = SlabOrderStatus = {}));
//# sourceMappingURL=slab.interface.js.map