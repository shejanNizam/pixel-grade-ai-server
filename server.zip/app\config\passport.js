"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const bcrypt_1 = __importDefault(require("bcrypt"));
const passport_1 = __importDefault(require("passport"));
const passport_google_oauth20_1 = require("passport-google-oauth20");
const passport_local_1 = require("passport-local");
const index_1 = require("./index");
const auth_identity_model_1 = require("../modules/auth_identity/auth_identity.model");
const user_interface_1 = require("../modules/user/user.interface");
const user_model_1 = require("../modules/user/user.model");
const user_service_1 = require("../modules/user/user.service");
passport_1.default.use(new passport_local_1.Strategy({ usernameField: "email", passwordField: "password" }, async (email, password, done) => {
    try {
        const user = await user_model_1.User.findOne({ email }).select("+password");
        if (!user) {
            return done(null, false, { message: "User does not exist" });
        }
        if (!user.isEmailVerified) {
            return done(null, false, { message: "Email is not verified" });
        }
        if (user.status === "blocked") {
            return done(null, false, { message: "Account is blocked" });
        }
        if (user.isDeleted) {
            return done(null, false, { message: "Account has been deleted" });
        }
        if (!user.password) {
            return done(null, false, {
                message: "No password set. Login with Google first, then set a password.",
            });
        }
        const isMatch = await bcrypt_1.default.compare(password, user.password);
        if (!isMatch) {
            return done(null, false, { message: "Password does not match" });
        }
        return done(null, user);
    }
    catch (error) {
        return done(error);
    }
}));
// Only register Google strategy when credentials are provided
const googleClientId = index_1.configs.google_client_id;
const googleClientSecret = index_1.configs.google_client_secret;
const googleCallbackUrl = index_1.configs.google_callback_url;
if (googleClientId && googleClientSecret && googleCallbackUrl) {
    passport_1.default.use(new passport_google_oauth20_1.Strategy({
        clientID: googleClientId,
        clientSecret: googleClientSecret,
        callbackURL: googleCallbackUrl,
    }, async (_accessToken, _refreshToken, profile, done) => {
        try {
            const email = profile.emails?.[0]?.value;
            if (!email)
                return done(null, false, { message: "No email from Google" });
            const existingIdentity = await auth_identity_model_1.AuthIdentity.findOne({
                provider: "google",
                providerId: profile.id,
            });
            if (existingIdentity) {
                const user = await user_model_1.User.findById(existingIdentity.userId);
                if (!user)
                    return done(null, false, { message: "User not found" });
                if (user.status === "blocked") {
                    return done(null, false, { message: "Account is blocked" });
                }
                if (user.isDeleted) {
                    return done(null, false, { message: "Account has been deleted" });
                }
                return done(null, user);
            }
            let user = await user_model_1.User.findOne({ email });
            if (user) {
                if (user.status === "blocked") {
                    return done(null, false, { message: "Account is blocked" });
                }
                if (user.isDeleted) {
                    return done(null, false, { message: "Account has been deleted" });
                }
            }
            else {
                // Google never asks for a handle, but every account needs one (UI
                // Feedback v1, edit #2) — otherwise OAuth users are the only cohort
                // whose Creator Profile has nothing to be addressed by. Seeded from
                // the email local-part, changeable later in Settings.
                const username = await user_service_1.UserServices.generateUniqueUsername(email.split("@")[0] || profile.displayName);
                user = await user_model_1.User.create({
                    email,
                    username,
                    name: profile.displayName,
                    avatar: { url: profile.photos?.[0]?.value || "", publicId: "" },
                    role: user_interface_1.UserRole.user,
                    isEmailVerified: true,
                });
            }
            await auth_identity_model_1.AuthIdentity.create({
                userId: user._id,
                provider: "google",
                providerId: profile.id,
            });
            return done(null, user);
        }
        catch (error) {
            return done(error);
        }
    }));
}
passport_1.default.serializeUser((user, done) => {
    const typedUser = user;
    if (!typedUser._id) {
        return done(new Error("User _id not found during serialization"));
    }
    done(null, typedUser._id);
});
passport_1.default.deserializeUser(async (id, done) => {
    try {
        const user = await user_model_1.User.findById(id);
        done(null, user);
    }
    catch (error) {
        done(error);
    }
});
//# sourceMappingURL=passport.js.map