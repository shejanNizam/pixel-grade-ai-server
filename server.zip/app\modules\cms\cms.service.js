"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CmsServices = void 0;
const http_status_1 = __importDefault(require("http-status"));
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const cms_model_1 = require("./cms.model");
/** Public read. Pages are seeded on boot, so a missing row means the seeder did
 *  not run rather than a bad request — surfaced as 404 either way. */
const getPage = async (slug) => {
    const page = await cms_model_1.CmsPage.findOne({ slug });
    if (!page)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Page not found");
    return page;
};
const getAllPages = async () => {
    return cms_model_1.CmsPage.find().populate("updatedBy", "name email");
};
/**
 * Admin edit. Upserts so a page missing from the seed still saves rather than
 * failing, and always stamps who made the change — the client asked to track
 * who edited each page and when.
 */
const updatePage = async (slug, htmlContent, adminId) => {
    return cms_model_1.CmsPage.findOneAndUpdate({ slug }, { htmlContent, updatedBy: adminId }, { returnDocument: "after", upsert: true, runValidators: true });
};
exports.CmsServices = {
    getPage,
    getAllPages,
    updatePage,
};
//# sourceMappingURL=cms.service.js.map