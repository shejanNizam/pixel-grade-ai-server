"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CmsControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const cms_interface_1 = require("./cms.interface");
const cms_service_1 = require("./cms.service");
/** The slug comes from the URL, so it is validated here rather than by the
 *  body-only validateRequest middleware. */
const parseSlug = (value) => {
    if (!Object.values(cms_interface_1.CmsSlug).includes(value)) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, `Unknown page "${value}". Expected one of: ${Object.values(cms_interface_1.CmsSlug).join(", ")}.`);
    }
    return value;
};
const getPage = (0, catchAsync_1.default)(async (req, res) => {
    const slug = parseSlug(req.params.slug);
    const result = await cms_service_1.CmsServices.getPage(slug);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Page retrieved successfully!",
        data: result,
    });
});
const getAllPages = (0, catchAsync_1.default)(async (_req, res) => {
    const result = await cms_service_1.CmsServices.getAllPages();
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Pages retrieved successfully!",
        data: result,
    });
});
const updatePage = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: adminId } = req.user;
    const slug = parseSlug(req.params.slug);
    const result = await cms_service_1.CmsServices.updatePage(slug, req.body.htmlContent, adminId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Page updated successfully!",
        data: result,
    });
});
exports.CmsControllers = {
    getPage,
    getAllPages,
    updatePage,
};
//# sourceMappingURL=cms.controller.js.map