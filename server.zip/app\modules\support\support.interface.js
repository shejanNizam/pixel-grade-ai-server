"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TicketStatus = void 0;
var TicketStatus;
(function (TicketStatus) {
    TicketStatus["open"] = "open";
    TicketStatus["answered"] = "answered";
    TicketStatus["resolved"] = "resolved";
    TicketStatus["closed"] = "closed";
})(TicketStatus || (exports.TicketStatus = TicketStatus = {}));
//# sourceMappingURL=support.interface.js.map