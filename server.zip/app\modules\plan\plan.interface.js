"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditInterval = exports.PlanName = void 0;
/** The four tiers are fixed. Admin edits them; nobody creates, deletes, or
 *  renames one, so the name doubles as a stable identifier. */
var PlanName;
(function (PlanName) {
    PlanName["Free"] = "Free";
    PlanName["Collector"] = "Collector";
    PlanName["Pro"] = "Pro";
    PlanName["Enterprise"] = "Enterprise";
})(PlanName || (exports.PlanName = PlanName = {}));
/** When a plan's credit allowance is refilled. Free is topped up daily; every
 *  paid tier is refilled monthly — including yearly subscribers, who get their
 *  monthly allowance twelve times rather than the whole year up front. */
var CreditInterval;
(function (CreditInterval) {
    CreditInterval["daily"] = "daily";
    CreditInterval["monthly"] = "monthly";
})(CreditInterval || (exports.CreditInterval = CreditInterval = {}));
//# sourceMappingURL=plan.interface.js.map