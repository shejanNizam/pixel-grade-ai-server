"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpenAIGradingProvider = void 0;
const http_status_1 = __importDefault(require("http-status"));
const openai_1 = __importDefault(require("openai"));
const index_1 = require("../../config/index");
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const logger_1 = require("../../utils/logger");
const grading_types_1 = require("./grading.types");
/**
 * OpenAI grading provider.
 *
 * Uses chat.completions with structured outputs (`response_format.json_schema`,
 * `strict: true`), which guarantees the reply parses against `gradingSchema`
 * rather than merely being asked to.
 *
 * MODEL: set OPENAI_GRADING_MODEL explicitly. The default below is a known
 * vision-capable model, but OpenAI ships new ones frequently — confirm the
 * current best vision model against their model list rather than trusting this
 * default to still be optimal.
 *
 * See grading.types.ts for the consistency guarantee — it lives in the cache,
 * not here.
 */
let client = null;
const isConfigured = () => Boolean(index_1.configs.GRADING.openai_api_key);
const getClient = () => {
    if (!isConfigured()) {
        throw new AppError_1.default(http_status_1.default.SERVICE_UNAVAILABLE, "OpenAI grading is not configured — OPENAI_API_KEY is missing.");
    }
    client ??= new openai_1.default({ apiKey: index_1.configs.GRADING.openai_api_key });
    return client;
};
const grade = async (input) => {
    if (input.imageUrls.length === 0) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "No images to grade");
    }
    let response;
    try {
        response = await getClient().chat.completions.create({
            model: index_1.configs.GRADING.openai_model,
            max_completion_tokens: 4096,
            response_format: {
                type: "json_schema",
                json_schema: {
                    name: "card_grade",
                    strict: true,
                    schema: grading_types_1.gradingSchema,
                },
            },
            messages: [
                { role: "system", content: grading_types_1.SYSTEM_PROMPT },
                {
                    role: "user",
                    content: [
                        ...input.imageUrls.map((url) => ({ type: "image_url", image_url: { url } })),
                        { type: "text", text: (0, grading_types_1.buildUserPrompt)(input) },
                    ],
                },
            ],
        });
    }
    catch (err) {
        logger_1.logger.error("OpenAI API call failed during grading:", err);
        throw new AppError_1.default(http_status_1.default.SERVICE_UNAVAILABLE, "The AI grading service is temporarily unavailable. Please verify backend API credentials or try again shortly.");
    }
    const choice = response.choices[0];
    // A content filter stop is a 200 with empty content — reading it blindly
    // would surface as a confusing JSON parse error instead of the real cause.
    if (choice?.finish_reason === "content_filter") {
        throw new AppError_1.default(http_status_1.default.UNPROCESSABLE_ENTITY, "The grading model declined to assess these images.");
    }
    // Truncation yields syntactically invalid JSON; naming it is far more useful
    // than "malformed JSON".
    if (choice?.finish_reason === "length") {
        throw new AppError_1.default(http_status_1.default.BAD_GATEWAY, "Grading response was truncated before completing — raise max_completion_tokens.");
    }
    const text = choice?.message?.content;
    if (!text) {
        throw new AppError_1.default(http_status_1.default.BAD_GATEWAY, "Grading model returned no readable result.");
    }
    let parsed;
    try {
        parsed = JSON.parse(text);
    }
    catch {
        throw new AppError_1.default(http_status_1.default.BAD_GATEWAY, "Grading model returned malformed JSON.");
    }
    return (0, grading_types_1.normalise)(parsed, index_1.configs.GRADING.model_version, response);
};
exports.OpenAIGradingProvider = {
    name: "openai",
    grade,
    isConfigured,
};
//# sourceMappingURL=openai.provider.js.map