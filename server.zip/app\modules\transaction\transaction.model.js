"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Transaction = exports.transactionSchema = void 0;
const mongoose_1 = require("mongoose");
const transaction_interface_1 = require("./transaction.interface");
exports.transactionSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
    type: { type: String, enum: Object.values(transaction_interface_1.TxnType), required: true },
    subscription: { type: mongoose_1.Schema.Types.ObjectId, ref: "Subscription" },
    plan: { type: mongoose_1.Schema.Types.ObjectId, ref: "Plan" },
    slabOrder: { type: mongoose_1.Schema.Types.ObjectId, ref: "SlabOrder" },
    invoiceNumber: { type: String },
    amount: { type: Number, required: true },
    currency: { type: String, default: "USD" },
    status: {
        type: String,
        enum: Object.values(transaction_interface_1.TxnStatus),
        default: transaction_interface_1.TxnStatus.pending,
    },
    stripeRef: { type: String },
}, {
    timestamps: true,
    versionKey: false,
});
// Retained indefinitely for audit — never pruned.
exports.transactionSchema.index({ user: 1, createdAt: -1 });
exports.transactionSchema.index({ type: 1, status: 1 });
exports.Transaction = (0, mongoose_1.model)("Transaction", exports.transactionSchema);
//# sourceMappingURL=transaction.model.js.map