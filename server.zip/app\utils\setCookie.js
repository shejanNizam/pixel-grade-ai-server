"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clearAuthCookie = exports.setAuthCookie = exports.durationToMs = void 0;
const index_1 = require("../config/index");
/**
 * Parses a JWT-style duration ("15m", "1d", "30d", "3600") into milliseconds.
 *
 * The cookie lifetime has to track the token lifetime. Hardcoding one while the
 * other comes from env drifts the moment someone tunes JWT_REFRESH_EXPIRES, and
 * the failure is silent: the cookie outlives the token (dead session that looks
 * live) or dies first (logged out while still holding a valid refresh token).
 */
const UNIT_MS = {
    s: 1000,
    m: 60 * 1000,
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
};
const durationToMs = (value, fallbackMs) => {
    const match = /^(\d+)\s*([smhd])?$/i.exec(value.trim());
    if (!match)
        return fallbackMs;
    const amount = Number(match[1]);
    if (!Number.isFinite(amount) || amount <= 0)
        return fallbackMs;
    const unit = (match[2] ?? "s").toLowerCase();
    return amount * (UNIT_MS[unit] ?? 1000);
};
exports.durationToMs = durationToMs;
const DAY_MS = 24 * 60 * 60 * 1000;
/**
 * Writes the auth cookies.
 *
 * Two things here are load-bearing and were both wrong in prototype V1:
 *
 * 1. `maxAge` MUST be set. Without it these are *session* cookies — the browser
 *    drops them when the window closes, so a user who quits the browser is
 *    logged out even though their 30-day refresh token is still perfectly
 *    valid. This was the "users are logged out frequently" report.
 *
 * 2. Cross-site delivery. When the API is on a different site than the app
 *    (api.example.com is same-site; a Vercel app calling a separate API domain
 *    is not), Chrome discards any cookie that is not `SameSite=None; Secure`.
 *    Production always sets both. `secure` cannot be enabled on plain-HTTP
 *    localhost, which is why development keeps `lax` — same-site localhost
 *    does not need `none` anyway.
 */
const setAuthCookie = (res, tokenInfo) => {
    const isProduction = index_1.configs.node_env === "production";
    const baseOptions = {
        httpOnly: true,
        secure: isProduction,
        sameSite: (isProduction ? "none" : "lax"),
        path: "/",
    };
    if (tokenInfo.accessToken) {
        res.cookie("accessToken", tokenInfo.accessToken, {
            ...baseOptions,
            maxAge: (0, exports.durationToMs)(index_1.configs.jwt_access_expires, DAY_MS),
        });
    }
    if (tokenInfo.refreshToken) {
        res.cookie("refreshToken", tokenInfo.refreshToken, {
            ...baseOptions,
            maxAge: (0, exports.durationToMs)(index_1.configs.jwt_refresh_expires, 30 * DAY_MS),
        });
    }
};
exports.setAuthCookie = setAuthCookie;
/**
 * Clears the auth cookies.
 *
 * The attributes must match what `setAuthCookie` wrote — a `clearCookie` whose
 * sameSite/secure/path differ from the original is a no-op in every major
 * browser, which leaves a logged-out user still holding their tokens.
 */
const clearAuthCookie = (res) => {
    const isProduction = index_1.configs.node_env === "production";
    const options = {
        httpOnly: true,
        secure: isProduction,
        sameSite: (isProduction ? "none" : "lax"),
        path: "/",
    };
    res.clearCookie("accessToken", options);
    res.clearCookie("refreshToken", options);
};
exports.clearAuthCookie = clearAuthCookie;
//# sourceMappingURL=setCookie.js.map