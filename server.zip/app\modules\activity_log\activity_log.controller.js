"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActivityLogControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const activity_log_service_1 = require("./activity_log.service");
const getAllLogs = (0, catchAsync_1.default)(async (req, res) => {
    const result = await activity_log_service_1.ActivityLogServices.getAllLogs(req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Activity logs retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
exports.ActivityLogControllers = {
    getAllLogs,
};
//# sourceMappingURL=activity_log.controller.js.map