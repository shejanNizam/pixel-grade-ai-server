"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const validateRequest = (schema) => {
    return async (req, res, next) => {
        try {
            if (req.body.data) {
                req.body = JSON.parse(req.body.data);
            }
            req.body = await schema.parseAsync(req.body);
            next();
        }
        catch (error) {
            next(error);
        }
    };
};
exports.default = validateRequest;
//# sourceMappingURL=validateRequest.js.map