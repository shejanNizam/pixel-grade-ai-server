"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const validateRequest_1 = __importDefault(require("../../middlewares/validateRequest"));
const user_interface_1 = require("../user/user.interface");
const credit_controller_1 = require("./credit.controller");
const credit_validation_1 = require("./credit.validation");
const router = (0, express_1.Router)();
/**
 * @swagger
 * /credit/me:
 *   get:
 *     tags: [Credit]
 *     summary: Get the authenticated user's credit balance
 *     description: >
 *       Returns balance, whether the plan is unlimited, the cost per scan, and
 *       how many scans the balance buys. `balance` is null on unlimited plans.
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Credit balance
 *       401:
 *         description: Unauthorized
 */
router.get("/me", (0, checkAuth_1.checkAuth)(...Object.values(user_interface_1.UserRole)), credit_controller_1.CreditControllers.getMyBalance);
/**
 * @swagger
 * /credit/me/ledger:
 *   get:
 *     tags: [Credit]
 *     summary: Paginated history of the user's credit grants and spends
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Ledger entries, newest first
 *       401:
 *         description: Unauthorized
 */
router.get("/me/ledger", (0, checkAuth_1.checkAuth)(...Object.values(user_interface_1.UserRole)), credit_controller_1.CreditControllers.getMyLedger);
/**
 * @swagger
 * /credit/{userId}/ledger:
 *   get:
 *     tags: [Credit]
 *     summary: Any user's credit ledger (admin only)
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Ledger entries
 *       403:
 *         description: Forbidden — insufficient role
 */
router.get("/:userId/ledger", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), credit_controller_1.CreditControllers.getUserLedger);
/**
 * @swagger
 * /credit/{userId}/adjust:
 *   post:
 *     tags: [Credit]
 *     summary: Manually add or remove credits (admin only)
 *     description: >
 *       Additive, not a reset. Writes a ledger row recording which admin made
 *       the change. A negative adjustment larger than the balance clamps to
 *       zero rather than going negative.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Adjusted; returns the new balance
 *       403:
 *         description: Forbidden — insufficient role
 */
router.post("/:userId/adjust", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), (0, validateRequest_1.default)(credit_validation_1.adminAdjustCreditsZodSchema), credit_controller_1.CreditControllers.adminAdjust);
exports.CreditRoutes = router;
//# sourceMappingURL=credit.route.js.map