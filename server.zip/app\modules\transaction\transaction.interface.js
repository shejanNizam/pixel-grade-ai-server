"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TxnStatus = exports.TxnType = void 0;
/** Money records cover both recurring subscriptions and one-off slab orders,
 *  so admin earnings can report on either without a second collection. */
var TxnType;
(function (TxnType) {
    TxnType["subscription"] = "subscription";
    TxnType["slab_order"] = "slab_order";
})(TxnType || (exports.TxnType = TxnType = {}));
var TxnStatus;
(function (TxnStatus) {
    TxnStatus["pending"] = "pending";
    TxnStatus["succeeded"] = "succeeded";
    TxnStatus["failed"] = "failed";
    TxnStatus["refunded"] = "refunded";
})(TxnStatus || (exports.TxnStatus = TxnStatus = {}));
//# sourceMappingURL=transaction.interface.js.map