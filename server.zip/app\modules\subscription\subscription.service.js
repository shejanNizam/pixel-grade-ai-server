"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionServices = void 0;
const http_status_1 = __importDefault(require("http-status"));
const mongoose_1 = require("mongoose");
const index_1 = require("../../config/index");
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const stripe_service_1 = require("../../services/stripe.service");
const dateWindows_1 = require("../../utils/dateWindows");
const logger_1 = require("../../utils/logger");
const credit_service_1 = require("../credit/credit.service");
const notification_interface_1 = require("../notification/notification.interface");
const notification_service_1 = require("../notification/notification.service");
const plan_interface_1 = require("../plan/plan.interface");
const plan_model_1 = require("../plan/plan.model");
const transaction_model_1 = require("../transaction/transaction.model");
const transaction_interface_1 = require("../transaction/transaction.interface");
const user_model_1 = require("../user/user.model");
const subscription_interface_1 = require("./subscription.interface");
const subscription_model_1 = require("./subscription.model");
const slabOrder_model_1 = require("../slabOrder/slabOrder.model");
/**
 * What Stripe charges up front.
 *
 * Yearly is the *effective monthly* rate × 12, charged on day one — the client
 * confirmed this. It is deliberately not `priceMonthly × 12`; the discount is
 * already baked into `priceYearly`, and multiplying the wrong field is the
 * easiest way to silently overcharge every yearly customer.
 */
const amountFor = (plan, interval) => interval === subscription_interface_1.BillingInterval.yearly
    ? plan.priceYearly * 12
    : plan.priceMonthly;
/** Where the user lands after Stripe. */
const returnUrls = () => ({
    success_url: `${index_1.configs.frontend_url}/user-dashboard/subscription?checkout=success`,
    cancel_url: `${index_1.configs.frontend_url}/user-dashboard/subscription?checkout=cancelled`,
});
/**
 * Starts a checkout session.
 *
 * Free is rejected: it is the implicit default for any account without an
 * active paid subscription, so "subscribing" to it would create a Stripe
 * customer and a $0 subscription for nothing.
 */
const createCheckoutSession = async (userId, planId, interval) => {
    const plan = await plan_model_1.Plan.findById(planId);
    if (!plan)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Plan not found");
    if (plan.name === plan_interface_1.PlanName.Free) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "The Free plan is the default and does not require checkout.");
    }
    const priceId = interval === subscription_interface_1.BillingInterval.yearly
        ? plan.stripePriceIdYear
        : plan.stripePriceIdMonth;
    if (!priceId) {
        throw new AppError_1.default(http_status_1.default.SERVICE_UNAVAILABLE, `This plan has no Stripe price configured for ${interval} billing.`);
    }
    const user = await user_model_1.User.findById(userId);
    if (!user)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "User not found");
    const session = await (0, stripe_service_1.getStripe)().checkout.sessions.create({
        mode: "subscription",
        line_items: [{ price: priceId, quantity: 1 }],
        customer_email: user.email,
        // The webhook is the only place a subscription is actually activated, and
        // it needs to know who and what — the client never gets to assert either.
        metadata: {
            userId: String(user._id),
            planId: String(plan._id),
            interval,
        },
        ...returnUrls(),
    });
    return { checkoutUrl: session.url, sessionId: session.id };
};
/**
 * Activates or updates a subscription from a verified Stripe event.
 *
 * Only ever called from the webhook, never from a client route — a user who
 * could call this directly could grant themselves Enterprise.
 */
const activateFromWebhook = async (userId, planId, interval, 
/** Absent for a manual (no-Stripe) grant — see scripts/grant-plan.ts. A
 *  subscription without this id cannot be cancelled through Stripe. */
stripeSubscriptionId, currentPeriodEnd) => {
    const plan = await plan_model_1.Plan.findById(planId);
    if (!plan) {
        logger_1.logger.error("Webhook referenced an unknown plan", { planId, userId });
        return null;
    }
    const subscription = await subscription_model_1.Subscription.findOneAndUpdate({ user: userId }, {
        user: userId,
        plan: planId,
        interval,
        status: subscription_interface_1.SubStatus.active,
        // Only overwrite the Stripe id when one is supplied, so a manual re-grant
        // never wipes a real subscription reference.
        ...(stripeSubscriptionId ? { stripeSubscriptionId } : {}),
        currentPeriodEnd,
        cancelAtPeriodEnd: false,
    }, { returnDocument: "after", upsert: true, runValidators: true });
    await transaction_model_1.Transaction.create({
        user: userId,
        type: transaction_interface_1.TxnType.subscription,
        subscription: subscription?._id,
        plan: planId,
        amount: amountFor(plan, interval),
        currency: "USD",
        status: transaction_interface_1.TxnStatus.succeeded,
        stripeRef: stripeSubscriptionId ?? "manual-grant",
    });
    // Grant the new allowance immediately. On a yearly plan this grants ONE
    // month's credits — the monthly cron grants the rest, month by month.
    await credit_service_1.CreditServices.grantAllowance(userId);
    await notification_service_1.NotificationServices.create(userId, notification_interface_1.NotifType.subscription, `Your ${plan.name} plan is active`, interval === subscription_interface_1.BillingInterval.yearly
        ? `Billed yearly. Your ${plan.creditAmount ?? "unlimited"} credits refresh every month.`
        : `Billed monthly.`, "/user-dashboard/subscription");
    // Revenue event — staff see conversions as they happen rather than only in
    // the monthly figures.
    await notification_service_1.NotificationServices.createForStaff(notification_interface_1.NotifType.subscription_started, `New ${plan.name} subscription`, `Billed ${interval}.`, "/admin/subscribed-users");
    return subscription;
};
const markPastDue = async (stripeSubscriptionId) => {
    const subscription = await subscription_model_1.Subscription.findOneAndUpdate({ stripeSubscriptionId }, { status: subscription_interface_1.SubStatus.past_due }, { returnDocument: "after" });
    if (!subscription)
        return null;
    await notification_service_1.NotificationServices.create(subscription.user, notification_interface_1.NotifType.subscription, "Payment failed", "We could not process your subscription payment. Update your payment method to keep your plan active.", "/user-dashboard/subscription");
    // Churn signal — worth a staff alert while the account can still be saved.
    await notification_service_1.NotificationServices.createForStaff(notification_interface_1.NotifType.subscription_payment_failed, "A subscription payment failed", "The account is past due and may lapse.", "/admin/subscribed-users");
    return subscription;
};
const markCanceled = async (stripeSubscriptionId) => {
    return subscription_model_1.Subscription.findOneAndUpdate({ stripeSubscriptionId }, { status: subscription_interface_1.SubStatus.canceled }, { returnDocument: "after" });
};
/**
 * Handles a verified Stripe event.
 *
 * Unrecognised event types return quietly rather than throwing: Stripe retries
 * on a non-2xx, so throwing on an event we simply do not care about would
 * produce an endless retry loop.
 */
const handleWebhookEvent = async (event) => {
    switch (event.type) {
        case "checkout.session.completed": {
            const session = event.data.object;
            const { userId, planId, interval } = session.metadata ?? {};
            if (!userId || !planId || !interval) {
                logger_1.logger.error("Checkout session completed without metadata", {
                    sessionId: session.id,
                });
                return { handled: false };
            }
            await activateFromWebhook(userId, planId, interval, String(session.subscription));
            return { handled: true };
        }
        case "invoice.payment_succeeded": {
            // Renewal. Extends the period and re-grants the allowance.
            const invoice = event.data.object;
            if (!invoice.subscription)
                return { handled: false };
            const subscription = await subscription_model_1.Subscription.findOne({
                stripeSubscriptionId: String(invoice.subscription),
            });
            if (!subscription)
                return { handled: false };
            subscription.status = subscription_interface_1.SubStatus.active;
            if (invoice.period_end) {
                subscription.currentPeriodEnd = new Date(invoice.period_end * 1000);
            }
            await subscription.save();
            await credit_service_1.CreditServices.grantAllowance(String(subscription.user));
            return { handled: true };
        }
        case "invoice.payment_failed": {
            const invoice = event.data.object;
            if (invoice.subscription) {
                await markPastDue(String(invoice.subscription));
            }
            return { handled: true };
        }
        case "customer.subscription.deleted": {
            await markCanceled(String(event.data.object.id));
            return { handled: true };
        }
        default:
            return { handled: false };
    }
};
/**
 * Cancels at period end rather than immediately — the user paid through the
 * current period and keeps access until it lapses.
 */
const cancelSubscription = async (userId) => {
    const subscription = await subscription_model_1.Subscription.findOne({
        user: userId,
        status: subscription_interface_1.SubStatus.active,
    });
    if (!subscription?.stripeSubscriptionId) {
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "No active subscription found");
    }
    await (0, stripe_service_1.getStripe)().subscriptions.update(subscription.stripeSubscriptionId, {
        cancel_at_period_end: true,
    });
    subscription.cancelAtPeriodEnd = true;
    await subscription.save();
    return subscription;
};
/** The user's plan, renewal date, and credit position in one call. */
const getMySubscription = async (userId) => {
    const subscription = await subscription_model_1.Subscription.findOne({ user: userId }).populate("plan");
    const plan = await credit_service_1.CreditServices.resolvePlan(userId);
    const credits = await credit_service_1.CreditServices.getBalance(userId);
    return { subscription, plan, credits };
};
/**
 * Admin list of subscribers.
 *
 * Driven from Subscription rather than User because "subscribed" is a fact
 * about a subscription, not a column on the account — filtering `User` could
 * never express it. The user and plan are joined in so the table has a name,
 * an email, and a tier without a second round trip.
 *
 * NOTE: the admin table also has Country and State columns. Neither exists on
 * the user model, so neither is returned — see docs/OPEN-QUESTIONS.md before
 * adding them, since collecting location is a data-protection decision rather
 * than a schema one.
 */
const listSubscribers = async (query) => {
    const page = Math.max(Number(query.page) || 1, 1);
    const limit = Math.min(Math.max(Number(query.limit) || 10, 1), 100);
    const searchTerm = (query.searchTerm ?? "").trim();
    const match = {};
    // Default to active: an admin opening "Subscribed users" means people who are
    // paying now, not everyone who ever did.
    match.status = query.status
        ? query.status
        : { $in: [subscription_interface_1.SubStatus.active, subscription_interface_1.SubStatus.past_due] };
    // Cast explicitly: the joined `plan._id` is an ObjectId, and $match does not
    // coerce a string to one, so an uncast filter silently returns nothing.
    if (query.plan && mongoose_1.Types.ObjectId.isValid(query.plan)) {
        match["plan._id"] = new mongoose_1.Types.ObjectId(query.plan);
    }
    const pipeline = [
        {
            $lookup: {
                from: user_model_1.User.collection.name,
                localField: "user",
                foreignField: "_id",
                as: "user",
            },
        },
        { $unwind: "$user" },
        { $match: { "user.isDeleted": false } },
        {
            $lookup: {
                from: plan_model_1.Plan.collection.name,
                localField: "plan",
                foreignField: "_id",
                as: "plan",
            },
        },
        { $unwind: "$plan" },
        { $match: match },
    ];
    if (searchTerm) {
        const rx = new RegExp(searchTerm, "i");
        pipeline.push({
            $match: { $or: [{ "user.name": rx }, { "user.email": rx }] },
        });
    }
    pipeline.push({
        $project: {
            _id: 1,
            status: 1,
            interval: 1,
            currentPeriodEnd: 1,
            cancelAtPeriodEnd: 1,
            subscribedAt: "$createdAt",
            "user._id": 1,
            "user.name": 1,
            "user.email": 1,
            "user.status": 1,
            "user.avatar": 1,
            "user.createdAt": 1,
            "plan._id": 1,
            "plan.name": 1,
            "plan.priceMonthly": 1,
            "plan.priceYearly": 1,
        },
    });
    // $facet keeps the page and its total in one round trip.
    const [result] = await subscription_model_1.Subscription.aggregate([
        ...pipeline,
        {
            $facet: {
                data: [
                    { $sort: { subscribedAt: -1 } },
                    { $skip: (page - 1) * limit },
                    { $limit: limit },
                ],
                total: [{ $count: "count" }],
            },
        },
    ]);
    const total = result?.total?.[0]?.count ?? 0;
    return {
        data: result?.data ?? [],
        meta: { page, limit, total, totalPage: Math.ceil(total / limit) },
    };
};
/**
 * Subscriber counts and monthly recurring revenue.
 *
 * MRR takes `priceYearly` verbatim for yearly subscribers because that field is
 * ALREADY the effective monthly rate — the ×12 happens once, at checkout (see
 * `amountFor`). Dividing an annual charge by twelve here would double-discount
 * every yearly customer and quietly understate MRR.
 *
 * `past_due` counts toward neither: the subscription has not been cancelled,
 * but the money did not arrive, and reporting it as recurring revenue would
 * book income that failed to collect.
 */
const getSubscriberStats = async () => {
    const rows = await subscription_model_1.Subscription.aggregate([
        { $match: { status: subscription_interface_1.SubStatus.active } },
        {
            $lookup: {
                from: plan_model_1.Plan.collection.name,
                localField: "plan",
                foreignField: "_id",
                as: "plan",
            },
        },
        { $unwind: "$plan" },
        {
            $group: {
                _id: null,
                activeSubscriptions: { $sum: 1 },
                mrr: {
                    $sum: {
                        $cond: [
                            { $eq: ["$interval", subscription_interface_1.BillingInterval.yearly] },
                            "$plan.priceYearly",
                            "$plan.priceMonthly",
                        ],
                    },
                },
                newThisMonth: {
                    $sum: {
                        $cond: [{ $gte: ["$createdAt", (0, dateWindows_1.startOfMonth)(0)] }, 1, 0],
                    },
                },
                newLastMonth: {
                    $sum: {
                        $cond: [
                            {
                                $and: [
                                    { $gte: ["$createdAt", (0, dateWindows_1.startOfMonth)(1)] },
                                    { $lt: ["$createdAt", (0, dateWindows_1.startOfMonth)(0)] },
                                ],
                            },
                            1,
                            0,
                        ],
                    },
                },
            },
        },
    ]);
    const stats = rows[0];
    const slabRevenueAgg = await slabOrder_model_1.SlabOrder.aggregate([
        { $match: { paymentStatus: { $ne: "failed" } } },
        { $group: { _id: null, total: { $sum: "$totalAmount" } } },
    ]);
    const slabRevenue = slabRevenueAgg[0]?.total ?? 0;
    return {
        activeSubscriptions: stats?.activeSubscriptions ?? 0,
        mrr: Number((stats?.mrr ?? 0).toFixed(2)),
        slabRevenue: Number((slabRevenue ?? 0).toFixed(2)),
        newThisMonth: stats?.newThisMonth ?? 0,
        newLastMonth: stats?.newLastMonth ?? 0,
    };
};
exports.SubscriptionServices = {
    createCheckoutSession,
    listSubscribers,
    getSubscriberStats,
    handleWebhookEvent,
    activateFromWebhook,
    cancelSubscription,
    getMySubscription,
    amountFor,
};
//# sourceMappingURL=subscription.service.js.map