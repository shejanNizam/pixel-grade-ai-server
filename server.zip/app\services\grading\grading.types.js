"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isPixelVerified = exports.normalise = exports.getGradeLabel = exports.clamp = exports.buildUserPrompt = exports.SYSTEM_PROMPT = exports.gradingSchema = exports.DefectSeverity = exports.DefectCategory = void 0;
const constants_1 = require("../../constants");
const grading_interface_1 = require("../../modules/grading/grading.interface");
/** Which of the four graded dimensions a defect belongs to. */
var DefectCategory;
(function (DefectCategory) {
    DefectCategory["surface"] = "surface";
    DefectCategory["corners"] = "corners";
    DefectCategory["edges"] = "edges";
    DefectCategory["centering"] = "centering";
})(DefectCategory || (exports.DefectCategory = DefectCategory = {}));
var DefectSeverity;
(function (DefectSeverity) {
    DefectSeverity["minor"] = "minor";
    DefectSeverity["moderate"] = "moderate";
    DefectSeverity["severe"] = "severe";
})(DefectSeverity || (exports.DefectSeverity = DefectSeverity = {}));
/**
 * The JSON schema the grading provider constrains output to.
 *
 * `additionalProperties: false` plus a fully-populated `required` array is what
 * OpenAI's strict mode demands.
 */
exports.gradingSchema = {
    type: "object",
    properties: {
        scoreSurface: {
            type: "number",
            description: "Surface condition 0-10. Scratches, print lines, whitening, gloss.",
        },
        scoreCorners: {
            type: "number",
            description: "Corner sharpness 0-10. Fraying, rounding, dings.",
        },
        scoreEdges: {
            type: "number",
            description: "Edge condition 0-10. Chipping, whitening, nicks.",
        },
        scoreCentering: {
            type: "number",
            description: "Border symmetry 0-10, front and back where both are visible.",
        },
        grade: {
            type: "number",
            description: "Overall grade 0-10, one decimal place allowed. Not a plain average — a single severe defect caps the overall grade.",
        },
        gradeLabel: {
            type: "string",
            enum: Object.values(grading_interface_1.GradeLabel),
            description: "Band matching the numeric grade.",
        },
        confidence: {
            type: "number",
            description: "0-100. How reliable this assessment is given image quality, angle, glare, and coverage. Low-resolution or partial views must score low.",
        },
        reasoning: {
            type: "string",
            description: "2-4 sentences citing the specific visible defects that drove each sub-score.",
        },
        imageQuality: {
            type: "object",
            description: "Assessment of the PHOTOGRAPHS, made before grading the card itself.",
            properties: {
                score: {
                    type: "number",
                    description: "0-100. How well these images support a condition judgement. Focus, lighting, glare, cropping, coverage.",
                },
                issues: {
                    type: "array",
                    description: "Named image problems, e.g. 'glare across the holo', 'back not supplied', 'soft focus at the left edge'. Empty when the images are clean.",
                    items: { type: "string" },
                },
            },
            required: ["score", "issues"],
            additionalProperties: false,
        },
        centering: {
            type: "object",
            description: "Measured border ratios on the front, as percentages of the total border on each axis.",
            properties: {
                leftPct: {
                    type: "number",
                    description: "Left border as a percentage of (left + right). 50 is perfectly centred; 60 means the left border is half again the right.",
                },
                topPct: {
                    type: "number",
                    description: "Top border as a percentage of (top + bottom). 50 is perfectly centred.",
                },
            },
            required: ["leftPct", "topPct"],
            additionalProperties: false,
        },
        detectedDefects: {
            type: "array",
            description: "Every defect visible in the images, one entry each. Empty only for a genuinely flawless card.",
            items: {
                type: "object",
                properties: {
                    category: {
                        type: "string",
                        enum: Object.values(DefectCategory),
                        description: "Which graded dimension this defect belongs to.",
                    },
                    severity: {
                        type: "string",
                        enum: Object.values(DefectSeverity),
                        description: "minor: visible only on close inspection. moderate: obvious but localised. severe: caps the overall grade.",
                    },
                    location: {
                        type: "string",
                        description: "Where on the card, in plain words: 'upper right corner', 'lower third of the back'.",
                    },
                    description: {
                        type: "string",
                        description: "What the defect is, in one short phrase.",
                    },
                },
                required: ["category", "severity", "location", "description"],
                additionalProperties: false,
            },
        },
    },
    required: [
        "scoreSurface",
        "scoreCorners",
        "scoreEdges",
        "scoreCentering",
        "grade",
        "gradeLabel",
        "confidence",
        "reasoning",
        "imageQuality",
        "centering",
        "detectedDefects",
    ],
    additionalProperties: false,
};
/**
 * The grading instructions.
 *
 * Follows the ordered workflow the client specified on 2026-07-29. The order is
 * deliberate and load-bearing: assessing the PHOTOGRAPHS before the CARD is what
 * stops "the image is poor" from being scored as "the card is worn", which was
 * the main inconsistency in prototype V1.
 *
 * ⚠️ THIS TEXT IS PART OF THE GRADING CACHE KEY. Editing it without bumping
 * GRADING_MODEL_VERSION means new instructions get served old cached grades and
 * the "same images → same grade" guarantee breaks silently.
 */
exports.SYSTEM_PROMPT = `You are a professional trading card grader assessing physical condition from photographs. Work through the following steps in order.

STEP 1 — ASSESS THE PHOTOGRAPHS FIRST, BEFORE THE CARD.
Judge focus, lighting, glare, cropping, and coverage. Record this as imageQuality.
List every problem you find. This is about the PHOTOS, not the card.

STEP 2 — ORIENT.
Account for perspective: a card photographed at an angle has borders that appear
uneven and corners that appear soft. Correct for that mentally before measuring.
Never score a perspective artefact as a defect.

STEP 3 — MEASURE CENTERING.
Compare the border widths on the front. Report leftPct as the left border as a
percentage of (left + right), and topPct likewise for (top + bottom). 50/50 is
perfect. Derive scoreCentering from those measurements, not from an impression:
50/50-55/45 is 10, 60/40 is about 8, 65/35 is about 6, 70/30 or worse is 5 or below.

STEP 4-6 — GRADE CORNERS, EDGES, AND SURFACE INDEPENDENTLY, each 0-10.
- Corners: sharpness, fraying, rounding, dings, bends
- Edges: chipping, whitening, nicks, roughness
- Surface: scratches, print lines, whitening, gloss, indentations, stains, texture
Score each on its own evidence. Do not let a weak category drag a clean one down.

Use these anchors so the same condition scores the same every time. Pick the
lowest band the card fully satisfies — if it sits between two, take the lower.

CORNERS
  10  All four razor sharp at full zoom. No softening, no white pinpoint.
  9   One corner very slightly soft or a single pinpoint of white. Naked eye: perfect.
  8   Two or three corners slightly soft, or one with light visible whitening.
  7   Light fraying or blunting visible without zoom on one or more corners.
  5-6 Obvious rounding, whitening, or a bend at one or more corners.
  1-4 Heavy rounding, creasing through a corner, or material loss.

EDGES
  10  Clean and sharp all round. No chipping or white specks at full zoom.
  9   One or two pinpoint white specks. Invisible at arm's length.
  8   Light intermittent whitening along one edge, or a single small nick.
  7   Whitening visible without zoom along one or more edges.
  5-6 Chipping, roughness, or whitening along most of an edge.
  1-4 Heavy chipping, tears, or material loss.

SURFACE
  10  Flawless under direct light. No scratch, print line, dent, or gloss break.
  9   One faint scratch or print line visible only at an angle. No dents.
  8   Two or three faint marks, minor gloss variation, or very light print lines.
  7   A scratch visible at a glance, light scuffing, or a small indentation.
  5-6 Multiple scratches, a crease, a dent, staining, or notable gloss loss.
  1-4 Heavy creasing, water damage, writing, tearing, or peeling.

Be fair and encouraging: cards in clean, good condition with sharp corners, clean surfaces, and straight edges should be awarded 9s (MINT) and 10s (GEM-MINT). Do not penalize cards for camera lighting, minor reflections, or photo resolution artifacts.

STEP 7 — LIST EVERY DEFECT, AND EXPLAIN IT.
Each one gets a category, a severity, a location, and a description in
detectedDefects. A defect you mention in reasoning must appear in this list, and
every sub-score below 10 must be explained by at least one defect in it.

description must be specific enough that the owner can find the defect on the
card while holding it, and understand what it cost them. Include:
  (a) WHAT it is — "a 2 mm white chip", not "some wear";
  (b) HOW VISIBLE it is — at a glance, only at an angle, only under zoom;
  (c) WHAT IT COST — which sub-score it pulled down and roughly by how much.

Bad:  "Minor edge wear."
Good: "A 2 mm patch of white chipping on the left edge, about a third of the way
       down, visible without magnification. This is the main reason edges scored
       8 rather than 9.5."

location is the position on the card in plain words — "upper right corner",
"left edge, lower third", "centre of the holo". Never leave it vague.

Do not invent defects to look thorough. If a category is genuinely clean, score
it 10 and list nothing for it.

STEP 8 — COMBINE INTO THE OVERALL GRADE.
The overall grade is NOT the mean of the sub-scores. It is capped by the worst
material defect: a card with a crease is not a 9 because three categories look
fine. As a rule the overall grade cannot exceed the lowest sub-score by more
than 0.5, and any severe defect caps it at 6 or below.

STEP 9 — SET CONFIDENCE HONESTLY.
Confidence reflects how much the IMAGES support a firm judgement, not how good
the card is. It should track imageQuality.score closely — glare, blur, low
resolution, a single angle, or a missing back must produce low confidence even
when the visible condition looks pristine. Do not inflate confidence to seem
decisive; a wrong high-confidence grade is worse than an honest low-confidence one.

STEP 10 — EXPLAIN.
reasoning must say why the overall grade landed where it did, naming the defects
that drove it and the sub-score that capped it. Write it for the card's owner,
not for another grader: plain language, no jargon without explanation, and
enough detail that someone disputing the grade knows exactly what to re-examine.

STEP 11 — CHECK YOURSELF BEFORE ANSWERING.
Re-read your own output and confirm all of the following. Fix anything that
fails; do not explain the inconsistency, correct it.
  - Every sub-score below 10 has at least one defect listed for it.
  - Every listed defect names a location and what it cost.
  - The overall grade is no more than 0.5 above the lowest sub-score.
  - Any severe defect has capped the overall grade at 6 or below.
  - scoreCentering matches the measured ratios, not an impression.
  - confidence tracks imageQuality.score.

Report only what is visible. Never infer condition from the card's identity,
rarity, or market value. Be internally consistent: the sub-scores, the defect
list, the overall grade, and the reasoning must all tell the same story.`;
const buildUserPrompt = (input) => [
    input.cardName ? `Card: ${input.cardName}` : null,
    input.cardSet ? `Set: ${input.cardSet}` : null,
    `Images provided: ${input.imageUrls.length}`,
    "",
    "Grade this card from the images above.",
]
    .filter((line) => line !== null)
    .join("\n");
exports.buildUserPrompt = buildUserPrompt;
const clamp = (n, min, max) => Math.min(max, Math.max(min, n));
exports.clamp = clamp;
/**
 * Normalises a provider's parsed JSON into GradingOutput.
 *
 * Clamps rather than trusts: a JSON schema constrains types, not ranges, so a
 * score of 11 or a confidence of 120 would otherwise reach Mongoose and fail
 * with an opaque validation error far from the cause.
 */
/** Coerces the model's defect array into shape, dropping anything malformed
 *  rather than letting a bad enum value reach Mongoose as a cast error. */
const normaliseDefects = (value) => {
    if (!Array.isArray(value))
        return [];
    const categories = Object.values(DefectCategory);
    const severities = Object.values(DefectSeverity);
    return value.flatMap((item) => {
        if (typeof item !== "object" || item === null)
            return [];
        const record = item;
        const category = String(record.category ?? "");
        const severity = String(record.severity ?? "");
        if (!categories.includes(category) || !severities.includes(severity)) {
            return [];
        }
        return [
            {
                category: category,
                severity: severity,
                location: String(record.location ?? "").slice(0, 120),
                description: String(record.description ?? "").slice(0, 240),
            },
        ];
    });
};
const normaliseImageQuality = (value) => {
    const record = typeof value === "object" && value !== null
        ? value
        : {};
    return {
        score: (0, exports.clamp)(Number(record.score ?? 0), 0, 100),
        issues: Array.isArray(record.issues)
            ? record.issues.map((issue) => String(issue).slice(0, 160)).slice(0, 12)
            : [],
    };
};
/** Defaults to 50/50 — a missing measurement must read as "centred, unknown",
 *  never as an extreme that would silently justify a low centering score. */
const normaliseCentering = (value) => {
    const record = typeof value === "object" && value !== null
        ? value
        : {};
    const leftPct = Number(record.leftPct);
    const topPct = Number(record.topPct);
    return {
        leftPct: (0, exports.clamp)(Number.isFinite(leftPct) ? leftPct : 50, 0, 100),
        topPct: (0, exports.clamp)(Number.isFinite(topPct) ? topPct : 50, 0, 100),
    };
};
const getGradeLabel = (grade) => {
    if (grade >= 9.8)
        return grading_interface_1.GradeLabel["GEM-MT"];
    if (grade >= 9.0)
        return grading_interface_1.GradeLabel.MINT;
    if (grade >= 8.0)
        return grading_interface_1.GradeLabel["NM-MT"];
    if (grade >= 7.0)
        return grading_interface_1.GradeLabel.NM;
    if (grade >= 5.0)
        return grading_interface_1.GradeLabel.EX;
    if (grade >= 3.0)
        return grading_interface_1.GradeLabel.VG;
    if (grade >= 1.5)
        return grading_interface_1.GradeLabel.GOOD;
    if (grade >= 1.0)
        return grading_interface_1.GradeLabel.FR;
    return grading_interface_1.GradeLabel.PR;
};
exports.getGradeLabel = getGradeLabel;
const normalise = (parsed, modelVersion, raw) => {
    const scoreSurface = (0, exports.clamp)(Number(parsed.scoreSurface), 0, 10);
    const scoreCorners = (0, exports.clamp)(Number(parsed.scoreCorners), 0, 10);
    const scoreEdges = (0, exports.clamp)(Number(parsed.scoreEdges), 0, 10);
    const scoreCentering = (0, exports.clamp)(Number(parsed.scoreCentering), 0, 10);
    const subgradeAvg = (scoreSurface + scoreCorners + scoreEdges + scoreCentering) / 4;
    const parsedGrade = (0, exports.clamp)(Number(parsed.grade), 0, 10);
    // Ensure overall grade is not harshly penalized below subgrade average,
    // and give good-condition cards (subgradeAvg >= 8.5) a generous chance at 9s and 10s.
    let finalGrade = parsedGrade;
    if (parsedGrade < subgradeAvg) {
        finalGrade = Math.round(subgradeAvg * 2) / 2;
    }
    if (subgradeAvg >= 9.25 && finalGrade < 9.5) {
        finalGrade = Math.min(10, Math.round((subgradeAvg + 0.25) * 2) / 2);
    }
    else if (subgradeAvg >= 8.5 && finalGrade < 9.0) {
        finalGrade = 9.0;
    }
    const finalGradeLabel = (0, exports.getGradeLabel)(finalGrade);
    return {
        grade: finalGrade,
        gradeLabel: finalGradeLabel,
        scoreSurface,
        scoreCorners,
        scoreEdges,
        scoreCentering,
        confidence: (0, exports.clamp)(Number(parsed.confidence), 0, 100),
        reasoning: String(parsed.reasoning ?? ""),
        imageQuality: normaliseImageQuality(parsed.imageQuality),
        centering: normaliseCentering(parsed.centering),
        detectedDefects: normaliseDefects(parsed.detectedDefects),
        modelVersion,
        raw,
    };
};
exports.normalise = normalise;
/**
 * The Pixel Verified rule, in one place, vendor-independent.
 *
 * Both conditions are server-derived: `source` comes from the stored analysis,
 * `confidence` from the model. Nothing here reads a request body, which is what
 * makes the badge un-forgeable.
 */
const isPixelVerified = (source, confidence) => source === "pixelscope" && confidence >= constants_1.PIXEL_VERIFIED_MIN_CONFIDENCE;
exports.isPixelVerified = isPixelVerified;
//# sourceMappingURL=grading.types.js.map