"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.selectSlabVariantZodSchema = exports.regenerateSlabZodSchema = exports.createSlabLabelZodSchema = void 0;
const zod_1 = __importDefault(require("zod"));
const imagegen_provider_1 = require("../../services/imagegen.provider");
const objectId = zod_1.default
    .string()
    .regex(/^[0-9a-fA-F]{24}$/, { message: "Must be a valid ObjectId." });
/** Dimensions are deliberately absent — geometry is server-owned and comes from
 *  the schema defaults, so a client cannot resize the card window.
 *
 *  `styleId` is gone too: artwork is derived from the confirmed card rather
 *  than chosen from a fixed theme list (client, 2026-07-30). */
exports.createSlabLabelZodSchema = zod_1.default.object({
    reportId: objectId,
});
/** Regeneration takes no input — it always produces a fresh set of four. */
exports.regenerateSlabZodSchema = zod_1.default.object({});
exports.selectSlabVariantZodSchema = zod_1.default.object({
    variantIndex: zod_1.default
        .number({ error: "variantIndex must be a number" })
        .int({ message: "variantIndex must be a whole number" })
        .min(1, { message: "variantIndex starts at 1" })
        .max(imagegen_provider_1.EXT_ART_COUNT, {
        message: `There are only ${imagegen_provider_1.EXT_ART_COUNT} artwork options`,
    }),
});
//# sourceMappingURL=slab.validation.js.map