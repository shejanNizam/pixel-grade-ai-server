"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActivityLogServices = void 0;
const QueryBuilder_1 = require("../../utils/QueryBuilder");
const logger_1 = require("../../utils/logger");
const activity_log_model_1 = require("./activity_log.model");
/**
 * Audit trail. Retained a minimum of one year.
 *
 * Logging is best-effort by design: an audit write must never be the reason a
 * user-facing action fails, so failures here are logged and swallowed rather
 * than thrown. The tradeoff is deliberate — losing one audit row is preferable
 * to failing a grade the user already paid credits for.
 */
const record = async (action, options = {}) => {
    try {
        await activity_log_model_1.ActivityLog.create({
            action,
            ...(options.userId ? { user: options.userId } : {}),
            ...(options.meta ? { meta: options.meta } : {}),
            ...(options.ipAddress ? { ipAddress: options.ipAddress } : {}),
        });
    }
    catch (error) {
        logger_1.logger.error("Failed to write activity log", { action, error });
    }
};
/** Convenience wrapper that pulls the caller's identity and IP off the request.
 *  `req.user` is absent on failed logins, which is exactly when the IP matters
 *  most — hence the optional user. */
const recordFromRequest = async (req, action, meta) => {
    const userId = req.user?._id;
    await record(action, {
        userId,
        meta,
        ipAddress: req.ip,
    });
};
const getAllLogs = async (query) => {
    const queryBuilder = new QueryBuilder_1.QueryBuilder(activity_log_model_1.ActivityLog.find().populate("user", "name email role"), query);
    const logs = await queryBuilder.filter().sort().paginate().build();
    const meta = await queryBuilder.getMeta();
    return { data: logs, meta };
};
exports.ActivityLogServices = {
    record,
    recordFromRequest,
    getAllLogs,
};
//# sourceMappingURL=activity_log.service.js.map