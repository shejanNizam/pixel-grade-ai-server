"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OtpRoutes = void 0;
const express_1 = require("express");
const rateLimiter_1 = require("../../middlewares/rateLimiter");
const validateRequest_1 = __importDefault(require("../../middlewares/validateRequest"));
const otp_controller_1 = require("./otp.controller");
const otp_validation_1 = require("./otp.validation");
const router = (0, express_1.Router)();
/**
 * @swagger
 * /otp/send:
 *   post:
 *     tags: [OTP]
 *     summary: Send a 6-digit OTP to the given email address
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SendOtpRequest'
 *     responses:
 *       200:
 *         description: OTP sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessResponse'
 *       422:
 *         description: Validation error
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ValidationError'
 *       429:
 *         description: OTP send limit reached (5 per hour per IP)
 */
router.post("/send", rateLimiter_1.otpLimiter, (0, validateRequest_1.default)(otp_validation_1.sendOtpZodSchema), otp_controller_1.OTPController.sendOTP);
/**
 * @swagger
 * /otp/verify:
 *   post:
 *     tags: [OTP]
 *     summary: Verify a 6-digit OTP for the given email
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/VerifyOtpRequest'
 *     responses:
 *       200:
 *         description: OTP verified successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessResponse'
 *       400:
 *         description: Invalid or expired OTP
 *       422:
 *         description: Validation error
 */
router.post("/verify", (0, validateRequest_1.default)(otp_validation_1.verifyOtpZodSchema), otp_controller_1.OTPController.verifyOTP);
exports.OtpRoutes = router;
//# sourceMappingURL=otp.route.js.map