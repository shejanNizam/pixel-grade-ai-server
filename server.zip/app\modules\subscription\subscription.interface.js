"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubStatus = exports.BillingInterval = void 0;
/** Yearly is charged up front at the effective monthly rate × 12. It does not
 *  change the credit cadence — a yearly subscriber still refills monthly. */
var BillingInterval;
(function (BillingInterval) {
    BillingInterval["monthly"] = "monthly";
    BillingInterval["yearly"] = "yearly";
})(BillingInterval || (exports.BillingInterval = BillingInterval = {}));
var SubStatus;
(function (SubStatus) {
    SubStatus["active"] = "active";
    SubStatus["canceled"] = "canceled";
    SubStatus["past_due"] = "past_due";
    SubStatus["expired"] = "expired";
})(SubStatus || (exports.SubStatus = SubStatus = {}));
//# sourceMappingURL=subscription.interface.js.map