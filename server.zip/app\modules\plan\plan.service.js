"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlanServices = void 0;
const http_status_1 = __importDefault(require("http-status"));
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const plan_model_1 = require("./plan.model");
/** Public — powers the marketing pricing table and the subscription screen.
 *  Ordered by price so the tiers always render cheapest-first. */
const getAllPlans = async () => {
    return plan_model_1.Plan.find({ isActive: true }).sort({ priceMonthly: 1 });
};
/** Admin view includes deactivated tiers. */
const getAllPlansForAdmin = async () => {
    return plan_model_1.Plan.find().sort({ priceMonthly: 1 });
};
const getSinglePlan = async (id) => {
    const plan = await plan_model_1.Plan.findById(id);
    if (!plan)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Plan not found");
    return plan;
};
/**
 * Admin edit. The four tiers are fixed, so `name` is stripped even if it
 * survives validation — renaming a tier would orphan every subscription and
 * every wallet that resolved its allowance through it.
 */
const updatePlan = async (id, payload) => {
    const existing = await plan_model_1.Plan.findById(id);
    if (!existing)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Plan not found");
    const safePayload = { ...payload };
    delete safePayload.name;
    delete safePayload._id;
    const updated = await plan_model_1.Plan.findByIdAndUpdate(id, safePayload, {
        returnDocument: "after",
        runValidators: true,
    });
    return updated;
};
exports.PlanServices = {
    getAllPlans,
    getAllPlansForAdmin,
    getSinglePlan,
    updatePlan,
};
//# sourceMappingURL=plan.service.js.map