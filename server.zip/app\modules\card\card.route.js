"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CardRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const user_interface_1 = require("../user/user.interface");
const card_controller_1 = require("./card.controller");
const router = (0, express_1.Router)();
/**
 * @swagger
 * /card:
 *   get:
 *     tags: [Card]
 *     summary: Search the card catalogue
 *     description: >
 *       Read-only. Catalogue rows are written by the identification pipeline —
 *       there is no create, update, or delete endpoint.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: searchTerm
 *         schema:
 *           type: string
 *         description: Matches name, set/expansion, or card number
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Paginated cards
 *       401:
 *         description: Unauthorized
 */
router.get("/", (0, checkAuth_1.checkAuth)(...Object.values(user_interface_1.UserRole)), card_controller_1.CardControllers.getAllCards);
/**
 * @swagger
 * /card/sets:
 *   get:
 *     tags: [Card]
 *     summary: Distinct set/expansion names, for collection filters
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Set names
 */
router.get("/sets", (0, checkAuth_1.checkAuth)(...Object.values(user_interface_1.UserRole)), card_controller_1.CardControllers.getSets);
/**
 * @swagger
 * /card/{id}:
 *   get:
 *     tags: [Card]
 *     summary: Get a single card
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Card found
 *       404:
 *         description: Card not found
 */
router.get("/:id", (0, checkAuth_1.checkAuth)(...Object.values(user_interface_1.UserRole)), card_controller_1.CardControllers.getSingleCard);
exports.CardRoutes = router;
//# sourceMappingURL=card.route.js.map