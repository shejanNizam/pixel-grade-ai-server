"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PriceSource = void 0;
var PriceSource;
(function (PriceSource) {
    PriceSource["tcgplayer"] = "tcgplayer";
    PriceSource["pricecharting"] = "pricecharting";
    PriceSource["cardmarket"] = "cardmarket";
    PriceSource["scrydex"] = "scrydex";
})(PriceSource || (exports.PriceSource = PriceSource = {}));
//# sourceMappingURL=price.interface.js.map