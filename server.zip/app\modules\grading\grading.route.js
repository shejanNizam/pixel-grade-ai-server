"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GradingRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const rateLimiter_1 = require("../../middlewares/rateLimiter");
const user_interface_1 = require("../user/user.interface");
const grading_controller_1 = require("./grading.controller");
const router = (0, express_1.Router)();
const anyUser = Object.values(user_interface_1.UserRole);
/**
 * @swagger
 * /grading/all:
 *   get:
 *     tags: [Grading]
 *     summary: Every grading report (admin only)
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Paginated reports
 *       403:
 *         description: Forbidden — insufficient role
 */
router.get("/all", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), grading_controller_1.GradingControllers.getAllReports);
/**
 * @swagger
 * /grading:
 *   get:
 *     tags: [Grading]
 *     summary: The caller's grading reports
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Paginated reports
 */
router.get("/", (0, checkAuth_1.checkAuth)(...anyUser), grading_controller_1.GradingControllers.getMyReports);
/**
 * @swagger
 * /grading/{analysisId}:
 *   post:
 *     tags: [Grading]
 *     summary: Grade a confirmed scan
 *     description: >
 *       Requires the scan to be confirmed — an unconfirmed analysis is rejected.
 *       Results are cached by image-set hash and model version, which is what
 *       makes grading repeatable: identical images always replay the same
 *       scores rather than re-running a non-deterministic model. Costs no
 *       additional credits; the scan was already charged.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: analysisId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       201:
 *         description: Report generated
 *       400:
 *         description: Scan not confirmed, or has no images
 *       503:
 *         description: Grading service is not configured
 */
router.post("/:analysisId", (0, checkAuth_1.checkAuth)(...anyUser), grading_controller_1.GradingControllers.gradeAnalysis);
/**
 * @swagger
 * /grading/report/{id}:
 *   get:
 *     tags: [Grading]
 *     summary: Get one grading report
 *     description: Users may read their own reports; admins may read any.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Report
 *       403:
 *         description: Not your report
 *       404:
 *         description: Report not found
 */
router.get("/report/:id", (0, checkAuth_1.checkAuth)(...anyUser), grading_controller_1.GradingControllers.getReport);
/**
 * @swagger
 * /grading/report/{id}/pdf:
 *   get:
 *     tags: [Grading]
 *     summary: Download the report as a PDF
 *     description: >
 *       Returns application/pdf bytes, not JSON. Watermarked when the report
 *       OWNER's plan has watermarkReports (Free by default) — rendered fresh
 *       per download so the watermark always reflects the current plan.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: PDF file
 *       403:
 *         description: Not your report
 *       404:
 *         description: Report not found
 */
router.get("/report/:id/pdf", (0, checkAuth_1.checkAuth)(...anyUser), grading_controller_1.GradingControllers.downloadReportPdf);
/**
 * @swagger
 * /grading/verify/{pixelId}:
 *   get:
 *     tags: [Grading]
 *     summary: Public slab verification (no auth)
 *     description: >
 *       Resolves the PIXEL ID printed on a slab band to a read-only summary of
 *       the grade. This is the target of the QR code on every slab, so it is
 *       deliberately unauthenticated — anyone holding the physical card can
 *       confirm the grade is genuine.
 *
 *       Returns a fixed public projection only: card details, the four
 *       sub-scores, the grade, the owner's public handle and avatar. Never the
 *       raw model output, the reasoning, or the owner's email.
 *     parameters:
 *       - in: path
 *         name: pixelId
 *         required: true
 *         description: With or without the `PG-` prefix, any case.
 *         schema:
 *           type: string
 *           example: PG-A1B2C3D4E5
 *     responses:
 *       200:
 *         description: The public grade summary
 *       400:
 *         description: Malformed Pixel ID
 *       404:
 *         description: No graded card matches that Pixel ID
 *       429:
 *         description: Rate limited
 */
router.get("/verify/:pixelId", rateLimiter_1.verifyLimiter, grading_controller_1.GradingControllers.verifyPixelId);
exports.GradingRoutes = router;
//# sourceMappingURL=grading.route.js.map