"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GradingProvider = void 0;
const grading_types_1 = require("./grading.types");
const openai_provider_1 = require("./openai.provider");
/**
 * The grading vendor: OpenAI.
 *
 * ⚠️ Changing the model invalidates grading consistency for already-graded
 * cards: a different model will not reproduce the previous model's scores. The
 * cache key includes `GRADING_MODEL_VERSION` for exactly this reason — bump it
 * when you change `OPENAI_GRADING_MODEL`, so old reports keep their original
 * grade and new scans re-grade cleanly instead of silently mixing two models'
 * output under one key.
 */
exports.GradingProvider = {
    ...openai_provider_1.OpenAIGradingProvider,
    isPixelVerified: grading_types_1.isPixelVerified,
};
//# sourceMappingURL=index.js.map