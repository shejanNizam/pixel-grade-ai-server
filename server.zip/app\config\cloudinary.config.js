"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cloudinaryUpload = exports.deleteFromCloudinary = exports.uploadBufferToCloudinary = void 0;
/* eslint-disable @typescript-eslint/no-explicit-any */
const cloudinary_1 = require("cloudinary");
const http_status_1 = __importDefault(require("http-status"));
const index_1 = require("./index");
const AppError_1 = __importDefault(require("../errorHelpers/AppError"));
const logger_1 = require("../utils/logger");
cloudinary_1.v2.config({
    cloud_name: index_1.configs.CLOUDINARY.cloudinary_cloud_name,
    api_key: index_1.configs.CLOUDINARY.cloudinary_api_key,
    api_secret: index_1.configs.CLOUDINARY.cloudinary_api_secret,
});
const uploadBufferToCloudinary = async (buffer, fileName) => {
    try {
        return new Promise((resolve, reject) => {
            const public_id = `uploads/${fileName}-${Date.now()}`;
            cloudinary_1.v2.uploader
                .upload_stream({ resource_type: "auto", public_id, folder: "uploads" }, (error, result) => {
                if (error)
                    return reject(error);
                resolve(result);
            })
                .end(buffer);
        });
    }
    catch (error) {
        throw new AppError_1.default(http_status_1.default.INTERNAL_SERVER_ERROR, `Error uploading file: ${error.message}`);
    }
};
exports.uploadBufferToCloudinary = uploadBufferToCloudinary;
// Extracts public_id from a Cloudinary URL.
// e.g. https://res.cloudinary.com/xxx/image/upload/v123/folder/image.jpg → folder/image
const extractPublicId = (url) => {
    if (!url || typeof url !== "string")
        return null;
    const parts = url.split("/upload/");
    if (parts.length < 2)
        return null;
    const withoutVersion = (parts[1] ?? "").replace(/^v\d+\//, "");
    return withoutVersion.replace(/\.[^.]+$/, "");
};
const deleteFromCloudinary = async (url) => {
    try {
        if (!url || typeof url !== "string")
            return;
        const public_id = extractPublicId(url);
        if (!public_id)
            return;
        await cloudinary_1.v2.uploader.destroy(public_id, { resource_type: "auto" });
    }
    catch (error) {
        logger_1.logger.error(`Cloudinary deletion failed for ${url}:`, error);
    }
};
exports.deleteFromCloudinary = deleteFromCloudinary;
exports.cloudinaryUpload = cloudinary_1.v2;
//# sourceMappingURL=cloudinary.config.js.map