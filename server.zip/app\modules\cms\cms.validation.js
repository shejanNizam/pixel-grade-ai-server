"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cmsSlugSchema = exports.updateCmsPageZodSchema = void 0;
const zod_1 = __importDefault(require("zod"));
const cms_interface_1 = require("./cms.interface");
exports.updateCmsPageZodSchema = zod_1.default.object({
    htmlContent: zod_1.default
        .string({ error: "htmlContent must be string" })
        .max(200_000, { message: "Page content is too large." }),
});
exports.cmsSlugSchema = zod_1.default.enum(Object.values(cms_interface_1.CmsSlug));
//# sourceMappingURL=cms.validation.js.map