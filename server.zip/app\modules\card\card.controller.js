"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CardControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const card_service_1 = require("./card.service");
const getAllCards = (0, catchAsync_1.default)(async (req, res) => {
    const result = await card_service_1.CardServices.getAllCards(req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Cards retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getSingleCard = (0, catchAsync_1.default)(async (req, res) => {
    const result = await card_service_1.CardServices.getSingleCard(req.params.id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Card retrieved successfully!",
        data: result,
    });
});
const getSets = (0, catchAsync_1.default)(async (_req, res) => {
    const result = await card_service_1.CardServices.getSets();
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Sets retrieved successfully!",
        data: result,
    });
});
exports.CardControllers = {
    getAllCards,
    getSingleCard,
    getSets,
};
//# sourceMappingURL=card.controller.js.map