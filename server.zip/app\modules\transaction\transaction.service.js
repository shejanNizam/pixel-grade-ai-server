"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionServices = void 0;
const QueryBuilder_1 = require("../../utils/QueryBuilder");
const transaction_interface_1 = require("./transaction.interface");
const transaction_model_1 = require("./transaction.model");
/** The caller's own invoices. */
const getMyTransactions = async (userId, query) => {
    const queryBuilder = new QueryBuilder_1.QueryBuilder(transaction_model_1.Transaction.find({ user: userId }).populate("plan", "name"), query);
    const transactions = await queryBuilder.filter().sort().paginate().build();
    const meta = await queryBuilder.getMeta();
    return { data: transactions, meta };
};
const getAllTransactions = async (query) => {
    const queryBuilder = new QueryBuilder_1.QueryBuilder(transaction_model_1.Transaction.find()
        .populate("user", "name email")
        .populate("plan", "name"), query);
    const transactions = await queryBuilder.filter().sort().paginate().build();
    const meta = await queryBuilder.getMeta();
    return { data: transactions, meta };
};
/**
 * Admin earnings.
 *
 * Counts only `succeeded` — pending and failed rows exist in the ledger for
 * audit but are not revenue, and refunds are excluded from the total rather
 * than netted, so gross and refunded are both visible.
 */
const getEarnings = async (from, to) => {
    const dateFilter = {};
    if (from)
        dateFilter.$gte = from;
    if (to)
        dateFilter.$lte = to;
    const match = { status: transaction_interface_1.TxnStatus.succeeded };
    if (Object.keys(dateFilter).length)
        match.createdAt = dateFilter;
    const pipeline = [
        { $match: match },
        {
            $group: {
                _id: "$type",
                total: { $sum: "$amount" },
                count: { $sum: 1 },
            },
        },
    ];
    const byType = await transaction_model_1.Transaction.aggregate(pipeline);
    const refunded = await transaction_model_1.Transaction.aggregate([
        {
            $match: {
                status: transaction_interface_1.TxnStatus.refunded,
                ...(Object.keys(dateFilter).length ? { createdAt: dateFilter } : {}),
            },
        },
        { $group: { _id: null, total: { $sum: "$amount" }, count: { $sum: 1 } } },
    ]);
    const subscriptions = byType.find((r) => r._id === "subscription");
    const slabOrders = byType.find((r) => r._id === "slab_order");
    return {
        grossRevenue: Number(byType.reduce((sum, r) => sum + r.total, 0).toFixed(2)),
        subscriptionRevenue: Number((subscriptions?.total ?? 0).toFixed(2)),
        slabOrderRevenue: Number((slabOrders?.total ?? 0).toFixed(2)),
        subscriptionCount: subscriptions?.count ?? 0,
        slabOrderCount: slabOrders?.count ?? 0,
        refundedAmount: Number((refunded[0]?.total ?? 0).toFixed(2)),
        refundedCount: refunded[0]?.count ?? 0,
    };
};
/** Revenue bucketed by month, for the admin earnings chart. */
const getRevenueByMonth = async (months = 12) => {
    const from = new Date();
    from.setMonth(from.getMonth() - months);
    return transaction_model_1.Transaction.aggregate([
        { $match: { status: transaction_interface_1.TxnStatus.succeeded, createdAt: { $gte: from } } },
        {
            $group: {
                _id: {
                    year: { $year: "$createdAt" },
                    month: { $month: "$createdAt" },
                },
                total: { $sum: "$amount" },
                count: { $sum: 1 },
            },
        },
        { $sort: { "_id.year": 1, "_id.month": 1 } },
    ]);
};
exports.TransactionServices = {
    getMyTransactions,
    getAllTransactions,
    getEarnings,
    getRevenueByMonth,
};
//# sourceMappingURL=transaction.service.js.map