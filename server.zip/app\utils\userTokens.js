"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createNewAccessTokenWithRefreshToken = exports.createUserTokens = void 0;
const http_status_1 = __importDefault(require("http-status"));
const index_1 = require("../config/index");
const AppError_1 = __importDefault(require("../errorHelpers/AppError"));
const user_model_1 = require("../modules/user/user.model");
const jwt_1 = require("./jwt");
const createUserTokens = (user) => {
    const jwtPayload = {
        _id: user._id?.toString(),
        email: user.email,
        role: user.role,
    };
    const accessToken = (0, jwt_1.generateToken)(jwtPayload, index_1.configs.jwt_access_secret, index_1.configs.jwt_access_expires);
    const refreshToken = (0, jwt_1.generateToken)(jwtPayload, index_1.configs.jwt_refresh_secret, index_1.configs.jwt_refresh_expires);
    return { accessToken, refreshToken };
};
exports.createUserTokens = createUserTokens;
const createNewAccessTokenWithRefreshToken = async (refreshToken) => {
    const verifiedRefreshToken = (0, jwt_1.verifyToken)(refreshToken, index_1.configs.jwt_refresh_secret);
    const user = await user_model_1.User.findOne({ email: verifiedRefreshToken.email });
    if (!user) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "User does not exist");
    }
    if (user.status === "blocked") {
        throw new AppError_1.default(http_status_1.default.FORBIDDEN, "Account is blocked");
    }
    if (user.isDeleted) {
        throw new AppError_1.default(http_status_1.default.FORBIDDEN, "Account has been deleted");
    }
    const jwtPayload = {
        _id: user._id?.toString(),
        email: user.email,
        role: user.role,
    };
    return (0, jwt_1.generateToken)(jwtPayload, index_1.configs.jwt_access_secret, index_1.configs.jwt_access_expires);
};
exports.createNewAccessTokenWithRefreshToken = createNewAccessTokenWithRefreshToken;
//# sourceMappingURL=userTokens.js.map