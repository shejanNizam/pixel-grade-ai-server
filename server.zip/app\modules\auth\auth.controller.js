"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthControllers = void 0;
/* eslint-disable @typescript-eslint/no-unused-vars */
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const passport_1 = __importDefault(require("passport"));
const index_1 = require("../../config/index");
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const setCookie_1 = require("../../utils/setCookie");
const userTokens_1 = require("../../utils/userTokens");
const auth_service_1 = require("./auth.service");
// for manual login with credentials ------------>>
// const credentialsLogin = catchAsync(
//   async (req: Request, res: Response, next: NextFunction) => {
//     const loginInfo = await AuthServices.credentialLogin(req.body);
//     setAuthCookie(res, loginInfo);
//     sendResponse(res, {
//       statusCode: httpStatus.CREATED,
//       success: true,
//       message: "User loggedin successfully!",
//       data: loginInfo,
//     });
//   },
// );
// for manual login with credentials  using passport js ------------>>
const credentialsLogin = (0, catchAsync_1.default)(async (req, res, next) => {
    passport_1.default.authenticate("local", async (err, user, info) => {
        if (err) {
            return next(new AppError_1.default(http_status_1.default.INTERNAL_SERVER_ERROR, err.message));
        }
        if (!user) {
            return next(new AppError_1.default(http_status_1.default.UNAUTHORIZED, info.message));
        }
        const userTokens = (0, userTokens_1.createUserTokens)(user);
        const { password: _password, ...rest } = user.toObject();
        (0, setCookie_1.setAuthCookie)(res, userTokens);
        (0, sendResponse_1.default)(res, {
            success: true,
            statusCode: http_status_1.default.OK,
            message: "User Logged In Successfully",
            data: {
                user: rest,
                accessToken: userTokens.accessToken,
                refreshToken: userTokens.refreshToken,
            },
        });
    })(req, res, next);
});
const getNewAccessToken = (0, catchAsync_1.default)(async (req, res, next) => {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "No refresh token received from cookies!");
    }
    const tokenInfo = await auth_service_1.AuthServices.getNewAccessToken(refreshToken);
    (0, setCookie_1.setAuthCookie)(res, tokenInfo);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.CREATED,
        success: true,
        message: "New access token retrive successfully!",
        data: tokenInfo,
    });
});
const logout = (0, catchAsync_1.default)(async (req, res, next) => {
    // Must mirror the attributes setAuthCookie wrote, or the browser treats
    // this as a different cookie and the clear silently does nothing.
    (0, setCookie_1.clearAuthCookie)(res);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "User logged out successfully!",
        data: null,
    });
});
const changePassword = (0, catchAsync_1.default)(async (req, res, next) => {
    const oldPassword = req.body.oldPassword;
    const newPassword = req.body.newPassword;
    const decodedToken = req.user;
    await auth_service_1.AuthServices.changePassword(oldPassword, newPassword, decodedToken);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Password changed successfully!",
        data: null,
    });
});
const setPassword = (0, catchAsync_1.default)(async (req, res, next) => {
    const decodedToken = req.user;
    const { password } = req.body;
    await auth_service_1.AuthServices.setPassword(decodedToken._id, password);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Password set successfully!",
        data: null,
    });
});
const forgotPassword = (0, catchAsync_1.default)(async (req, res, next) => {
    const { email } = req.body;
    await auth_service_1.AuthServices.forgotPassword(email);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Email sent successfully!",
        data: null,
    });
});
const resetPassword = (0, catchAsync_1.default)(async (req, res, next) => {
    const decodedToken = req.user;
    // console.log(decodedToken);
    await auth_service_1.AuthServices.resetPassword(req.body, decodedToken);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Password reset successfully!",
        data: null,
    });
});
//  for google authentication
const googleCallbackControll = (0, catchAsync_1.default)(async (req, res, next) => {
    const user = req.user;
    if (!user) {
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "User not found!");
    }
    const tokenInfo = (0, userTokens_1.createUserTokens)(user);
    (0, setCookie_1.setAuthCookie)(res, tokenInfo);
    if (!index_1.configs.frontend_url) {
        throw new AppError_1.default(http_status_1.default.INTERNAL_SERVER_ERROR, "Frontend URL not configured");
    }
    const rawState = req.query.state || "/";
    const isRelative = rawState.startsWith("/") && !rawState.startsWith("//");
    const safePath = /^\/[a-zA-Z0-9\-._~:@!$&'()*+,;=%/?#]*$/.test(rawState)
        ? rawState
        : "/";
    res.redirect(`${index_1.configs.frontend_url}${safePath}`);
});
exports.AuthControllers = {
    credentialsLogin,
    getNewAccessToken,
    logout,
    changePassword,
    setPassword,
    forgotPassword,
    resetPassword,
    googleCallbackControll,
};
//# sourceMappingURL=auth.controller.js.map