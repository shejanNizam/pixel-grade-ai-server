"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnalysisControllers = void 0;
const http_status_1 = __importDefault(require("http-status"));
const catchAsync_1 = __importDefault(require("../../utils/catchAsync"));
const sendResponse_1 = __importDefault(require("../../utils/sendResponse"));
const analysis_interface_1 = require("./analysis.interface");
const analysis_service_1 = require("./analysis.service");
const card_interface_1 = require("../card/card.interface");
const createAnalysis = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    // Defaults are applied here rather than in the schema so the service always
    // receives a fully-populated image set.
    const images = req.body.images.map((image, index) => ({
        imageUrl: image.imageUrl,
        side: image.side ?? analysis_interface_1.ImageSide.front,
        slotIndex: image.slotIndex ?? index,
    }));
    const result = await analysis_service_1.AnalysisServices.createAnalysis(userId, {
        source: req.body.source ?? analysis_interface_1.UploadSource.standard,
        game: req.body.game ?? card_interface_1.CardGame.pokemon,
        language: req.body.language,
        images,
        clientRequestId: req.body.clientRequestId,
    });
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.CREATED,
        success: true,
        message: "Scan started — confirm the card match to continue.",
        data: result,
    });
});
const confirmCard = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await analysis_service_1.AnalysisServices.confirmCard(userId, req.params.id, req.body.cardId);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Card confirmed — grading can now begin.",
        data: result,
    });
});
const cancelAnalysis = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await analysis_service_1.AnalysisServices.cancelAnalysis(userId, req.params.id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Scan canceled — your credits have been returned.",
        data: result,
    });
});
const getMyAnalyses = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await analysis_service_1.AnalysisServices.getMyAnalyses(userId, req.query);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Scans retrieved successfully!",
        data: result.data,
        meta: result.meta,
    });
});
const getAnalysis = (0, catchAsync_1.default)(async (req, res) => {
    const { _id: userId } = req.user;
    const result = await analysis_service_1.AnalysisServices.getAnalysis(userId, req.params.id);
    (0, sendResponse_1.default)(res, {
        statusCode: http_status_1.default.OK,
        success: true,
        message: "Scan retrieved successfully!",
        data: result,
    });
});
exports.AnalysisControllers = {
    createAnalysis,
    confirmCard,
    cancelAnalysis,
    getMyAnalyses,
    getAnalysis,
};
//# sourceMappingURL=analysis.controller.js.map