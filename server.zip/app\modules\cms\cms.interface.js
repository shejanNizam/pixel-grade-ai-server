"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CmsSlug = void 0;
/** Exactly three pages, each public. The slug is the identity — pages are
 *  seeded once and thereafter only edited. */
var CmsSlug;
(function (CmsSlug) {
    CmsSlug["about"] = "about";
    CmsSlug["terms"] = "terms";
    CmsSlug["privacy"] = "privacy";
})(CmsSlug || (exports.CmsSlug = CmsSlug = {}));
//# sourceMappingURL=cms.interface.js.map