"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlabOrderRoutes = void 0;
const express_1 = require("express");
const checkAuth_1 = require("../../middlewares/checkAuth");
const user_interface_1 = require("../user/user.interface");
const slabOrder_controller_1 = require("./slabOrder.controller");
const router = (0, express_1.Router)();
const anyUser = Object.values(user_interface_1.UserRole);
router.post("/", (0, checkAuth_1.checkAuth)(...anyUser), slabOrder_controller_1.SlabOrderControllers.createOrder);
router.get("/my-orders", (0, checkAuth_1.checkAuth)(...anyUser), slabOrder_controller_1.SlabOrderControllers.getMyOrders);
router.get("/admin/all", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), slabOrder_controller_1.SlabOrderControllers.getAllOrders);
router.patch("/admin/:id", (0, checkAuth_1.checkAuth)(user_interface_1.UserRole.admin, user_interface_1.UserRole.super_admin), slabOrder_controller_1.SlabOrderControllers.updateOrderStatus);
exports.SlabOrderRoutes = router;
//# sourceMappingURL=slabOrder.route.js.map