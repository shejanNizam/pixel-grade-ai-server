"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlabOrder = void 0;
const mongoose_1 = require("mongoose");
const ShippingAddressSchema = new mongoose_1.Schema({
    fullName: { type: String, required: true, trim: true },
    phone: { type: String, required: true, trim: true },
    streetAddress: { type: String, required: true, trim: true },
    city: { type: String, required: true, trim: true },
    state: { type: String, trim: true },
    postalCode: { type: String, required: true, trim: true },
    country: { type: String, required: true, trim: true },
}, { _id: false });
const SlabOrderSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
    slab: { type: mongoose_1.Schema.Types.ObjectId, ref: "SlabLabel", required: true },
    slabLabel: { type: mongoose_1.Schema.Types.ObjectId, ref: "SlabLabel" },
    report: { type: mongoose_1.Schema.Types.ObjectId, ref: "CardAnalysis" },
    shippingAddress: { type: ShippingAddressSchema, required: true },
    quantity: { type: Number, required: true, default: 1, min: 1 },
    unitPrice: { type: Number, required: true, default: 9.99 },
    subtotal: { type: Number, required: true, default: 9.99 },
    shippingFee: { type: Number, required: true, default: 4.99 },
    taxAmount: { type: Number, required: true, default: 0.8 },
    totalAmount: { type: Number, required: true },
    amount: { type: Number },
    shippingCarrier: { type: String, default: "USPS" },
    paymentStatus: {
        type: String,
        enum: ["pending", "paid", "failed"],
        default: "paid",
    },
    orderStatus: {
        type: String,
        enum: ["pending", "processing", "shipped", "delivered", "cancelled"],
        default: "pending",
    },
    status: {
        type: String,
        default: "pending",
    },
    trackingNumber: { type: String, trim: true },
    notes: { type: String, trim: true },
}, { timestamps: true });
SlabOrderSchema.pre("save", function () {
    if (this.slab && !this.slabLabel) {
        this.slabLabel = this.slab;
    }
    if (this.totalAmount && !this.amount) {
        this.amount = this.totalAmount;
    }
    if (this.orderStatus && !this.status) {
        this.status = this.orderStatus;
    }
});
exports.SlabOrder = mongoose_1.models.SlabOrder || (0, mongoose_1.model)("SlabOrder", SlabOrderSchema);
//# sourceMappingURL=slabOrder.model.js.map