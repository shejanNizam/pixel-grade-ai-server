"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CollectionItem = exports.collectionItemSchema = void 0;
const mongoose_1 = require("mongoose");
exports.collectionItemSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
    card: { type: mongoose_1.Schema.Types.ObjectId, ref: "Card", required: true },
    report: { type: mongoose_1.Schema.Types.ObjectId, ref: "GradingReport" },
    manualImageUrl: { type: String },
    externalGrade: { type: String },
    quantity: { type: Number, default: 1, min: 1 },
    favorite: { type: Boolean, default: false },
    currentPrice: { type: Number },
    change24h: { type: Number },
    change7d: { type: Number },
    change30d: { type: Number },
}, {
    timestamps: { createdAt: "addedAt", updatedAt: true },
    versionKey: false,
});
exports.collectionItemSchema.index({ user: 1, addedAt: -1 });
// Not unique — the same card can appear twice with different grades (one PSA 9
// slabbed copy, one raw), which is why quantity exists per entry rather than
// being forced into a single row.
exports.collectionItemSchema.index({ user: 1, card: 1 });
exports.collectionItemSchema.index({ user: 1, favorite: 1 });
exports.CollectionItem = (0, mongoose_1.model)("CollectionItem", exports.collectionItemSchema);
//# sourceMappingURL=collection.model.js.map