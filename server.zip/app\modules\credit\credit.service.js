"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditServices = void 0;
const http_status_1 = __importDefault(require("http-status"));
const constants_1 = require("../../constants");
const AppError_1 = __importDefault(require("../../errorHelpers/AppError"));
const QueryBuilder_1 = require("../../utils/QueryBuilder");
const plan_interface_1 = require("../plan/plan.interface");
const plan_model_1 = require("../plan/plan.model");
const subscription_model_1 = require("../subscription/subscription.model");
const subscription_interface_1 = require("../subscription/subscription.interface");
const credit_interface_1 = require("./credit.interface");
const credit_model_1 = require("./credit.model");
const user_model_1 = require("../user/user.model");
/**
 * Every wallet mutation goes through here so no code path can move credits
 * without leaving a ledger row. `balanceAfter` is captured from the same
 * document update that changed the balance, so the two can never disagree.
 */
const recordEntry = async (userId, amount, reason, balanceAfter, analysisId, session, meta) => {
    const [entry] = await credit_model_1.CreditLedger.create([
        {
            user: userId,
            amount,
            reason,
            balanceAfter,
            ...(analysisId ? { analysis: analysisId } : {}),
            ...(meta ? { meta } : {}),
        },
    ], session ? { session } : {});
    return entry;
};
/** Mongo's duplicate-key error. The scan/refund uniqueness index turns a
 *  repeated movement into this rather than a second wallet mutation. */
const isDuplicateKey = (error) => typeof error === "object" &&
    error !== null &&
    error.code === 11000;
/**
 * Claim the right to move credits for one analysis, then move them.
 *
 * The ledger row is written BEFORE the wallet changes, which is the opposite of
 * the obvious order and the whole point: `{analysis, reason}` is unique, so the
 * insert is what arbitrates between two callers racing to refund the same scan
 * (a user closing the dialog just as the sweeper reaches it). Whoever loses the
 * insert never touches the wallet, so a scan cannot be refunded twice.
 *
 * `balanceAfter` is filled in immediately after the wallet update. It is briefly
 * wrong on the freshly-written row; that is strictly better than the
 * alternative, where a lost race has already minted credits.
 *
 * Returns null when the movement was already recorded — the caller treats that
 * as success, because the credits are where they should be either way.
 */
const claimAnalysisMovement = async (userId, amount, reason, analysisId, session, meta) => {
    try {
        const [entry] = await credit_model_1.CreditLedger.create([
            {
                user: userId,
                amount,
                reason,
                balanceAfter: 0,
                analysis: analysisId,
                ...(meta ? { meta } : {}),
            },
        ], session ? { session } : {});
        return entry ?? null;
    }
    catch (error) {
        if (isDuplicateKey(error))
            return null;
        throw error;
    }
};
/** Resolve the user's active plan, falling back to Free when they have no
 *  subscription at all — an unsubscribed account is a Free account. */
const resolvePlan = async (userId) => {
    const user = await user_model_1.User.findById(userId);
    if (user?.role === "admin" || user?.role === "super_admin") {
        const enterprise = await plan_model_1.Plan.findOne({ name: plan_interface_1.PlanName.Enterprise });
        if (enterprise)
            return enterprise;
    }
    const subscription = await subscription_model_1.Subscription.findOne({
        user: userId,
        status: subscription_interface_1.SubStatus.active,
    }).populate("plan");
    if (subscription?.plan) {
        return subscription.plan;
    }
    const free = await plan_model_1.Plan.findOne({ name: plan_interface_1.PlanName.Free });
    if (!free) {
        throw new AppError_1.default(http_status_1.default.INTERNAL_SERVER_ERROR, "Free plan is not seeded — run seedPlans.");
    }
    return free;
};
/** Wallets are created lazily on first read so an account that predates this
 *  module still gets one, rather than 404-ing forever. */
const getOrCreateWallet = async (userId) => {
    const existing = await credit_model_1.CreditWallet.findOne({ user: userId });
    if (existing)
        return existing;
    const plan = await resolvePlan(userId);
    const isUnlimited = plan.creditAmount === null;
    return credit_model_1.CreditWallet.create({
        user: userId,
        balance: isUnlimited ? 0 : (plan.creditAmount ?? 0),
        isUnlimited,
    });
};
/** Midnight this morning, server time — the boundary a daily grant crosses. */
const startOfToday = () => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    return start;
};
/**
 * Top up a Free wallet if today's allowance has not landed yet.
 *
 * The cron at 00:05 only fires in a process that is alive at 00:05. On a single
 * instance that restarts, redeploys, or is simply down for ten minutes, the
 * grant is skipped and never caught up — which is exactly the "20 daily credits
 * do not refresh" report from prototype V1. Granting lazily on read makes the
 * allowance a function of the calendar rather than of process uptime; the cron
 * stays as a backstop so wallets nobody opens still tick over.
 *
 * The claim is a single conditional update, not a read-then-write: a dashboard
 * that fires the balance, ledger, and scan requests in parallel at 00:01 must
 * produce one grant, not three. Only the caller that moves `lastDailyGrantAt`
 * past midnight writes a ledger row.
 */
const ensureDailyAllowance = async (userId) => {
    const wallet = await getOrCreateWallet(userId);
    if (wallet.isUnlimited)
        return { granted: false, balance: null };
    const plan = await resolvePlan(userId);
    if (plan.creditInterval !== plan_interface_1.CreditInterval.daily ||
        plan.creditAmount === null) {
        return { granted: false, balance: wallet.balance };
    }
    const claimed = await credit_model_1.CreditWallet.findOneAndUpdate({
        user: userId,
        isUnlimited: false,
        $or: [
            { lastDailyGrantAt: { $exists: false } },
            { lastDailyGrantAt: null },
            { lastDailyGrantAt: { $lt: startOfToday() } },
        ],
    }, { $set: { balance: plan.creditAmount, lastDailyGrantAt: new Date() } }, { returnDocument: "after" });
    if (!claimed)
        return { granted: false, balance: wallet.balance };
    // Free credits do not roll over, so the grant is a reset. The ledger records
    // the delta it actually moved, which is negative when the user still held
    // more than a day's allowance.
    await recordEntry(userId, plan.creditAmount - wallet.balance, credit_interface_1.CreditReason.grant_daily, claimed.balance);
    return { granted: true, balance: claimed.balance };
};
const getBalance = async (userId) => {
    await ensureDailyAllowance(userId);
    const wallet = await getOrCreateWallet(userId);
    const plan = await resolvePlan(userId);
    return {
        balance: wallet.isUnlimited ? null : wallet.balance,
        isUnlimited: wallet.isUnlimited,
        creditsPerScan: constants_1.CREDITS_PER_SCAN,
        scansRemaining: wallet.isUnlimited
            ? null
            : Math.floor(wallet.balance / constants_1.CREDITS_PER_SCAN),
        allowance: plan.creditAmount,
        interval: plan.creditInterval,
        periodEnd: wallet.periodEnd,
        lastDailyGrantAt: wallet.lastDailyGrantAt,
    };
};
/**
 * Server-authoritative spend. Called only from the scan pipeline — never from a
 * route that a client can reach directly.
 *
 * The debit is a single conditional update rather than a read-then-write: two
 * concurrent scans on a wallet holding 10 credits must not both succeed, and
 * `balance: { $gte: cost }` inside the update makes the check and the decrement
 * one atomic operation.
 *
 * The ledger row is claimed first (see `claimAnalysisMovement`), so one scan can
 * only ever be charged once however many times this is reached for it.
 */
const spendForScan = async (userId, analysisId, session) => {
    // Settle today's allowance before reading the balance. Without this a Free
    // user whose grant was missed is refused a scan they are entitled to, and
    // only a visit to the balance widget would unstick them.
    await ensureDailyAllowance(userId);
    const wallet = await getOrCreateWallet(userId);
    // Unlimited plans still get a ledger row so admin analytics can report
    // consumption per tier, but the balance is untouched. `charged: false` marks
    // it so a later refund knows there is nothing to give back — the user may
    // have downgraded off Enterprise in between.
    const entry = await claimAnalysisMovement(userId, -constants_1.CREDITS_PER_SCAN, credit_interface_1.CreditReason.scan, analysisId, session, wallet.isUnlimited ? { charged: false } : undefined);
    if (!entry) {
        return {
            charged: false,
            balance: wallet.isUnlimited ? null : wallet.balance,
        };
    }
    if (wallet.isUnlimited) {
        entry.balanceAfter = wallet.balance;
        await entry.save();
        return { charged: false, balance: null };
    }
    const updated = await credit_model_1.CreditWallet.findOneAndUpdate({ user: userId, isUnlimited: false, balance: { $gte: constants_1.CREDITS_PER_SCAN } }, { $inc: { balance: -constants_1.CREDITS_PER_SCAN } }, { returnDocument: "after", ...(session ? { session } : {}) });
    if (!updated) {
        // The claim did not become a debit, so it must not stay in the ledger —
        // otherwise the refund path would later "return" credits never taken.
        await credit_model_1.CreditLedger.deleteOne({ _id: entry._id });
        throw new AppError_1.default(http_status_1.default.PAYMENT_REQUIRED, `Not enough credits. A scan costs ${constants_1.CREDITS_PER_SCAN} credits and your balance is ${wallet.balance}.`);
    }
    entry.balanceAfter = updated.balance;
    await entry.save();
    return { charged: true, balance: updated.balance };
};
/**
 * Return the credits a scan took, when that scan never produced a report —
 * it failed, or the user abandoned it at the confirmation step.
 *
 * Idempotent by construction (see `claimAnalysisMovement`), because three
 * different paths can reach it for the same scan: the identification error
 * handler, an explicit cancel, and the abandoned-scan sweeper.
 *
 * Refunds are additive rather than a balance reset, so a refund racing with a
 * fresh daily grant cannot erase the grant.
 */
const refundScan = async (userId, analysisId) => {
    const wallet = await getOrCreateWallet(userId);
    if (wallet.isUnlimited)
        return { refunded: false, balance: null };
    // Nothing was ever taken for this scan (no debit was recorded, or the wallet
    // was unlimited at the time) — so there is nothing to give back.
    const debit = await credit_model_1.CreditLedger.findOne({
        analysis: analysisId,
        reason: credit_interface_1.CreditReason.scan,
    });
    if (!debit || debit.meta?.charged === false) {
        return { refunded: false, balance: wallet.balance };
    }
    const entry = await claimAnalysisMovement(userId, constants_1.CREDITS_PER_SCAN, credit_interface_1.CreditReason.refund, analysisId);
    if (!entry)
        return { refunded: false, balance: wallet.balance };
    const updated = await credit_model_1.CreditWallet.findOneAndUpdate({ user: userId, isUnlimited: false }, { $inc: { balance: constants_1.CREDITS_PER_SCAN } }, { returnDocument: "after" });
    if (!updated) {
        await credit_model_1.CreditLedger.deleteOne({ _id: entry._id });
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Wallet not found");
    }
    entry.balanceAfter = updated.balance;
    await entry.save();
    return { refunded: true, balance: updated.balance };
};
/**
 * Grant an interval's allowance. Free is a *reset to* the daily amount (no
 * rollover); paid tiers are also a reset, since the client confirmed monthly
 * allowances do not accumulate. If rollover is later approved this is the one
 * place that changes — see docs/OPEN-QUESTIONS.md.
 */
const grantAllowance = async (userId) => {
    const plan = await resolvePlan(userId);
    const wallet = await getOrCreateWallet(userId);
    if (plan.creditAmount === null) {
        await credit_model_1.CreditWallet.updateOne({ user: userId }, { isUnlimited: true, balance: 0 });
        return { granted: null, balance: null };
    }
    const isDaily = plan.creditInterval === plan_interface_1.CreditInterval.daily;
    const delta = plan.creditAmount - wallet.balance;
    const updated = await credit_model_1.CreditWallet.findOneAndUpdate({ user: userId }, {
        balance: plan.creditAmount,
        isUnlimited: false,
        ...(isDaily ? { lastDailyGrantAt: new Date() } : {}),
    }, { returnDocument: "after" });
    if (!updated)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Wallet not found");
    await recordEntry(userId, delta, isDaily ? credit_interface_1.CreditReason.grant_daily : credit_interface_1.CreditReason.grant_monthly, updated.balance);
    return { granted: plan.creditAmount, balance: updated.balance };
};
/** Admin correction. Always additive and always leaves a ledger row naming the
 *  admin who made it. */
const adminAdjust = async (userId, amount, adminId) => {
    if (!Number.isInteger(amount) || amount === 0) {
        throw new AppError_1.default(http_status_1.default.BAD_REQUEST, "Adjustment must be a non-zero whole number.");
    }
    await getOrCreateWallet(userId);
    const updated = await credit_model_1.CreditWallet.findOneAndUpdate({ user: userId }, { $inc: { balance: amount } }, { returnDocument: "after" });
    if (!updated)
        throw new AppError_1.default(http_status_1.default.NOT_FOUND, "Wallet not found");
    // $inc can drive the balance negative; clamp rather than reject, so an admin
    // clawing back more than the user holds leaves them at zero, not in debt.
    if (updated.balance < 0) {
        updated.balance = 0;
        await updated.save();
    }
    await recordEntry(userId, amount, credit_interface_1.CreditReason.admin_adjust, updated.balance, undefined, undefined, { adjustedBy: adminId });
    return { balance: updated.balance };
};
const getLedger = async (userId, query) => {
    const queryBuilder = new QueryBuilder_1.QueryBuilder(credit_model_1.CreditLedger.find({ user: userId }), query);
    const entries = await queryBuilder.filter().sort().paginate().build();
    const meta = await queryBuilder.getMeta();
    return { data: entries, meta };
};
exports.CreditServices = {
    getOrCreateWallet,
    getBalance,
    spendForScan,
    refundScan,
    grantAllowance,
    ensureDailyAllowance,
    adminAdjust,
    getLedger,
    resolvePlan,
};
//# sourceMappingURL=credit.service.js.map