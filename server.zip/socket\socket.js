"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.emitToConversation = exports.emitToUser = exports.getIO = exports.initSocket = void 0;
const redis_adapter_1 = require("@socket.io/redis-adapter");
const redis_1 = require("redis");
const socket_io_1 = require("socket.io");
const config_1 = require("../app/config");
const redis_config_1 = require("../app/config/redis.config");
const jwt_1 = require("../app/utils/jwt");
const logger_1 = require("../app/utils/logger");
let io;
const initSocket = async (httpServer) => {
    io = new socket_io_1.Server(httpServer, {
        cors: {
            origin: config_1.configs.frontend_urls.includes("*") ? true : config_1.configs.frontend_urls,
            credentials: !config_1.configs.frontend_urls.includes("*"),
        },
    });
    // Redis adapter — allows horizontal scaling across multiple server instances
    const pubClient = (0, redis_1.createClient)(redis_config_1.redisConnectionOptions);
    const subClient = pubClient.duplicate();
    (0, redis_config_1.attachRedisLogging)(pubClient, "Socket Redis pub");
    (0, redis_config_1.attachRedisLogging)(subClient, "Socket Redis sub");
    await Promise.all([pubClient.connect(), subClient.connect()]);
    io.adapter((0, redis_adapter_1.createAdapter)(pubClient, subClient));
    logger_1.logger.info("Socket.io Redis adapter connected.");
    // JWT authentication middleware — runs before every connection
    io.use((socket, next) => {
        const token = socket.handshake.auth?.token;
        if (!token)
            return next(new Error("Authentication required"));
        try {
            const decoded = (0, jwt_1.verifyToken)(token, config_1.configs.jwt_access_secret);
            socket.user = decoded;
            next();
        }
        catch {
            next(new Error("Invalid or expired token"));
        }
    });
    io.on("connection", (socket) => {
        const { _id: userId } = socket.user;
        // Every user joins their personal room on connect — used to push targeted events
        socket.join(`user:${userId}`);
        // Join a conversation room to receive messages and typing indicators for that chat
        socket.on("join_conversation", (conversationId) => {
            socket.join(`conv:${conversationId}`);
        });
        socket.on("leave_conversation", (conversationId) => {
            socket.leave(`conv:${conversationId}`);
        });
        // Relay typing indicators to the other participant(s) in the conversation
        socket.on("typing", ({ conversationId }) => {
            socket.to(`conv:${conversationId}`).emit("typing", { conversationId, userId });
        });
        socket.on("stop_typing", ({ conversationId }) => {
            socket.to(`conv:${conversationId}`).emit("stop_typing", { conversationId, userId });
        });
        socket.on("disconnect", () => {
            socket.leave(`user:${userId}`);
        });
    });
    return io;
};
exports.initSocket = initSocket;
const getIO = () => {
    if (!io)
        throw new Error("Socket.io not initialized");
    return io;
};
exports.getIO = getIO;
/**
 * Emit an event to a specific user regardless of which socket they're connected from.
 * Safe to call before socket init — silently skips if not ready.
 */
const emitToUser = (userId, event, data) => {
    try {
        (0, exports.getIO)().to(`user:${userId}`).emit(event, data);
    }
    catch {
        // socket not yet initialized (e.g. during seeding), skip silently
    }
};
exports.emitToUser = emitToUser;
/**
 * Emit an event to all sockets that joined a conversation room.
 * Reaches users who currently have that chat open.
 */
const emitToConversation = (conversationId, event, data) => {
    try {
        (0, exports.getIO)().to(`conv:${conversationId}`).emit(event, data);
    }
    catch {
        // socket not yet initialized, skip silently
    }
};
exports.emitToConversation = emitToConversation;
//# sourceMappingURL=socket.js.map